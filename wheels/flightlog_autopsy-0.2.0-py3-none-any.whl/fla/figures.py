"""把关键信号画成"能看懂事故"的图。

报告里的"图文推理"靠三样东西：图、图注、看图要点。图本身不产生新结论，
只是把检测器用到的同一批信号摊开，让人能一眼复核——哪些通道顶到上限、
姿态从哪一刻开始不跟手、高度怎么掉下去。

matplotlib 是可选依赖：没装就自动跳过图，报告其余部分照常。
"""
from __future__ import annotations

import math
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .model import Analysis, FlightLog, fmt_t

__all__ = ["Figure", "available", "build_figures", "explain", "window_for"]


@dataclass
class Figure:
    number: int
    path: Path
    title: str
    caption: str


# --------------------------------------------------------------------------
# 环境准备
# --------------------------------------------------------------------------
def _prepare_env() -> None:
    """matplotlib 需要一个可写的缓存目录；便携包里绝对不能往只读位置写。"""
    if os.environ.get("MPLCONFIGDIR"):
        return
    for cand in (Path.home() / ".cache" / "matplotlib", Path(tempfile.gettempdir()) / "fla-mpl"):
        try:
            cand.mkdir(parents=True, exist_ok=True)
            probe = cand / ".write-test"
            probe.write_text("1", encoding="utf-8")
            probe.unlink()
            os.environ["MPLCONFIGDIR"] = str(cand)
            return
        except OSError:
            continue


_FONTS = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Source Han Sans SC",
          "WenQuanYi Zen Hei", "PingFang SC", "Heiti SC", "Arial Unicode MS"]


_prepare_env()


def _plt():
    _prepare_env()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    have = {f.name for f in font_manager.fontManager.ttflist}
    picked = [f for f in _FONTS if f in have]
    plt.rcParams["font.sans-serif"] = picked + ["DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.dpi"] = 110
    plt.rcParams["savefig.bbox"] = "tight"
    return plt


def available() -> bool:
    _prepare_env()
    try:
        import matplotlib  # noqa: F401
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
# 取数据
# --------------------------------------------------------------------------
def window_for(log: FlightLog) -> tuple[float, float]:
    """图的时间窗：有事故就截事故前的 25 s，否则取最后一个架次的前 30 s。"""
    t_inc = getattr(log, "t_incident", None)
    if t_inc:
        # 事故段要覆盖到"撞地/日志中断"为止：t_incident 只是最早的那个事件
        impacts = [e.t for e in log.events if e.kind in ("impact", "crash")]
        end = max([t_inc] + impacts)
        # 日志在事故后不久就断了：整段画到日志结束，才能看到最后的姿态与输出
        if log.t_end - t_inc <= 10.0:
            t1 = log.t_end
        else:
            t1 = min(log.t_end, end + 1.0)
        return max(0.0, t1 - 20.0), t1
    arms = log.armed_intervals()
    if arms:
        t0, t1 = arms[-1]
        return t0, min(t1, t0 + 30.0)
    return 0.0, min(log.t_end, 30.0)


def _sustained(t: np.ndarray, y: np.ndarray, mask: np.ndarray) -> tuple[float, float]:
    """mask 里最长连续 True 段的 (持续秒数, 起点时刻)。"""
    best, best_t, cur_i = 0.0, float(t[0]) if len(t) else 0.0, None
    for i, flag in enumerate(mask):
        if flag:
            if cur_i is None:
                cur_i = i
            dur = float(t[i] - t[cur_i])
            if dur > best:
                best, best_t = dur, float(t[cur_i])
        else:
            cur_i = None
    return best, best_t


def _ts(v: float) -> str:
    """秒 → mm:ss.s（T+ 起点为日志开始）。"""
    m, sec = divmod(max(0.0, v), 60.0)
    return f"{int(m):02d}:{sec:04.1f}"


def _xy(s, t0: float, t1: float, maxpts: int = 4000):
    seg = s.window(t0, t1)
    t, y = seg.t, seg.y
    if len(t) > maxpts:
        k = int(np.ceil(len(t) / maxpts))
        t, y = t[::k], y[::k]
    return t, y


def _motors(log: FlightLog):
    """电机输出通道；常量通道（舵机、云台、未接通道）不算电机。"""
    out = []
    for name, s in log.series.items():
        if not name.startswith("out.c") or not name[5:].isdigit():
            continue
        if len(s.y) < 2 or float(np.max(s.y) - np.min(s.y)) < 1.0:
            continue
        out.append((int(name[5:]), s))
    out.sort(key=lambda x: x[0])
    return out


def _alt(log: FlightLog):
    """高度优先用"相对 home"，绝对高度在事故段会因 GPS 漂移误导。"""
    for key in ("alt.rel", "alt.ctun", "alt.baro", "alt.gps"):
        s = log.get(key)
        if s is not None and len(s.y) > 2:
            return key, s
    return None, None


_KIND_LABEL = {"thrust_loss": "推力损失", "estop": "电机急停", "impact": "触地",
               "failsafe": "失控保护", "crash": "撞机", "sensor": "传感器异常",
               "mode": "模式切换"}


def _mark_events(ax, log: FlightLog, t0: float, t1: float,
                 label: bool = False) -> list[str]:
    """画事件竖线；label=True 时在最上面那格写事件名（其余格只画线）。"""
    marks: list[str] = []
    seen: dict[str, float] = {}
    for e in log.events:
        if not (t0 <= e.t <= t1):
            continue
        if e.kind == "sensor":  # GPS 毛刺之类，图上不标，免得抢戏
            continue
        name = _KIND_LABEL.get(e.kind)
        if not name:
            continue
        if name in seen and e.t - seen[name] < 1.0:
            continue
        seen[name] = e.t
        ax.axvline(e.t, color="#C0392B", lw=0.9, ls="--", alpha=0.75, zorder=1)
        if label:
            ax.annotate(name, xy=(e.t, 0.02), xycoords=("data", "axes fraction"),
                        xytext=(2, 0), textcoords="offset points", rotation=90,
                        va="bottom", ha="left", fontsize=8, color="#C0392B")
        marks.append(name)
    return marks


# --------------------------------------------------------------------------
# 图 1：事故段总览（姿态 / 航向 / 电机 / 高度）
# --------------------------------------------------------------------------
def _figure_overview(a: Analysis, window: tuple[float, float], path: Path) -> Figure | None:
    plt = _plt()
    from .detectors.phase import motor_bounds

    log = a.log
    t0, t1 = window
    motor_need = {"out." + n for n in ("c1",)}
    if not any(k.startswith("out.") for k in log.series) and not log.has("att.roll"):
        return None

    t_arm = None
    arms = log.armed_intervals()
    if arms:
        t_arm = next((a0 for a0, a1 in arms if a0 <= t1 <= a1), arms[-1][0])
    base = t_arm if t_arm is not None else 0.0

    fig, axes = plt.subplots(4, 1, figsize=(11.6, 9.4), sharex=True,
                             gridspec_kw={"height_ratios": [1.35, 0.9, 1.35, 0.85]})
    ax1, ax2, ax3, ax4 = axes

    # ---- 姿态 ----
    for key, des, color, name in (("att.roll", "att.des_roll", "#1F6FD0", "滚转"),
                                  ("att.pitch", "att.des_pitch", "#2E9E5B", "俯仰")):
        s = log.get(key)
        if s is None:
            continue
        t, y = _xy(s, t0, t1)
        ax1.plot(t, y, color=color, lw=1.5, label=f"{name} 实际")
        d = log.get(des)
        if d is not None:
            td, yd = _xy(d, t0, t1)
            ax1.plot(td, yd, color=color, lw=1.1, ls="--", alpha=0.85, label=f"{name} 期望")
    ax1.set_ylabel("姿态 [°]")
    ax1.legend(loc="lower left", fontsize=8, ncol=2, framealpha=0.9)
    ax1.grid(alpha=0.25)

    # ---- 航向 ----
    yaw = log.get("att.yaw")
    if yaw is not None:
        t, y = _xy(yaw, t0, t1)
        ax2.plot(t, np.degrees(np.unwrap(np.radians(y))), color="#7A4FBF", lw=1.5, label="航向 实际")
    dyaw = log.get("att.des_yaw")
    if dyaw is not None:
        t, y = _xy(dyaw, t0, t1)
        ax2.plot(t, np.degrees(np.unwrap(np.radians(y))), color="#7A4FBF", lw=1.1,
                 ls="--", alpha=0.85, label="航向 期望")
    ax2.set_ylabel("航向 [°]")
    ax2.legend(loc="lower left", fontsize=8, framealpha=0.9)
    ax2.grid(alpha=0.25)

    # ---- 电机 ----
    motors = _motors(log)
    mb = motor_bounds(log, t1)
    if motors and mb:
        lo, hi, span = mb
        for num, series in motors:
            t, y = _xy(series, t0, t1)
            ax3.plot(t, y, lw=1.15, label=f"C{num}")
        for level, text, dy in ((hi, f"可达上限 {hi:.0f} µs", -12),
                                (lo, f"下限 {lo:.0f} µs", 5)):
            ax3.axhline(level, color="#C0392B", lw=0.9, ls=":", alpha=0.9)
            ax3.annotate(text, xy=(t0, level), xytext=(4, dy), textcoords="offset points",
                         fontsize=7.5, color="#C0392B")
        ax3.set_ylabel("电机输出 [PWM]")
        ax3.legend(loc="lower left", fontsize=7.5, ncol=6, framealpha=0.9)
    ax3.grid(alpha=0.25)

    key, s = _alt(log)
    if s is not None:
        t, y = _xy(s, t0, t1)
        if key != "alt.rel":
            y = y - y[0]
        name = {"alt.rel": "相对高度", "alt.ctun": "EKF 高度",
                "alt.baro": "气压高度", "alt.gps": "GPS 高度"}[key]
        ax4.plot(t, y, color="#2E86C1", lw=1.7, label=name)
    ax4.axhline(0, color="#999999", lw=0.6, alpha=0.6)
    ax4.set_ylabel("高度 [m]")
    ax4.set_xlabel("时间（分:秒，T+ 起点为日志开始）")
    ax4.legend(loc="lower left", fontsize=8, framealpha=0.9)
    ax4.grid(alpha=0.25)

    from matplotlib.ticker import FuncFormatter

    rel = FuncFormatter(lambda v, _pos: _ts(v))
    for i, ax in enumerate(axes):
        _mark_events(ax, log, t0, t1, label=(i == 0))
        ax.tick_params(labelsize=8)
        ax.set_xlim(t0 - 0.4, t1 + 0.4)
        ax.xaxis.set_major_formatter(rel)

    if log.t_incident:
        title = f"事故段总览 · 最后 {t1 - t0:.0f} s（至 T+{_ts(t1)}）"
    else:
        title = f"飞行段总览 · 前 {t1 - t0:.0f} s"
    fig.suptitle(title, fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.985))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)
    return None if path.stat().st_size < 1000 else None


# --------------------------------------------------------------------------
# 图 2：振动 / 电源
# --------------------------------------------------------------------------
def _figure_vibe_power(a: Analysis, window: tuple[float, float], path: Path) -> bool:
    plt = _plt()
    log = a.log
    t0, t1 = window
    has_vibe = any(k.startswith("vibe.") and k[5:].isdigit() or k in ("vibe.x", "vibe.y", "vibe.z")
                   for k in log.series)
    has_bat = log.has("bat.volt")
    if not (has_vibe or has_bat):
        return False

    rows = int(has_vibe) + int(has_bat)
    fig, axes = plt.subplots(rows, 1, figsize=(11.6, 2.9 * rows), sharex=True, squeeze=False)
    axes = [ax for row in axes for ax in row]
    i = 0
    if has_vibe:
        ax = axes[i]; i += 1
        for key, label in (("vibe.x", "X"), ("vibe.y", "Y"), ("vibe.z", "Z")):
            s = log.get(key)
            if s is None:
                continue
            t, y = _xy(s, t0, t1)
            ax.plot(t, y, lw=1.1, label=f"振动 {label}")
        for key in [k for k in log.series if k.startswith("vibe.clip")]:
            s = log.series[key]
            t, y = _xy(s, t0, t1)
            ax.plot(t, y, lw=0.9, ls=":", alpha=0.8, label="削顶计数")
            break
        ax.set_ylabel("振动 [m/s²]")
        ax.legend(loc="upper left", fontsize=8, ncol=4, framealpha=0.9)
        ax.grid(alpha=0.25)
    if has_bat:
        ax = axes[i]
        v = log.get("bat.volt")
        t, y = _xy(v, t0, t1)
        ax.plot(t, y, color="#C0392B", lw=1.4, label="电池电压")
        ax.set_ylabel("电压 [V]")
        c = log.get("bat.curr")
        if c is not None:
            ax2 = ax.twinx()
            tc, yc = _xy(c, t0, t1)
            ax2.plot(tc, yc, color="#2E86C1", lw=1.1, alpha=0.9, label="电流")
            ax2.set_ylabel("电流 [A]", color="#2E86C1")
            ax2.tick_params(axis="y", colors="#2E86C1", labelsize=8)
        ax.legend(loc="upper left", fontsize=8, framealpha=0.9)
        ax.grid(alpha=0.25)
        ax.set_xlabel("时间（分:秒，T+ 起点为日志开始）")
        ax.set_xlim(t0 - 0.4, t1 + 0.4)
        from matplotlib.ticker import FuncFormatter

        ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _pos: _ts(v)))

    fig.suptitle("振动与供电", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)
    return True



def _figure_track(a: Analysis, path: Path, provider: str = "amap") -> bool:
    """航迹图：底图 + 时间着色轨迹 + 起止点 + 关键事件落点。"""
    from matplotlib.collections import LineCollection

    from . import maps, track

    log = a.log
    facts = track.track_facts(log)
    if facts is None:
        return False
    plt = _plt()

    la, lo, t = facts["lat"], facts["lng"], facts["t"]
    lat0, lng0 = facts["home"][0], facts["home"][1]
    coslat = max(math.cos(math.radians(lat0)), 1e-6)
    east = (lo - lng0) * 111320.0 * coslat
    north = (la - lat0) * 110574.0

    span = max(float(np.ptp(east)), float(np.ptp(north)), 30.0) * 1.2
    lat_c, lng_c = float(np.mean([la.min(), la.max()])), float(np.mean([lo.min(), lo.max()]))
    half_lat = span / 2.0 / 110574.0
    half_lng = span / 2.0 / (111320.0 * coslat)

    prov = maps.resolve(provider)
    img = extent = None
    ok = total = 0
    if prov is not None:
        if prov.gcj:
            b0 = maps.wgs2gcj(lat_c - half_lat, lng_c - half_lng)
            b1 = maps.wgs2gcj(lat_c + half_lat, lng_c + half_lng)
            gy, gx = maps.wgs2gcj(la, lo)      # wgs2gcj 返回 (lat, lng)
            x, y = gx, gy
        else:
            b0, b1 = (lat_c - half_lat, lng_c - half_lng), (lat_c + half_lat, lng_c + half_lng)
            x, y = lo, la
        z = maps.choose_zoom(span, lat_c, max_zoom=prov.max_zoom)
        img, extent, ok, total = maps.stitch(prov, b0[0], b0[1], b1[0], b1[1], z)
        if img is None:
            x, y = east, north
        else:
            x, y = np.asarray(x), np.asarray(y)
    else:
        x, y = east, north

    fig, ax = plt.subplots(figsize=(7.2, 5.8))
    if img is not None:
        ax.imshow(img, extent=extent, interpolation="bilinear", zorder=0)
        # 视窗按航迹收紧：瓦片通常盖得更大，多余的边裁掉
        px0, px1, py0, py1 = (float(np.min(x)), float(np.max(x)),
                              float(np.min(y)), float(np.max(y)))
        if px1 - px0 < 1e-6:
            px0, px1 = px0 - 1e-4, px1 + 1e-4
        if py1 - py0 < 1e-6:
            py0, py1 = py0 - 1e-4, py1 + 1e-4
        pad_x, pad_y = (px1 - px0) * 0.18, (py1 - py0) * 0.18
        ax.set_xlim(max(extent[0], px0 - pad_x), min(extent[1], px1 + pad_x))
        ax.set_ylim(max(extent[2], py0 - pad_y), min(extent[3], py1 + pad_y))
        ax.set_aspect(1.0 / coslat)
        ax.set_xticks([])
        ax.set_yticks([])
        for sp in ax.spines.values():
            sp.set_edgecolor("#94a3b8")
    else:
        ax.set_aspect("equal")
        step = 10 ** math.floor(math.log10(span / 4.0))
        if span / step > 8:
            step *= 5
        lo_x, hi_x = east.min() - step, east.max() + step
        lo_y, hi_y = north.min() - step, north.max() + step
        ax.set_xlim(lo_x, hi_x)
        ax.set_ylim(lo_y, hi_y)
        ax.set_xticks(np.arange(math.floor(lo_x / step) * step, hi_x + step, step))
        ax.set_yticks(np.arange(math.floor(lo_y / step) * step, hi_y + step, step))
        ax.grid(color="#cbd5e1", lw=0.6, ls=":")
        ax.set_xlabel("东向偏移（m）", fontsize=8)
        ax.set_ylabel("北向偏移（m）", fontsize=8)
        ax.tick_params(labelsize=7.5)
        ax.axhline(0, color="#94a3b8", lw=0.7)
        ax.axvline(0, color="#94a3b8", lw=0.7)

    pts = np.column_stack([x, y]).reshape(-1, 1, 2)
    if len(pts) > 1:
        segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
        lc = LineCollection(segs, cmap="plasma", linewidth=2.2, zorder=3)
        lc.set_array(t[:-1])
        ax.add_collection(lc)
        cb = fig.colorbar(lc, ax=ax, fraction=0.032, pad=0.02)
        cb.set_label("时间（s）", fontsize=8)
        cb.ax.tick_params(labelsize=7)
        ticks = cb.get_ticks()
        cb.set_ticks(ticks)
        cb.set_ticklabels([fmt_t(v, log.t_end).replace("T+", "") for v in ticks])

    ax.plot(x[0], y[0], "o", ms=8, mfc="#22c55e", mec="white", mew=1.4, zorder=6,
            label="起点（解锁）")
    ax.plot(x[-1], y[-1], "X", ms=10, mfc="#ef4444", mec="white", mew=1.4, zorder=6,
            label="最后位置")

    marks = {"thrust_loss", "estop", "impact", "crash"}
    seen = set()
    for e in log.events:
        if e.kind not in marks or e.kind in seen:
            continue
        pos = track.position_at(log, e.t)
        if not pos:
            continue
        seen.add(e.kind)
        if img is not None:
            if prov.gcj:
                ey, ex = maps.wgs2gcj(pos[0], pos[1])
            else:
                ex, ey = pos[1], pos[0]
        else:
            ex = (pos[1] - lng0) * 111320.0 * coslat
            ey = (pos[0] - lat0) * 110574.0
        ax.plot(ex, ey, "o", ms=6, mfc="#1e293b", mec="white", mew=1.2, zorder=7)
        ax.annotate(f"{_KIND_LABEL.get(e.kind, e.kind)} {fmt_t(e.t, log.t_end)}",
                    xy=(ex, ey), xytext=(6, 7), textcoords="offset points",
                    fontsize=7, color="#0f172a", zorder=8,
                    bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="#cbd5e1", alpha=0.85))

    if img is not None:
        # 比例尺按当前视窗摆，不要按整块瓦片摆（否则会掉到坐标轴外面去）
        x0_lim, x1_lim = ax.get_xlim()
        y0_lim, y1_lim = ax.get_ylim()
        width_deg = x1_lim - x0_lim
        bar = 10 ** math.floor(math.log10(max(width_deg * 111320.0 * coslat / 5.0, 1.0)))
        bar_deg = bar / (111320.0 * coslat)
        bx = x0_lim + width_deg * 0.05
        by = y0_lim + (y1_lim - y0_lim) * 0.06
        ax.plot([bx, bx + bar_deg], [by, by], color="#111827", lw=3.2, zorder=8,
                solid_capstyle="butt")
        ax.text(bx + bar_deg / 2, by + (y1_lim - y0_lim) * 0.015, f"{bar:.0f} m",
                ha="center", va="bottom", fontsize=7.5, zorder=8,
                bbox=dict(fc="white", ec="none", alpha=0.8, pad=1.2))

    ax.legend(loc="upper left", fontsize=7.5, framealpha=0.85)
    title = f"航迹（{prov.label}）" if img is not None else "航迹（本地网格，未取在线底图）"
    ax.set_title(f"{title}　范围 {facts['max_range_m']:.0f} m", fontsize=10.5)
    foot = (f"{prov.attribution}　|　WGS-84 → GCJ-02"
            if img is not None and prov.gcj else
            (prov.attribution if img is not None else "坐标：WGS-84，起点为原点"))
    if img is not None and ok < total:
        foot += f"　|　{total - ok}/{total} 张瓦片不可用"
    if img is not None:
        ax.text(0.995, 0.008, foot, transform=ax.transAxes, ha="right", va="bottom",
                fontsize=6, color="#475569",
                bbox=dict(fc="white", ec="none", alpha=0.72, pad=1.0))
    else:
        fig.text(0.995, 0.005, foot, ha="right", va="bottom", fontsize=6, color="#64748b")

    fig.savefig(path)
    plt.close(fig)
    return True


# --------------------------------------------------------------------------
# 对外接口
# --------------------------------------------------------------------------
def build_figures(a: Analysis, outdir: str | Path, prefix: str = "fig",
                  map_provider: str = "amap") -> list[Figure]:
    """生成报告用图，返回带编号与图注的列表；matplotlib 不在就直接空表。

    ``map_provider``：航迹底图来源（``amap`` / ``osm`` / ``off``）。取 ``off``
    或瓦片取不到时自动降级成本地网格，报告照常出。
    """
    if not available():
        return []
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    window = window_for(a.log)
    figs: list[Figure] = []
    n = len(figs)

    p1 = out / f"{prefix}1.png"
    _figure_overview(a, window, p1)
    if p1.exists() and p1.stat().st_size > 1000:
        figs.append(Figure(len(figs) + 1, p1, "事故段总览",
                           _caption_overview(a, window)))
    p2 = out / f"{prefix}2.png"
    try:
        ok2 = _figure_vibe_power(a, window, p2)
    except Exception:
        ok2 = False
    if ok2 and p2.exists() and p2.stat().st_size > 1000:
        figs.append(Figure(len(figs) + 1, p2, "振动与供电",
                           "振动三轴与削顶计数（上）、电池电压与电流（下）；"
                           "振动长期偏高会加速电调与电机负担，电压骤降则直接影响推力余量。"))
    p3 = out / f"{prefix}3.png"
    try:
        ok3 = _figure_track(a, p3, provider=map_provider)
    except Exception:
        ok3 = False
    if ok3 and p3.exists() and p3.stat().st_size > 1000:
        from . import maps, track

        prov = maps.resolve(map_provider)
        base = (f"底图：{prov.label}"
                if prov else "底图：本地网格（未取在线瓦片）")
        corr = "，WGS-84 已按 GCJ-02 纠偏" if prov and prov.gcj else ""
        figs.append(Figure(len(figs) + 1, p3, "航迹与位置",
                           "线为水平航迹、颜色对应时间（右下色标），绿点为解锁/起点、红叉为最后位置；"
                           f"深色圆点为关键事件落点。{base}{corr}。"))
    return figs


def _caption_overview(a: Analysis, window: tuple[float, float]) -> str:
    log = a.log
    t0, t1 = window
    parts = []
    if log.has("att.roll"):
        parts.append("姿态（实线为实际，虚线为期望）")
    if any(k.startswith("out.") for k in log.series):
        parts.append("六路电机输出（虚线为修正后的可达上下限）")
    if log.has("alt.gps") or log.has("alt.baro"):
        parts.append("相对高度")
    body = "、".join(parts) if parts else "关键信号"
    marks = sorted({_KIND_LABEL.get(e.kind, "") for e in log.events
                    if e.kind in _KIND_LABEL and t0 <= e.t <= t1})
    tail = "，红色竖线为：" + "、".join(m for m in marks if m) if marks else ""
    base = "解锁后时间（分:秒）" if log.armed_intervals() else "时间（分:秒）"
    return f"{body}；横轴为{base}{tail}。"


def explain(a: Analysis, window: tuple[float, float] | None = None) -> list[str]:
    """看图要点：用图里的信号算几句人话，贴在图下面。"""
    from .detectors.phase import motor_bounds

    log = a.log
    t0, t1 = window or window_for(log)
    notes: list[str] = []

    roll = log.get("att.roll")
    if roll is not None:
        seg = roll.window(t0, t1)
        if len(seg.y):
            k = int(np.argmax(np.abs(seg.y)))
            notes.append(f"滚转在 {fmt_t(seg.t[k], log.t_end)} 达到 {seg.y[k]:+.1f}°"
                         f"（姿态面板），期望值同期为 "
                         f"{(log.get('att.des_roll').at(seg.t[k]) if log.has('att.des_roll') else 0):+.1f}°。")

    motors = _motors(log)
    mb = motor_bounds(log, t1)
    if motors and mb:
        lo, hi, span = mb
        tw = min(t1, log.t_incident) if log.t_incident else t1   # 只看事发前，避开急停后的余波
        sat, cut = [], []
        for num, series in motors:
            seg = series.window(t0, tw)
            if not len(seg.y):
                continue
            dur, st = _sustained(seg.t, seg.y, seg.y >= hi - 0.01 * span)
            if dur >= 1.5:
                sat.append((num, dur, st))
            dur2, st2 = _sustained(seg.t, seg.y, seg.y <= lo + 0.02 * span)
            if dur2 >= 1.5:
                cut.append((num, dur2, st2))
        for num, dur, st in sorted(sat, key=lambda x: -x[1])[:1]:
            notes.append(f"{num} 号电机自 {fmt_t(st, log.t_end)} 起被顶到可达上限 {hi:.0f} µs，"
                         f"保持 {dur:.1f} s——推力没有跟上指令，是失效嫌疑。")
        for num, dur, st in sorted(cut, key=lambda x: -x[1])[:1]:
            notes.append(f"{num} 号电机自 {fmt_t(st, log.t_end)} 起被压到下限 {lo:.0f} µs，"
                         f"保持 {dur:.1f} s——通常是飞控在配平偏航，是响应而不是故障源。")

    key, s = _alt(log)
    if s is not None:
        seg = s.window(t0, t1)
        if len(seg.y):
            y = seg.y if key == "alt.rel" else seg.y - seg.y[0]
            peak = float(y.max()) if len(y) else 0.0
            notes.append(f"高度面板：窗口内最高 {peak:.1f} m，"
                         f"结束时 {float(y[-1]):+.1f} m（{'相对 home' if key == 'alt.rel' else '相对窗口起点'}）。")
    return notes


def build_tune_figure(log, tune: dict, path) -> "Figure | None":
    """调参体检用图：速率环跟踪 + 相位/相干度。"""
    from . import tune as tune_mod

    plt = _plt()
    rate = tune.get("rate") or {}
    if not rate:
        return None
    des = log.get("rate.des_roll")
    act = log.get("rate.roll")
    if des is None or act is None:
        return None
    t = np.asarray(des.t, float)
    y_des = np.asarray(des.y, float)
    y_act = np.asarray(act.y, float)
    n = min(len(t), len(y_des), len(y_act))
    t, y_des, y_act = t[:n], y_des[:n], y_act[:n]
    full_des, full_act = y_des.copy(), y_act.copy()   # 频谱用整段，时间曲线只用平稳段
    # 只用一段平稳飞行看跟踪：从"质量窗口"中点起 40 s，避开起飞/坠机两头
    qend = getattr(log, "t_quality_end", None) or t[-1]
    a0 = max(0.0, qend * 0.45)
    keep = (t >= a0) & (t <= a0 + 40)
    if keep.sum() > 200:
        t, y_des, y_act = t[keep], y_des[keep], y_act[keep]

    fig = plt.figure(figsize=(11.2, 7.2))
    gs = fig.add_gridspec(2, 1, height_ratios=[1.25, 1.0], hspace=0.32)
    ax = fig.add_subplot(gs[0])
    ax.plot(t, y_des, color="#8aa0b8", lw=0.9, ls="--", label="期望角速率 RDes")
    ax.plot(t, y_act, color="#2f6fd0", lw=0.9, label="实际角速率 R")
    lim = float(np.percentile(np.abs(np.r_[y_des, y_act]), 99.5)) * 1.15 or 50
    ax.set_ylim(-lim, lim)
    ax.set_ylabel("横滚角速率 [°/s]")
    ax.set_title("速率环跟踪（横滚轴）　实线=实际，虚线=期望", fontsize=10.5)
    ax.legend(loc="upper right", fontsize=8, framealpha=0.9)
    ax.grid(alpha=0.25, ls=":")
    from matplotlib.ticker import FuncFormatter

    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _pos: _ts(v)))

    d = tune.get("delay") or {}
    ax2 = fig.add_subplot(gs[1])
    if d.get("usable") or d:
        f, ph, gam = tune_mod.cross_spec(full_des, full_act, rate["fs"])
        band = (f >= 0.3) & (f <= min(6.0, rate["fs"] / 4))
        ax2.plot(f[band], ph[band], ".", ms=4, color="#2f6fd0", label="相位滞后")
        fit = (f >= 0.5) & (f <= min(3.0, rate["fs"] / 4))
        if fit.sum() >= 2:
            ax2.plot(f[fit], d["lag_2hz"] - d["delay_ms"] / 1000 * 360 * (2.0 - f[fit]),
                     color="#c0392b", lw=1.2,
                     label=f"拟合：{d['delay_ms']:.0f} ms（相干度 {d['coherence']:.2f}）")
        ax2.set_xlabel("频率 [Hz]")
        ax2.set_ylabel("相位滞后 [°]")
        ax2.grid(alpha=0.25, ls=":")
        ax2.legend(loc="lower left", fontsize=8, framealpha=0.9)
        ax2b = ax2.twinx()
        ax2b.plot(f[band], gam[band], color="#2e9e6b", lw=0.9, alpha=0.75, label="相干度")
        ax2b.set_ylabel("相干度", color="#2e9e6b")
        ax2b.tick_params(axis="y", colors="#2e9e6b")
        ax2b.set_ylim(0, 1.05)

    fig.subplots_adjust(left=0.085, right=0.915, top=0.93, bottom=0.09, hspace=0.30)
    from pathlib import Path

    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return Figure(3, out, "速率环跟踪与相位",
                  f"横滚轴 RDes/R 跟踪；下图为 0.3–6 Hz 的相位滞后与相干度，"
                  f"0.5–3 Hz 线性拟合的斜率即等效延迟（{d.get('delay_ms', 0):.0f} ms，"
                  f"已扣除 FLTT {d.get('fltt_hz', 0):.0f} Hz 的 {d.get('fltt_ms', 0):.0f} ms）。")
