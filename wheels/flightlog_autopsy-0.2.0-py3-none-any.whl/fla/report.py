"""离线 Markdown 报告生成（不依赖大模型）。"""
from __future__ import annotations

import datetime as _dt
import hashlib
from pathlib import Path

from .model import Analysis, Finding, fmt_t
from .summary import summary_table

SEV_LABEL = {"critical": "严重", "warn": "警告", "info": "提示"}
SEV_ICON = {"critical": "🟥", "warn": "🟨", "info": "🟦"}
CN_NUM = "一二三四五六七八九十"

ADVICE = {
    "truncated-log": "确认坠机现场：检查电池是否脱落、飞控/SD 卡是否损坏；若需要复盘，优先保证日志完整落盘。",
    "thrust-loss": "先查被顶到上限的那一路：桨叶是否断裂/脱落、电机线是否虚焊、电调是否过热保护、ESC 校准是否一致；"
                    "被压低的那一路通常是飞控的配平动作，先确认它本身完好再排除。",
    "estop": "复核 E-Stop 开关的通道映射与物理位置，确认是否误触；若为主动处置，说明当时已判断失控。",
    "mode-switch": "回放当时的模式操作：为什么切到定高/定点而不是 RTL/LAND；复核失控保护选项"
                   "（FS_OPTIONS / FS_THR_ENABLE / FENCE_ACTION），让推力损失能自动触发返航或迫降。",
    "impact": "检查机架、脚架、桨叶与减震；结合加速度峰值判断触地姿态。",
    "vibration": "检查桨平衡、电机轴承、机架紧固与飞控减震；必要时降低 INS_ACCEL_FILTER / 调整 Notch。",
    "imu-consistency": "双 IMU 读数不一致：检查飞控减震是否松动、IMU 是否损坏；校准并做地面振动测试。",
    "compass": "重新校准罗盘、检查磁罗盘与电源线距离；GPS/罗盘同时报警时优先排除供电干扰。",
    "attitude-tracking": "检查 PID/滤波与重心；姿态跟踪误差大往往意味着动力不足或重心严重偏移。",
    "flip": "翻转通常不可恢复：检查电机转向/桨叶方向、机架刚度与重心。",
    "oscillation": "识别出的振荡频率可用于设置 Notch 滤波；检查桨叶缺损与机臂共振。",
    "gps-quality": "检查 GPS 安装位置（远离图传/电源）、天线与屏蔽；卫星数骤降时避免依赖 GPS 模式。",
    "ekf-health": "EKF 新息/方差异常说明估计器不信任传感器：检查罗盘干扰、GPS 跳变与振动。",
    "altitude-consistency": "气压与 GPS 高度偏差大：检查气压计遮挡/风压、GPS 高度异常。",
    "battery": "检查电池内阻与接头；电压骤降会导致电调欠压、飞控复位。",
    "actuator-saturation": "输出长期打满说明动力余量不足：减重、换桨或检查电池；也可能是单个电机失效后其余在补偿。",
    "rc-link": "检查遥控链路、接收机天线与失控保护配置（FS_THR_ENABLE / FS_GPS_ENABLE）。",
    "system-load": "降低日志频率/关闭多余功能；主循环超时会触发看门狗复位。",
    "failsafe-sequence": "按时间线复核每一步处置是否及时；建议开启 GPS/罗盘一致性检查与围栏。",
}


def _sha256(path: Path, limit: int = 4 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(limit):
            h.update(chunk)
    return h.hexdigest()[:16]


def _bar(score: int) -> str:
    filled = int(round(score / 10))
    return "█" * filled + "░" * (10 - filled) + f"  {score}/100"


def _finding_block(i: int, f: Finding, t_end: float) -> str:
    span = ""
    if f.t_start is not None:
        span = fmt_t(f.t_start, t_end)
        if f.t_end is not None and abs(f.t_end - f.t_start) > 1:
            span += f" → {fmt_t(f.t_end, t_end)}"
    lines = [f"### {i}. {SEV_ICON.get(f.severity, '')} {f.title}",
             f"- **类别**：{f.category}　**严重度**：{SEV_LABEL.get(f.severity, f.severity)}"
             f"　**置信度**：{f.confidence:.0%}"
             + (f"　**时间**：{span}" if span else "")]
    if f.evidence:
        lines.append("- **证据**：")
        lines += [f"  - {e}" for e in f.evidence]
    if f.conclusion:
        lines.append(f"- **判读**：{f.conclusion}")
    if f.refs:
        lines.append(f"- **相关日志**：`{'`, `'.join(f.refs)}`")
    return "\n".join(lines)


def _fmt_ll(lat: float, lng: float) -> str:
    ns = "N" if lat >= 0 else "S"
    ew = "E" if lng >= 0 else "W"
    return f"{abs(lat):.5f}°{ns}, {abs(lng):.5f}°{ew}"


def _track_section(log) -> list[str]:
    """「航迹与位置」章节；没有定位数据返回空表。"""
    try:
        from .track import track_facts
        from .track import position_at as _pos_at
    except Exception:
        return []
    facts = track_facts(log)
    if not facts:
        return []
    out: list[str] = []
    home_lat, home_lng, home_t = facts["home"]
    end_lat, end_lng, end_t = facts["end"]
    out.append("| 项目 | 值 |")
    out.append("| --- | --- |")
    out.append(f"| 起点（解锁位置） | {_fmt_ll(home_lat, home_lng)}　`{fmt_t(home_t, log.t_end)}` |")
    out.append(f"| 最后位置 | {_fmt_ll(end_lat, end_lng)}　`{fmt_t(end_t, log.t_end)}` |")
    peak_lat, peak_lng, peak_t = facts["max_range_at"]
    out.append(f"| 最大离起点距离 | **{facts['max_range_m']:.0f} m**　"
               f"`{fmt_t(peak_t, log.t_end)}`　（{_fmt_ll(peak_lat, peak_lng)}）|")
    out.append(f"| 水平航迹总长 | {facts['path_m']:.0f} m |")
    out.append(f"| 终点相对起点偏移 | {facts['final_offset_m']:.0f} m |")
    if "alt_max" in facts:
        lo = facts.get("alt_min", 0.0)
        out.append(f"| 相对高度范围（1–99 分位） | {lo:.1f} ~ {facts['alt_max']:.1f} m |")
    if "max_speed_ms" in facts:
        out.append(f"| 最大地速 | {facts['max_speed_ms']:.1f} m/s |")
    out.append("")

    marks = {"thrust_loss": "推力损失", "estop": "电机急停", "impact": "触地",
             "crash": "撞机"}
    rows = []
    seen = set()
    for e in log.events:
        if e.kind not in marks or e.kind in seen:
            continue
        pos = _pos_at(log, e.t)
        if not pos:
            continue
        seen.add(e.kind)
        dist = None
        try:
            from .track import haversine

            dist = haversine(home_lat, home_lng, pos[0], pos[1])
        except Exception:
            pass
        extra = f"，距起点 {dist:.0f} m" if dist is not None else ""
        rows.append(f"- `{fmt_t(e.t, log.t_end)}` **{marks[e.kind]}**：{_fmt_ll(pos[0], pos[1])}{extra}")
    if rows:
        out.append("关键事件落点：")
        out.append("")
        out.extend(rows)
        out.append("")

    out.append("> 坐标是日志里的 WGS-84 原始值，未做脱敏；"
               "底图为在线瓦片，客户机上取不到瓦片时自动降级为本地网格图。")
    out.append("")
    return out


def render_markdown(analysis: Analysis, title: str | None = None,
                    narrative: dict | None = None,
                    figures: list | None = None,
                    notes: list[str] | None = None) -> str:
    """渲染中文 Markdown 报告。

    narrative 为 ``fla.llm.narrate()`` 的返回值；给了就插入"事故复盘"章节，
    没给（无密钥/离线）则只有规则层结论。
    """
    log = analysis.log
    s = analysis.summary
    path = Path(log.path)
    now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    out: list[str] = []
    add = out.append
    n = 0

    def section(name: str) -> None:
        nonlocal n
        n += 1
        add(f"## {CN_NUM[n - 1] if n - 1 < len(CN_NUM) else n}、{name}")
        add("")

    add(f"# {title or '飞行事故分析报告'}")
    add("")
    add(f"> 日志：`{path.name}`　·　生成时间：{now}　·　"
        f"大小：{path.stat().st_size / 1e6:.1f} MB　·　SHA256：`{_sha256(path)}`")
    add("")

    section("结论")
    add(f"**{analysis.verdict}**　`{_bar(analysis.score)}`　证据强度（不是发生率）")
    add("")
    if analysis.score >= 95:
        n_crit = len(analysis.by_severity("critical"))
        add(f"> 读取方式：量表按严重度加权累加、100 封顶。本例 {n_crit} 项严重证据已把量表顶满，"
            f"所以显示 {analysis.score}/100——它表示“证据远多于判定阈值”，"
            "而不是“100% 会发生事故”的概率。")
        add("")
    add(analysis.verdict_text or "（无）")
    add("")
    counts = {k: len(analysis.by_severity(k)) for k in ("critical", "warn", "info")}
    add(f"检出问题：严重 **{counts['critical']}** 条、警告 **{counts['warn']}** 条、"
        f"提示 **{counts['info']}** 条；未执行检查 **{len(analysis.skipped)}** 条。")
    add("")

    if figures:
        section("图解复现")
        add("规则层把关键信号画成图，判断依据都落在图上，方便逐条复核。")
        add("")
        for fig in figures:
            add(f"![图 {fig.number}　{fig.title}]({Path(fig.path).name})")
            add(f"*图 {fig.number}　{fig.title}：{fig.caption}*")
            add("")
        if notes:
            add("**看图要点**：")
            add("")
            for note in notes:
                add(f"- {note}")
            add("")

    track_facts = _track_section(log)
    if track_facts:
        section("航迹与位置")
        out.extend(track_facts)

    if narrative:
        from .llm import narrative_markdown

        section("事故复盘（大模型叙事）")
        add(narrative_markdown(narrative, analysis))
        try:
            from .llm import evidence_pack
            from .verify import check as verify_narrative

            rep = verify_narrative(narrative, evidence_pack(analysis), log.t_end)
            add("")
            add("### 叙事核对")
            if rep["ok"]:
                add(f"- 核对通过：{rep['times']} 个时间戳、{rep['nums']} 个数字都能在证据包里找到。")
            else:
                add(f"- 时间戳 {rep['times']} 处、数字 {rep['nums']} 处，其中需要人工确认：")
                for t in rep["bad_times"]:
                    add(f"  - 时间 T+{int(t // 60):02d}:{t % 60:04.1f} 未在证据包中出现")
                for bad in rep["bad_nums"]:
                    add(f"  - 数值 {bad} 未在证据包中直接出现（可能是换算、规则阈值或补全，请对照检测明细）")
                add("  （模型只写叙事，数字应来自规则层；对不上的请以检测明细为准）")
            add("")
        except Exception as exc:  # 核对失败不影响报告
            add(f"- 核对未执行：{exc}")
            add("")

    section("日志概况")
    add("| 项目 | 值 |")
    add("| --- | --- |")
    for k, v in summary_table(s):
        add(f"| {k} | {v} |")
    add("")

    sessions = s.get("sessions") or []
    if len(sessions) > 1:
        add("### 架次概览")
        add("")
        add("| 架次 | 开始 | 时长 | 最大高度 | 起始模式 | 结束 |")
        add("| --- | --- | --- | --- | --- | --- |")
        for x in sessions[:12]:
            alt = "—" if x.get("max_alt_m") is None else f"{x['max_alt_m']:.1f} m"
            end = "正常上锁" if x.get("end") == "disarm" else "**中断/未上锁**"
            add(f"| 第 {x['index']} 架次 | {fmt_t(x['t_start'], log.t_end)} | {x['dur']:.1f} s | "
                f"{alt} | {x.get('mode_start') or '—'} | {end} |")
        add("")

    modes = s.get("modes") or []
    if len(modes) > 1:
        add("### 飞行模式时间线")
        add("")
        add("| 模式 | 开始 | 持续 |")
        add("| --- | --- | --- |")
        for m in modes[:20]:
            add(f"| {m['mode']} | {fmt_t(m['t_start'], log.t_end)} | {m['dur']:.1f} s |")
        add("")

    evs = [e for e in log.events if e.kind != "msg" or e.severity != "info"]
    if evs:
        add("### 关键事件时间线")
        add("")
        add("| 时间 | 类型 | 内容 |")
        add("| --- | --- | --- |")
        for e in evs[:60]:
            add(f"| {fmt_t(e.t, log.t_end)} | {e.kind} | {e.detail.replace('|', '/')} |")
        add("")

    if analysis.tune and (analysis.tune.get("gate") or analysis.tune.get("suggestions")):
        from .tune import render_section as _tune_section

        section("调参体检")
        out.extend(_tune_section(analysis.tune, log))
        fig = analysis.tune.get("figure")
        if fig:
            no = len(figures) + 1 if figures else 1
            cap = analysis.tune.get("figure_caption", "")
            out.append(f"![图 {no}　速率环跟踪]({Path(fig).name})")
            if cap:
                out.append(f"*图 {no}　速率环跟踪：{cap}*")
            out.append("")

    section("检测明细")
    findings = analysis.sorted_findings()
    if not findings:
        add("已执行的检查未发现明显异常。")
        add("")
    for i, f in enumerate(findings, 1):
        add(_finding_block(i, f, log.t_end))
        add("")

    if analysis.skipped:
        section("未执行的检查")
        add("| 检查项 | 原因 |")
        add("| --- | --- |")
        for sk in analysis.skipped:
            add(f"| `{sk.detector}` | {sk.reason.replace('|', '/')} |")
        add("")

    section("规则层建议")
    advices: list[str] = []
    for f in findings:
        a = ADVICE.get(f.id)
        if a and a not in advices:
            advices.append(a)
    if advices:
        for i, a in enumerate(advices, 1):
            add(f"{i}. {a}")
    else:
        add("保持常规检查：桨叶/紧固件/电池健康度/罗盘校准。")
    add("")

    cov = s.get("coverage") or {}
    section("附录")
    params = s.get("params") or {}
    if params:
        add("### 关键参数")
        add("")
        add("| 参数 | 值 |")
        add("| --- | --- |")
        for k in sorted(params):
            add(f"| `{k}` | {params[k]} |")
        add("")
    add("### 数据覆盖")
    add("")
    add("- 可用信号：" + ("、".join(f"`{x}`" for x in s.get("series_present", [])[:40]) or "—"))
    if s.get("missing"):
        add("- 缺失信号：" + "、".join(f"`{x}`" for x in s["missing"]))
    if cov.get("unused"):
        rest = cov.get("unused_total", 0) - len(cov["unused"])
        add(f"- 日志里有、但还没有规则使用的高频消息（共 {cov.get('unused_total', 0)} 种）："
            + "、".join(f"`{m}`({c})" for m, c in cov["unused"][:8])
            + (f"，另有 {rest} 种" if rest > 0 else ""))
        add("  - 这些消息里可能有更细的证据（如 SURF 表面跟踪、XKF 系列估计量）；"
            "需要时可在 `fla/readers` 里加映射，再写一条规则。")
    if log.warnings:
        add("- 解析告警：")
        add("")
        for w in log.warnings[:10]:
            add(f"  - {w}")
    add("")
    add("---")
    add("")
    add("*本报告由 flightlog-autopsy 自动生成。规则层负责事实与阈值判定；"
        + ("叙事章节由大模型基于规则层证据包撰写，不参与事实提取。" if narrative
           else "未启用大模型叙事（离线模式）。加 `--llm` 可生成事故复盘与整改建议。")
        + "*")
    return "\n".join(out)


def write_markdown(analysis: Analysis, out: str | Path, title: str | None = None,
                   narrative: dict | None = None,
                   figures: list | None = None,
                   notes: list[str] | None = None) -> Path:
    p = Path(out)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(render_markdown(analysis, title, narrative, figures, notes),
                 encoding="utf-8")
    return p
