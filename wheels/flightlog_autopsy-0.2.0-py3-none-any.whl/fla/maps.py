"""航迹底图：在线瓦片获取、磁盘缓存与坐标纠偏。

设计取舍：
- 只做"底图"，不做交互地图。报告里要的是一张能印进 PDF/Word 的图，
  所以直接拼成位图交给 matplotlib。
- 瓦片按 z/x/y 缓存在本地，第二次出图不走网络；客户机上没网时返回 None，
  由调用方降级成网格底图（不允许因为没网就没有报告）。
- 高德/腾讯这类国内瓦片用的是 GCJ-02（火星坐标），而飞控记的是 WGS-84，
  直接叠加会整体偏 100–500 m。所以 provider 带 ``gcj`` 标记，
  调用方先 ``wgs2gcj()`` 再算瓦片范围，偏移量随纬度/经度变化，是逐点修正。
"""
from __future__ import annotations

import math
import os
import urllib.request
from dataclasses import dataclass
from pathlib import Path

import numpy as np

__all__ = [
    "TILE", "PROVIDERS", "Provider", "resolve", "wgs2gcj",
    "tile_xy", "tile_bounds", "tiles_for", "choose_zoom",
    "cache_root", "load_tile", "stitch",
]

TILE = 256
_UA = "dsh-flightlog/0.2 (flight log autopsy; tiles cached locally)"


@dataclass(frozen=True)
class Provider:
    key: str
    label: str
    attribution: str
    tpl: str            # {s} 子域 / {x} {y} {z}
    subdomains: tuple[str, ...]
    max_zoom: int
    gcj: bool           # True = 瓦片用 GCJ-02，叠加前必须纠偏


PROVIDERS: dict[str, Provider] = {
    "amap": Provider(
        key="amap",
        label="高德地图",
        attribution="底图 © 高德地图",
        tpl="https://wprd0{s}.is.autonavi.com/appmaptile"
            "?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scl=1&style=7",
        subdomains=("1", "2", "3", "4"),
        max_zoom=19,
        gcj=True,
    ),
    "osm": Provider(
        key="osm",
        label="OpenStreetMap",
        attribution="底图 © OpenStreetMap contributors",
        tpl="https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        subdomains=(),
        max_zoom=19,
        gcj=False,
    ),
}


def resolve(name: str | None) -> Provider | None:
    """``off``/``none``/空 → None（不画底图）。"""
    if not name:
        return None
    key = str(name).strip().lower()
    if key in {"off", "none", "no", "0", "false"}:
        return None
    return PROVIDERS.get(key, PROVIDERS["amap"])


def cache_root() -> Path:
    p = os.environ.get("FLA_TILE_CACHE")
    if p:
        return Path(p)
    base = Path.home() / ".cache"
    return base / "fla-tiles"


# --------------------------------------------------------------------------
# 坐标
# --------------------------------------------------------------------------
_A = 6378245.0
_EE = 0.00669342162296594323


def _tf_lat(x, y):
    r = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * np.sqrt(np.abs(x))
    r += (20.0 * np.sin(6.0 * x * np.pi) + 20.0 * np.sin(2.0 * x * np.pi)) * 2.0 / 3.0
    r += (20.0 * np.sin(y * np.pi) + 40.0 * np.sin(y / 3.0 * np.pi)) * 2.0 / 3.0
    r += (160.0 * np.sin(y / 12.0 * np.pi) + 320.0 * np.sin(y * np.pi / 30.0)) * 2.0 / 3.0
    return r


def _tf_lng(x, y):
    r = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * np.sqrt(np.abs(x))
    r += (20.0 * np.sin(6.0 * x * np.pi) + 20.0 * np.sin(2.0 * x * np.pi)) * 2.0 / 3.0
    r += (20.0 * np.sin(x * np.pi) + 40.0 * np.sin(x / 3.0 * np.pi)) * 2.0 / 3.0
    r += (150.0 * np.sin(x / 12.0 * np.pi) + 300.0 * np.sin(x / 30.0 * np.pi)) * 2.0 / 3.0
    return r


def wgs2gcj(lat, lng):
    """WGS-84 → GCJ-02。支持标量与 numpy 数组，返回同形状。"""
    lat_a = np.asarray(lat, dtype=float)
    lng_a = np.asarray(lng, dtype=float)
    dlat = _tf_lat(lng_a - 105.0, lat_a - 35.0)
    dlng = _tf_lng(lng_a - 105.0, lat_a - 35.0)
    rad = lat_a / 180.0 * np.pi
    magic = 1 - _EE * np.sin(rad) ** 2
    sq = np.sqrt(magic)
    dlat = (dlat * 180.0) / ((_A * (1 - _EE)) / (magic * sq) * np.pi)
    dlng = (dlng * 180.0) / (_A / sq * np.cos(rad) * np.pi)
    out_lat, out_lng = lat_a + dlat, lng_a + dlng
    if np.isscalar(lat) and np.isscalar(lng):
        return float(out_lat), float(out_lng)
    return out_lat, out_lng


def tile_xy(lat: float, lng: float, z: int) -> tuple[int, int]:
    n = 2 ** z
    x = int((lng + 180.0) / 360.0 * n)
    s = math.sin(math.radians(lat))
    y = int((0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n)
    n -= 1
    return max(0, min(n, x)), max(0, min(n, y))


def tile_bounds(z: int, x: int, y: int) -> tuple[float, float, float, float]:
    """返回 (top_lat, bottom_lat, left_lng, right_lng)。"""
    n = 2 ** z

    def lat_of(yy: float) -> float:
        return math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * yy / n))))

    return (lat_of(y), lat_of(y + 1), x / n * 360.0 - 180.0, (x + 1) / n * 360.0 - 180.0)


def tiles_for(lat0: float, lng0: float, lat1: float, lng1: float, z: int):
    """给出覆盖矩形的瓦片范围 (x0, x1, y0, y1)，含端点。"""
    x0, y0 = tile_xy(lat1, lng0, z)      # 左上
    x1, y1 = tile_xy(lat0, lng1, z)      # 右下
    return min(x0, x1), max(x0, x1), min(y0, y1), max(y0, y1)


def choose_zoom(span_m: float, lat: float, target_px: int = 560,
                max_zoom: int = 19, max_tiles: int = 12) -> int:
    """按航迹跨度挑 zoom：目标像素约 target_px，同时限制瓦片数量。"""
    span_m = max(span_m, 1.0)
    coslat = max(math.cos(math.radians(lat)), 1e-6)
    mpp_wanted = span_m / max(target_px, 1)
    z = int(math.floor(math.log2(156543.03392 * coslat / mpp_wanted) + 0.5))
    z = max(2, min(max_zoom, z))
    half_lat = span_m / 2.0 / 110574.0
    half_lng = span_m / 2.0 / (111320.0 * coslat)
    while z > 2:
        x0, x1, y0, y1 = tiles_for(lat - half_lat, -half_lng, lat + half_lat, half_lng, z)
        if (x1 - x0 + 1) * (y1 - y0 + 1) <= max_tiles:
            break
        z -= 1
    return z


# --------------------------------------------------------------------------
# 瓦片
# --------------------------------------------------------------------------
def _tile_path(p: Provider, z: int, x: int, y: int) -> Path:
    return cache_root() / p.key / str(z) / str(x) / f"{y}.png"


def load_tile(p: Provider, z: int, x: int, y: int, timeout: float = 8.0) -> np.ndarray | None:
    """读缓存或下载一张瓦片；失败返回 None（调用方决定是否降级）。"""
    path = _tile_path(p, z, x, y)
    if path.exists() and path.stat().st_size > 512:
        try:
            return _read_png(path)
        except Exception:
            pass
    sub = p.subdomains[(x + y) % len(p.subdomains)] if p.subdomains else ""
    url = p.tpl.format(s=sub, x=x, y=y, z=z)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _UA})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            blob = r.read()
        if len(blob) < 512:
            return None
        arr = _read_png(blob)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
        except OSError:
            pass
        return arr
    except Exception:
        return None


def _read_png(src) -> np.ndarray:
    import io

    from matplotlib.image import imread

    if isinstance(src, Path):
        arr = imread(str(src))
    else:
        arr = imread(io.BytesIO(src), format="png")
    arr = np.asarray(arr, dtype=float)
    if arr.ndim == 2:
        arr = np.dstack([arr] * 3)
    if arr.shape[2] == 4:
        arr = arr[..., :3]
    return arr


def stitch(p: Provider, lat0: float, lng0: float, lat1: float, lng1: float,
           z: int, timeout: float = 8.0):
    """拼一张覆盖矩形（惰性：文件格式为 provider 坐标）的底图。

    返回 ``(img, extent, ok, total)``：img 为 HxWx3 的 float 数组，
    extent 为 matplotlib 的 ``(left, right, bottom, top)``；全部失败返回 ``(None, None, 0, total)``。
    失败位置填浅灰，不至于让整张图作废。
    """
    x0, x1, y0, y1 = tiles_for(lat0, lng0, lat1, lng1, z)
    nx, ny = x1 - x0 + 1, y1 - y0 + 1
    canvas = np.full((ny * TILE, nx * TILE, 3), 0.93)
    ok = 0
    for iy in range(ny):
        for ix in range(nx):
            arr = load_tile(p, z, x0 + ix, y0 + iy, timeout)
            if arr is None:
                continue
            h, w = arr.shape[:2]
            canvas[iy * TILE:iy * TILE + h, ix * TILE:ix * TILE + w] = arr[:TILE, :TILE]
            ok += 1
    if ok == 0:
        return None, None, 0, nx * ny
    top, _, left, _ = tile_bounds(z, x0, y0)
    _, bottom, _, right = tile_bounds(z, x1, y1)
    return canvas, (left, right, bottom, top), ok, nx * ny
