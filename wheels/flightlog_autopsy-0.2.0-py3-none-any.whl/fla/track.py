"""航迹统计：起降位置、范围、航迹长度、事件落点。

只做算术，不出图——图在 ``fla.figures``，文字在 ``fla.report``。
坐标一律保持 WGS-84，纠偏（GCJ-02）只发生在画底图时。
"""
from __future__ import annotations

import numpy as np

from .model import FlightLog

__all__ = ["R_EARTH", "haversine", "track_facts", "position_at"]

R_EARTH = 6371008.8


def haversine(lat1, lng1, lat2, lng2):
    """球面距离（米）。参数可为标量或 numpy 数组，返回同形状。"""
    p1 = np.radians(lat1)
    p2 = np.radians(lat2)
    dp = p2 - p1
    dl = np.radians(lng2) - np.radians(lng1)
    a = np.sin(dp / 2.0) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2.0) ** 2
    out = 2.0 * R_EARTH * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))
    if np.isscalar(lat1) and np.isscalar(lat2):
        return float(out)
    return out


def _series(log: FlightLog, *names):
    for name in names:
        s = log.get(name)
        if s is not None and len(s.y):
            return name, s
    return None, None


def track_facts(log: FlightLog) -> dict | None:
    """航迹事实；没有可用的经纬度就返回 None。"""
    name, s = _series(log, "pos.lat")
    if s is None:
        return None
    name_lng, s_lng = _series(log, "pos.lng")
    if s_lng is None:
        return None

    la = np.asarray(s.y, dtype=float)
    lo = np.asarray(s_lng.y, dtype=float)
    t = np.asarray(s.t, dtype=float)
    n = min(len(la), len(lo), len(t))
    la, lo, t = la[:n], lo[:n], t[:n]
    good = np.isfinite(la) & np.isfinite(lo) & (np.abs(la) > 1e-7) & (np.abs(lo) > 1e-7)
    if good.sum() < 10:
        return None
    la, lo, t = la[good], lo[good], t[good]
    track = getattr(log, "track", None) or {}  # 预留给未来的回放
    del track

    seg = haversine(la[:-1], lo[:-1], la[1:], lo[1:])
    seg = np.where(np.isfinite(seg), seg, 0.0)
    # 相邻点跳变（>2 km/s）多半是定位跳点，不计入航迹长度
    dt = np.diff(t)
    with np.errstate(divide="ignore", invalid="ignore"):
        spd = np.where(dt > 0, seg / np.maximum(dt, 1e-9), 0.0)
    keep = spd < 2000.0
    path_m = float(seg[keep].sum())

    d0 = haversine(la[0], lo[0], la, lo)
    k = int(np.argmax(d0))
    facts = {
        "n": int(n),
        "t0": float(t[0]),
        "t1": float(t[-1]),
        "home": (float(la[0]), float(lo[0]), float(t[0])),
        "end": (float(la[-1]), float(lo[-1]), float(t[-1])),
        "max_range_m": float(d0[k]),
        "max_range_at": (float(la[k]), float(lo[k]), float(t[k])),
        "path_m": path_m,
        "final_offset_m": float(d0[-1]),
        "lat": la,
        "lng": lo,
        "t": t,
    }

    _, alt = _series(log, "alt.rel", "alt.gps", "alt.baro")
    if alt is not None and len(alt.y):
        av = np.asarray(alt.y, dtype=float)
        av = av[np.isfinite(av)]
        if av.size >= 20:
            # 用分位数而不是极值：定位跳变会让相对高度瞬间跳到上百米
            lo, hi = np.percentile(av, [1.0, 99.0])
            facts["alt_min"], facts["alt_max"] = float(lo), float(hi)
        elif av.size:
            facts["alt_min"], facts["alt_max"] = float(av.min()), float(av.max())
    _, gspd = _series(log, "vel.ground", "gps.spd", "spd")
    if gspd is not None and len(gspd.y):
        sv = np.asarray(gspd.y, dtype=float)
        sv = sv[np.isfinite(sv)]
        if sv.size:
            facts["max_speed_ms"] = float(np.nanmax(sv))
    return facts


def position_at(log: FlightLog, t: float) -> tuple[float, float] | None:
    """某个时刻最接近的位置（WGS-84）。"""
    _, s = _series(log, "pos.lat")
    _, sl = _series(log, "pos.lng")
    if s is None or sl is None or not len(s.t):
        return None
    i = int(np.argmin(np.abs(np.asarray(s.t, dtype=float) - float(t))))
    la, lo = float(s.y[i]), float(sl.y[i]) if i < len(sl.y) else float("nan")
    if not np.isfinite(la) or not np.isfinite(lo) or abs(la) < 1e-7:
        return None
    return la, lo
