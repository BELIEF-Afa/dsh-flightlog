"""flightlog-autopsy —— 开源飞控日志事故分析。

层次分明：

* ``fla.readers``  把 .bin / .ulg / .csv 解析成统一的规范信号表；
* ``fla.summary``  只做客观统计（高度、航程、模式时间线…）；
* ``fla.detectors``规则检测，每条规则产出一个可读的 Finding（带证据与判读）；
* ``fla.analyzer`` 汇总、评分、给结论；
* ``fla.report``   离线 Markdown 报告；
* ``fla.llm``      接入 OpenAI 兼容大模型，把证据包写成事故复盘。
"""

__version__ = "0.2.0"

__all__ = ["__version__"]
