"""导航类检测：GPS 质量、EKF 健康、高度一致性、撞地判定。"""
from __future__ import annotations

import numpy as np

from ..model import FlightLog, Finding, fmt_t
from .base import Detector, span

R = 6371000.0


def haversine(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp = p2 - p1
    dl = np.radians(lon2 - lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


class GpsQualityDetector(Detector):
    id = "gps-quality"
    title = "GPS 定位质量"
    category = "导航"
    requires = ("gps.sats",)

    def run(self, log: FlightLog) -> list[Finding]:
        sats = log.get("gps.sats")
        ev: list[str] = []
        sev_ = "info"

        st = sats.stat()
        ev.append(f"卫星数：最少 {st['min']:.0f}，P05 {st['p05']:.0f}，最大 {st['max']:.0f} 颗")
        if st["min"] < 6:
            sev_ = "warn"
        if st["p05"] < 5:
            sev_ = "critical"
        low = sats.below(6.0, min_dur=3.0)
        if low:
            ev.append(f"卫星数 <6 的持续时段：{span([a for a, _ in low], log.t_end)}")

        hdop = log.get("gps.hdop")
        if hdop is not None:
            hs = hdop.stat()
            ev.append(f"HDOP：P95 {hs['p95']:.2f}，最大 {hs['max']:.2f}")
            if hs["p95"] > 2.0:
                sev_ = "warn" if sev_ == "info" else sev_
            if hs["max"] > 5.0:
                sev_ = "critical" if sev_ == "warn" else sev_

        fix = log.get("gps.fix")
        if fix is not None:
            # ArduPilot: 0=无,1=无定位,2=2D,3=3D,4=DGPS,5=RTK浮点,6=RTK固定
            bad = fix.below(3.0, min_dur=2.0)
            if bad:
                sev_ = "critical"
                ev.append(f"定位状态低于 3D 的时段：{span([a for a, _ in bad], log.t_end)}")

        # 位置跳变（GPS 欺骗/多路径）
        lat, lng = log.get("pos.lat"), log.get("pos.lng")
        if lat is not None and lng is not None:
            n = min(len(lat), len(lng))
            d = haversine(lat.y[:n - 1], lng.y[:n - 1], lat.y[1:n], lng.y[1:n])
            dt = np.diff(lat.t[:n])
            with np.errstate(divide="ignore", invalid="ignore"):
                speed = np.where(dt > 1e-6, d / np.maximum(dt, 1e-6), 0.0)
            jumps = np.flatnonzero((d > 80) & (speed > 60))
            if jumps.size:
                sev_ = "critical" if sev_ in ("info", "warn") else sev_
                ev.append(f"检测到 {jumps.size} 次位置跳变（>80m 且等效速度 >60m/s），"
                          f"例如 {fmt_t(float(lat.t[jumps[0]]), log.t_end)}")

        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_, evidence=ev,
                        conclusion=("GPS 定位质量在飞行中下降/丢失。多旋翼在 GPS 模式依赖它维持位置，"
                                    "丢星会触发 EKF 位置发散 → 姿态/位置失控或自动切换模式。"),
                        confidence=0.75, refs=["GPS"])]


class EkfHealthDetector(Detector):
    id = "ekf-health"
    title = "EKF 状态估计健康度"
    category = "导航"
    requires = ()

    def run(self, log: FlightLog) -> list[Finding]:
        ev: list[str] = []
        sev_ = "info"
        t_bad = None
        for name, warn, crit, label in (
            ("ekf.ipn", 1.0, 2.5, "位置新息方差(北)"),
            ("ekf.ipe", 1.0, 2.5, "位置新息方差(东)"),
            ("ekf.ivn", 3.0, 6.0, "速度新息(北)"),
            ("ekf.ive", 3.0, 6.0, "速度新息(东)"),
        ):
            s = log.get(name)
            if s is None:
                continue
            st = s.stat()
            ev.append(f"{label} {name}：P95 {st['p95']:.2f}，最大 {st['max']:.2f}")
            if st["p95"] >= crit:
                sev_ = "critical"
            elif st["p95"] >= warn and sev_ == "info":
                sev_ = "warn"
            if st["max"] >= warn and t_bad is None:
                t_bad = st["argmax_t"]

        # 直接由 ERR/EV 记录的 EKF 失控保护
        ekf_fs = [e for e in log.events if e.kind in ("failsafe", "error")
                  and ("EKF" in e.detail.upper() or "ekf" in e.detail)]
        if ekf_fs:
            sev_ = "critical"
            ev.append("飞控日志中的 EKF 相关事件：" + "；".join(e.detail for e in ekf_fs[:4]))
            t_bad = ekf_fs[0].t if t_bad is None else t_bad

        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_, t_start=t_bad, t_end=t_bad,
                        evidence=ev,
                        conclusion=("EKF 的新息/方差超出正常范围，说明滤波器对自身状态失去信心。"
                                    "常见根因是振动过大、罗盘干扰、GPS 跳变或 IMU 故障；"
                                    "持续超限会触发 EKF 失效保护并切换/降落。"),
                        confidence=0.7, refs=["NKF1", "NKF3", "XKF4", "ERR"])]


class AltitudeConsistencyDetector(Detector):
    id = "altitude-consistency"
    title = "气压高度与 GPS 高度一致性"
    category = "导航"
    requires = ("alt.baro",)

    def run(self, log: FlightLog) -> list[Finding]:
        baro = log.get("alt.baro")
        gps = log.get("alt.gps")
        rel = log.get("alt.rel")
        ev = []
        sev_ = "info"

        if gps is not None:
            t0, t1 = max(baro.t0, gps.t0), min(baro.t1, gps.t1)
            if t1 - t0 > 10:
                grid = np.arange(t0, t1, 1.0)
                b = baro.interp(grid)
                g = gps.interp(grid)
                off = np.median(b - g)
                d = np.abs((b - g) - off)
                mx = float(np.max(d))
                ev.append(f"气压/GPS 高度差（去常值偏置后）：最大 {mx:.1f} m，P95 {np.percentile(d, 95):.1f} m")
                if mx > 15:
                    sev_ = "warn"
                if mx > 40:
                    sev_ = "critical"

        if rel is not None:
            st = rel.stat()
            ev.append(f"相对高度：最大 {st['max']:.1f} m，末值 {st['last']:.1f} m")

        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_, evidence=ev,
                        conclusion=("气压高度与 GPS 高度出现明显分歧，可能是气压计进气孔被遮挡/进水、"
                                    "大风导致气压波动，或 GPS 高度本身不可信；定高/降落会受影响。"),
                        confidence=0.6, refs=["BARO", "GPS"])]


class ImpactDetector(Detector):
    """撞地/坠机判定：末端过载 + 高度骤降 + 上锁时机。"""

    id = "impact"
    title = "撞地 / 坠机判定"
    category = "事故"
    requires = ()
    scope = "full"

    def run(self, log: FlightLog) -> list[Finding]:
        t_end = log.t_end
        flight_end = log.flight_end
        ev: list[str] = []
        sev_ = "info"
        t_hit = None

        acc = log.get("acc.mag")
        if acc is not None:
            # 只看解锁时段内的过载
            mask = np.zeros(acc.t.shape, dtype=bool)
            for a, b in log.armed_intervals():
                mask |= (acc.t >= a) & (acc.t <= b)
            if np.any(mask):
                sub = acc.y[mask]
                sub_t = acc.t[mask]
                peak = float(np.max(sub))
                i = int(np.argmax(sub))
                t_hit = float(sub_t[i])
                ev.append(f"机体过载峰值 {peak:.1f} m/s²（≈{peak / 9.81:.1f} g），出现在 {fmt_t(t_hit, t_end)}")
                if peak >= 60:
                    sev_ = "critical"
                elif peak >= 35:
                    sev_ = "warn"

        vz = log.get("vel.vert")
        if vz is not None:
            mask = np.zeros(vz.t.shape, dtype=bool)
            for a, b in log.armed_intervals():
                mask |= (vz.t >= a) & (vz.t <= b)
            if np.any(mask):
                sub = vz.y[mask]
                sub_t = vz.t[mask]
                # 撞击瞬间 EKF 速度会出现 ±1000 m/s 级跳变，剔除后再取极值
                ok = np.abs(sub) <= 60
                if np.any(ok):
                    sub, sub_t = sub[ok], sub_t[ok]
                desc = float(np.min(sub))
                i = int(np.argmin(sub))
                ev.append(f"最大下降率 {desc:.1f} m/s（{fmt_t(float(sub_t[i]), t_end)}）")
                if desc <= -10:
                    sev_ = "critical"
                elif desc <= -5 and sev_ == "info":
                    sev_ = "warn"

        alt = log.get("alt.rel")
        if alt is not None and len(alt):
            max_alt = float(np.max(alt.y))
            last_alt = float(alt.y[-1])
            ev.append(f"最大相对高度 {max_alt:.1f} m，日志结束高度 {last_alt:.1f} m")
            # 未记录着陆事件、仍在解锁状态就贴地 => 非正常触地
            landed = log.last_event("land")
            still_armed = bool(log.events_of("arm")) and not log.events_of("disarm")
            if max_alt > 10 and last_alt < 3 and (landed is None or landed.t < flight_end - 5):
                sev_ = "critical"
                ev.append("日志结束时高度已贴近地面且没有正常着陆记录")

        if sev_ == "info":
            return []
        concl = ("检测到高过载/高下降率，机体在日志末端经历了一次非正常触地。"
                 if sev_ == "critical" else
                 "末端下降率偏大，存在重着陆风险。")
        return [Finding(self.id, self.title, self.category, sev_, t_start=t_hit, t_end=t_hit,
                        evidence=ev, conclusion=concl, confidence=0.8,
                        refs=["IMU.AccZ", "CTUN.CRt", "POS.RelHomeAlt"])]
