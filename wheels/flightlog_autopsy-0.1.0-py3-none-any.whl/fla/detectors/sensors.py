"""传感器类检测：振动、IMU 一致性、罗盘。

阈值依据（ArduPilot 官方调参文档）：
* VIBE 的 VibeX/Y/Z 是各轴加速度的"振动幅度"指标，官方给的判读是
  **> 30 m/s² 有问题，> 60 m/s² 不建议起飞**；
* Clip0/1/2 是 IMU 削顶累计计数，飞行中持续增长说明振动已经让加速度计"打顶"，
  此时姿态估计会被污染；
* 磁场强度应在 250–650 mGauss（25–65 µT），偏离说明罗盘受干扰或校准错误。
"""
from __future__ import annotations

import numpy as np

from ..model import FlightLog, Finding
from .base import Detector, family, fmt_num, merge_sev, sev, span

VIBE_WARN = 30.0
VIBE_CRIT = 60.0
VIBE_PEAK_CRIT = 90.0
CLIP_WARN = 100
CLIP_CRIT = 1000


class VibrationDetector(Detector):
    id = "vibration"
    title = "机体振动 / IMU 削顶"
    category = "机械"
    requires = ("vibe.x",)

    def run(self, log: FlightLog) -> list[Finding]:
        axes = {"X": family(log, "vibe.x"), "Y": family(log, "vibe.y"), "Z": family(log, "vibe.z")}
        ev: list[str] = []
        worst_p95 = 0.0
        worst_peak = 0.0
        worst_axis = "—"
        for ax, fams in axes.items():
            for s in fams:
                st = s.stat()
                if not st.get("n"):
                    continue
                p95 = st["p95"]
                pk = st["max"]
                if p95 > worst_p95:
                    worst_p95, worst_axis = p95, ax
                worst_peak = max(worst_peak, pk)
                suffix = s.name.split("#")[1] if "#" in s.name else "0"
                ev.append(f"Vibe{ax}(IMU{suffix}): P95 {p95:.1f} / 峰值 {pk:.1f} m/s²")

        # 削顶计数增量
        clip_total = 0
        clip_detail = []
        for key in [k for k in log.series if k.startswith("vibe.clip")]:
            s = log.get(key)
            if s is None or len(s) < 2:
                continue
            d = float(s.y[-1] - s.y[0])
            clip_total += max(d, 0)
            clip_detail.append(f"{key} +{d:.0f}")
        if clip_detail:
            ev.append("削顶计数增量：" + "，".join(clip_detail))

        # 严重度以 P95 为主（官方判据是"持续振动幅度"）；单次尖峰只作证据
        severity = merge_sev(
            sev(worst_p95, VIBE_WARN, VIBE_CRIT),
            "warn" if worst_peak >= VIBE_PEAK_CRIT else "info",
            sev(clip_total, CLIP_WARN, CLIP_CRIT),
        )
        if severity == "info":
            return []

        if severity == "critical":
            concl = (f"{worst_axis} 轴振动 P95 达 {worst_p95:.0f} m/s²、峰值 {worst_peak:.0f} m/s²，"
                     "已进入 ArduPilot 明确不建议起飞的区间，姿态估计随时可能被振动污染。")
        else:
            concl = (f"{worst_axis} 轴振动 P95 {worst_p95:.0f} m/s² 超过 30 m/s² 的告警线，"
                     "属于需要停机检查的振动水平。")

        # 振动在时间上的分布（找出恶化时刻）
        pk_series = log.get("vibe.pk")
        t_peak = None
        if pk_series is not None:
            i = int(np.argmax(pk_series.y))
            t_peak = float(pk_series.t[i])
        if t_peak is not None:
            concl += f" 峰值出现在 {log_fmt(t_peak, log.t_end)}。"
        return [Finding(self.id, self.title, self.category, severity,
                        t_start=t_peak, t_end=t_peak, evidence=ev, conclusion=concl,
                        confidence=0.85, refs=["VIBE", "IMU"])]


class ImuConsistencyDetector(Detector):
    id = "imu-consistency"
    title = "IMU 之间的角速度不一致"
    category = "机械"
    requires = ("gyro.x", "gyro.x#1")

    def run(self, log: FlightLog) -> list[Finding]:
        a, b = log.get("gyro.x"), log.get("gyro.x#1")
        t0 = max(a.t0, b.t0)
        t1 = min(a.t1, b.t1)
        if t1 - t0 < 5:
            return []
        grid = np.arange(t0, t1, 0.1)
        d = a.interp(grid) - b.interp(grid)
        rms = float(np.sqrt(np.mean(d ** 2)))
        p95 = float(np.percentile(np.abs(d), 95))
        severity = sev(p95, 0.30, 0.80)
        if severity == "info":
            return []
        # 找出偏差最大的时段
        win = int(2.0 / 0.1)
        if d.size > win:
            k = np.convolve(np.abs(d), np.ones(win) / win, mode="valid")
            i = int(np.argmax(k))
            t_bad = float(grid[i])
        else:
            t_bad = float(grid[int(np.argmax(np.abs(d)))])
        return [Finding(
            self.id, self.title, self.category, severity,
            t_start=t_bad, t_end=t_bad,
            evidence=[f"IMU0 与 IMU1 的 X 轴角速度差：RMS {rms:.3f} rad/s，P95 {p95:.3f} rad/s",
                      f"偏差最大时刻 {log_fmt(t_bad, log.t_end)}"],
            conclusion=("两个 IMU 的角速度读数出现持续偏差，通常是其中一个 IMU 松动、"
                        "减震失效或本身故障；飞控若正在使用坏的那个 IMU，姿态会跟着漂。"),
            confidence=0.7, refs=["IMU", "IMU2"])]


class CompassDetector(Detector):
    id = "compass"
    title = "罗盘干扰 / 磁场异常"
    category = "导航"
    requires = ("mag.strength",)

    def run(self, log: FlightLog) -> list[Finding]:
        s = log.get("mag.strength")
        st = s.stat()
        if not st.get("n"):
            return []
        lo, hi = st["p05"], st["p95"]
        # 变化率（mGauss/s）
        dt = np.diff(s.t)
        dy = np.diff(s.y)
        rate = np.divide(dy, dt, out=np.zeros_like(dy), where=dt > 1e-6)
        max_rate = float(np.max(np.abs(rate))) if rate.size else 0.0

        ev = [f"磁场强度 P05/P95：{lo:.0f} / {hi:.0f} mGauss（地球正常范围约 250–650）",
              f"最大变化率：{max_rate:.0f} mGauss/s"]
        sev_ = merge_sev(
            "warn" if (lo < 180 or hi > 800) else "info",
            "critical" if (lo < 100 or hi > 1200) else "info",
            sev(max_rate, 300, 800),
        )
        if sev_ == "info":
            return []
        tb = float(s.t[int(np.argmax(np.abs(rate)))]) if rate.size else None
        return [Finding(self.id, self.title, self.category, sev_, t_start=tb, t_end=tb,
                        evidence=ev,
                        conclusion=("磁场强度或变化率异常，典型原因是动力线/电调离罗盘太近、"
                                    "磁干扰源随油门变化，会导致航向漂移、自动模式跑偏。"),
                        confidence=0.7, refs=["MAG"])]


def log_fmt(t: float, t_end: float) -> str:
    from ..model import fmt_t

    return fmt_t(t, t_end)
