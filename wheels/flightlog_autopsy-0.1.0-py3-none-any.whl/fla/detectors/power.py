"""动力/电气/通信类检测：电池、执行器饱和、遥控链路、飞控负载、失控保护序列。"""
from __future__ import annotations

import numpy as np

from ..model import FlightLog, Finding, fmt_t
from .base import Detector, sev, span

CELL_FULL_V = 4.2
CELL_WARN_V = 3.5
CELL_CRIT_V = 3.3


def _cell_count(log: FlightLog, vmax: float) -> int:
    """从满电电压与参数里推断电芯串数。"""
    for k, v in log.params.items():
        ku = k.upper()
        if ku.endswith("N_CELLS") or ku.endswith("CELLS"):
            try:
                n = int(float(v))
                if 1 <= n <= 14:
                    return n
            except Exception:
                pass
    if vmax <= 0:
        return 1
    n = int(round(vmax / CELL_FULL_V))
    return max(1, min(n, 14))


class BatteryDetector(Detector):
    id = "battery"
    title = "电池电压 / 电流"
    category = "电气"
    requires = ("bat.volt",)

    def run(self, log: FlightLog) -> list[Finding]:
        v = log.get("bat.volt")
        st = v.stat()
        if not st.get("n"):
            return []
        cells = _cell_count(log, st["max"])
        per_cell_min = st["min"] / cells
        per_cell_max = st["max"] / cells

        # 电压下降速率
        dt = np.diff(v.t)
        dv = np.diff(v.y)
        rate = np.divide(dv, dt, out=np.zeros_like(dv), where=dt > 1e-6)
        min_rate = float(np.min(rate)) if rate.size else 0.0

        ev = [f"电压：最高 {st['max']:.2f} V，最低 {st['min']:.2f} V（推断 {cells}S，"
              f"单芯 {per_cell_min:.2f}–{per_cell_max:.2f} V）",
              f"电压最低点出现在 {fmt_t(st['argmin_t'], log.t_end)}"]
        sev_ = sev(per_cell_min, CELL_WARN_V, CELL_CRIT_V, higher_is_worse=False)
        ev.append(f"最大电压下降速率：{min_rate:.2f} V/s"
                  + ("（瞬时压降，通常由大电流机动引起）" if min_rate <= -1.5 else ""))
        # 电压瞬时压降本身不足以判定电池故障，只在单芯电压已经偏低时升级严重度
        if min_rate <= -3.0 and sev_ != "info":
            sev_ = "critical" if sev_ == "warn" and per_cell_min < CELL_WARN_V else sev_
        elif min_rate <= -1.5 and sev_ == "info" and per_cell_min < 3.7:
            sev_ = "warn"

        pct = log.get("bat.pct")
        if pct is not None and len(pct):
            first = float(pct.y[0])
            last = float(pct.y[-1])
            ev.append(f"电量估计：起飞时 {first:.0f}%，结束时 {last:.0f}%")
            if first < 70 and sev_ == "info":
                sev_ = "warn"
                ev.append("起飞时电量已不足 70%，动力余量偏小")

        cur = log.get("bat.curr")
        if cur is not None:
            cs = cur.stat()
            ev.append(f"电流：最大 {cs['max']:.1f} A，平均 {cs['mean']:.1f} A")

        if sev_ == "info":
            return []
        concl = ("电池电压已跌到单芯 3.3 V 以下的危险区间，电调/飞控可能欠压复位（brownout），"
                 "动力输出会突然衰减。" if per_cell_min < CELL_CRIT_V else
                 "电池电压偏低或下降过快，续航/动力余量不足，重载机动时容易触发低压保护。")
        return [Finding(self.id, self.title, self.category, sev_,
                        t_start=st["argmin_t"], t_end=st["argmin_t"],
                        evidence=ev, conclusion=concl, confidence=0.8, refs=["BAT"])]


class ActuatorSaturationDetector(Detector):
    id = "actuator-saturation"
    title = "执行器输出饱和"
    category = "动力"
    requires = ("out.pwm",)

    def run(self, log: FlightLog) -> list[Finding]:
        chan = {k: s for k, s in log.series.items() if k.startswith("out.c")}
        if not chan:
            return []
        allmax = max(float(np.max(s.y)) for s in chan.values())
        normalized = allmax <= 1.5
        hi = 0.97 if normalized else 1950.0
        unit = "" if normalized else " us"

        ev = []
        sev_ = "info"
        saturated = 0
        worst_dur = 0.0
        for name, s in sorted(chan.items()):
            runs = s.above(hi, min_dur=1.5)
            dur = sum(b - a for a, b in runs)
            if dur > 0:
                saturated += 1
                worst_dur = max(worst_dur, max(b - a for a, b in runs))
                ev.append(f"{name.upper()}：最高 {float(np.max(s.y)):.2f}{unit}，"
                          f"接近满量程累计 {dur:.1f}s")
            else:
                ev.append(f"{name.upper()}：最高 {float(np.max(s.y)):.2f}{unit}")

        if saturated >= 1:
            sev_ = "warn"
        if saturated >= 2 or worst_dur >= 5:
            sev_ = "critical"

        # 末端（最后 5 秒）是否仍在打满
        agg = log.get("out.pwm")
        tail = agg.window(max(log.flight_end - 5, 0), log.flight_end) if agg is not None else None
        if tail is not None and len(tail) and float(np.max(tail.y)) >= hi:
            ev.append("日志末端 5 秒内仍有通道处于满量程")

        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_, evidence=ev,
                        conclusion=("一个或多个执行器长时间顶在满量程，说明动力/控制余量耗尽："
                                    "可能是电池衰减、桨叶损坏、电机失效或重心严重偏移，"
                                    "此时飞控已无法再通过增大差动来纠正姿态。"),
                        confidence=0.75, refs=["RCOU"])]


class RcLinkDetector(Detector):
    id = "rc-link"
    title = "遥控链路 / 失控保护"
    category = "通信"
    requires = ()

    def run(self, log: FlightLog) -> list[Finding]:
        ev: list[str] = []
        sev_ = "info"
        failsafe_events = []
        for e in log.events:
            txt = e.detail.upper()
            if e.kind == "failsafe" and ("RADIO" in txt or "RC" in txt or "遥控" in txt):
                failsafe_events.append(e)
        if failsafe_events:
            sev_ = "critical"
            ev += [f"{fmt_t(e.t, log.t_end)} {e.detail}" for e in failsafe_events[:5]]

        thr = log.get("rc.thr")
        if thr is not None:
            st = thr.stat()
            ev.append(f"遥控油门输入：最小 {st['min']:.0f} us、最大 {st['max']:.0f} us")
            if st["max"] <= 900:
                sev_ = "critical" if sev_ == "info" else sev_
                ev.append("整个日志中油门通道没有有效输入（持续低于 900us）")

        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_,
                        t_start=failsafe_events[0].t if failsafe_events else None,
                        evidence=ev,
                        conclusion=("遥控链路出现失效保护。多旋翼进入失控保护后会按配置执行"
                                    "悬停/返航/降落；如果同时伴随定位丢失，返航会指向错误方向。"),
                        confidence=0.65, refs=["RCIN", "ERR"])]


class SystemLoadDetector(Detector):
    id = "system-load"
    title = "飞控 CPU / 主循环负载"
    category = "电气"
    requires = ()

    def run(self, log: FlightLog) -> list[Finding]:
        ev, sev_ = [], "info"
        cpu = log.get("cpu.load")
        if cpu is not None:
            st = cpu.stat()
            ev.append(f"CPU 负载：P95 {st['p95']:.0f}%，最大 {st['max']:.0f}%")
            if st["p95"] > 90:
                sev_ = "critical"
            elif st["p95"] > 75 or st["max"] > 98:
                sev_ = "warn"
        loop = log.get("loop.max")
        if loop is not None:
            st = loop.stat()
            ev.append(f"主循环耗时：P95 {st['p95']:.1f} ms，最大 {st['max']:.1f} ms")
            # 主循环周期在 400 Hz 下是 2.5 ms；P95 超过 5 ms 说明已经在丢周期
            if st["p95"] > 8 or st["max"] > 100:
                sev_ = "critical"
            elif st["p95"] > 4 or st["max"] > 25:
                sev_ = "warn" if sev_ == "info" else sev_
        if sev_ == "info":
            return []
        return [Finding(self.id, self.title, self.category, sev_, evidence=ev,
                        conclusion=("飞控负载过高/主循环超时会导致控制周期抖动，"
                                    "严重时触发看门狗复位（日志会在这里断开）。"),
                        confidence=0.6, refs=["PM"])]


class FailsafeSequenceDetector(Detector):
    """把失控保护/错误事件按时间串起来——事故报告里最有用的一段叙述。"""

    id = "failsafe-sequence"
    title = "失控保护与错误事件序列"
    category = "通信"
    requires = ()
    scope = "full"

    def run(self, log: FlightLog) -> list[Finding]:
        evs = [e for e in log.events if e.kind in ("failsafe", "error", "impact")]
        if not evs:
            return []
        evs.sort(key=lambda e: e.t)
        crit = [e for e in evs if e.severity == "critical"]
        severity = "critical" if crit else "warn"
        evidence = [f"{fmt_t(e.t, log.t_end)} [{e.severity}] {e.detail}" for e in evs[:8]]
        if len(evs) > 8:
            evidence.append(f"……另有 {len(evs) - 8} 条")
        return [Finding(self.id, self.title, self.category, severity,
                        t_start=evs[0].t, t_end=evs[-1].t, evidence=evidence,
                        conclusion=("上述事件按时间排列，构成事故的触发链；"
                                    "报告会据此判断哪一环是直接诱因、哪一环是结果。"),
                        confidence=0.7, refs=["ERR", "EV", "MSG"])]
