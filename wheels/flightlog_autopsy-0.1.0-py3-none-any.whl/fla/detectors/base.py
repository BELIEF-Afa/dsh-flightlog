"""检测器基类与公共工具。"""
from __future__ import annotations

from typing import Iterable

import numpy as np

from ..model import FlightLog, Finding, Series


class Detector:
    """一条规则。

    子类用**类属性**声明元信息（``id`` / ``title`` / ``category`` / ``requires`` /
    ``note``），实例化时可直接 ``MyDetector()``；也可以 ``MyDetector(title="改名")``
    覆盖个别字段。
    """

    id: str = ""
    title: str = ""
    category: str = "其它"
    requires: tuple[str, ...] = ()
    note: str = ""
    #: "quality" = 只统计到事故触发点之前；"full" = 看完整段日志（用于坠机结构证据）
    scope: str = "quality"

    def __init__(self, **overrides: object) -> None:
        for k, v in overrides.items():
            setattr(self, k, v)

    def available(self, log: FlightLog) -> str | None:
        """不可用时返回原因（会写进报告的"未执行的检查"）。"""
        missing = [r for r in self.requires if not log.has(r)]
        if missing:
            return "缺少信号：" + "、".join(missing)
        return None

    def run(self, log: FlightLog) -> list[Finding]:  # pragma: no cover - 抽象
        raise NotImplementedError

    def __repr__(self) -> str:
        return f"<{type(self).__name__} id={self.id!r}>"

# --------------------------------------------------------------------------- #
# 工具
# --------------------------------------------------------------------------- #
def sev(value: float, warn: float, crit: float, higher_is_worse: bool = True) -> str:
    if higher_is_worse:
        if value >= crit:
            return "critical"
        if value >= warn:
            return "warn"
    else:
        if value <= crit:
            return "critical"
        if value <= warn:
            return "warn"
    return "info"


def merge_sev(*sevs: str) -> str:
    order = {"critical": 0, "warn": 1, "info": 2, "unknown": 3}
    return min(sevs, key=lambda s: order.get(s, 3)) if sevs else "info"


def family(log: FlightLog, base: str) -> list[Series]:
    return log.family(base)


def best_window(series_list: Iterable[Series], t0: float, t1: float) -> float:
    """多个实例在 [t0,t1] 内的最大绝对值（用于"最差 IMU"）。"""
    vals = [s.window(t0, t1).stat().get("max_abs", 0.0) for s in series_list if len(s)]
    return float(max(vals)) if vals else 0.0


def fmt_num(v: float | None, unit: str = "", nd: int = 1) -> str:
    if v is None or not np.isfinite(v):
        return "—"
    s = f"{v:.{nd}f}"
    return f"{s} {unit}".strip()


def span(ts: list[float], t_end: float, limit: int = 3) -> str:
    """把一串时间点格式化成 "T+01:23.4、T+02:10.0 等 5 处"。"""
    from ..model import fmt_t

    if not ts:
        return "全段"
    uniq = sorted(set(round(float(t), 1) for t in ts))
    head = "、".join(fmt_t(t, t_end) for t in uniq[:limit])
    if len(uniq) > limit:
        head += f" 等 {len(uniq)} 处"
    return head


def ratio(v: float, total: float) -> float:
    return float(v / total) if total else 0.0
