"""内置检测器注册表。

顺序即报告中的展示顺序（同类归并前）；新增检测器只需在此登记。
"""
from __future__ import annotations

from . import attitude, nav, phase, power, sensors
from .base import Detector

DEFAULT_DETECTORS: list[Detector] = [
    # 飞行阶段 / 动力链
    phase.TruncatedLogDetector(),
    phase.ThrustLossDetector(),
    phase.EstopDetector(),
    phase.ModeSwitchDetector(),
    # 机械与传感器
    sensors.VibrationDetector(),
    sensors.ImuConsistencyDetector(),
    sensors.CompassDetector(),
    # 姿态控制
    attitude.AttitudeTrackingDetector(),
    attitude.FlipDetector(),
    attitude.OscillationDetector(),
    # 导航与估计
    nav.GpsQualityDetector(),
    nav.EkfHealthDetector(),
    nav.AltitudeConsistencyDetector(),
    nav.ImpactDetector(),
    # 电气与通信
    power.BatteryDetector(),
    power.ActuatorSaturationDetector(),
    power.RcLinkDetector(),
    power.SystemLoadDetector(),
    power.FailsafeSequenceDetector(),
]
