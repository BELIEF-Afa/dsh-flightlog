"""姿态类检测：跟踪误差、翻转、振荡。"""
from __future__ import annotations

import numpy as np

from ..model import FlightLog, Finding, fmt_t, moving_average
from .base import Detector, merge_sev, sev


def _armed(log: FlightLog, t: np.ndarray) -> np.ndarray:
    mask = np.zeros(t.shape, dtype=bool)
    for a, b in log.armed_intervals():
        mask |= (t >= a) & (t <= b)
    return mask


class AttitudeTrackingDetector(Detector):
    """实际姿态 vs 期望姿态的偏离——"飞控想压 20°，机体压不动"就是控制失效。"""

    id = "attitude-tracking"
    title = "姿态跟踪误差"
    category = "姿态"
    requires = ("att.roll",)

    def run(self, log: FlightLog) -> list[Finding]:
        err = log.get("att.err_rp")
        source = "ATT.ErrRP"
        if err is None:
            roll, pitch = log.get("att.roll"), log.get("att.pitch")
            dr, dp = log.get("att.des_roll"), log.get("att.des_pitch")
            if roll is None or dr is None:
                return []
            n = min(len(roll), len(dr))
            e_roll = np.abs(roll.y[:n] - dr.y[:n])
            if pitch is not None and dp is not None:
                m = min(n, len(pitch), len(dp))
                e = np.sqrt(e_roll[:m] ** 2 + (pitch.y[:m] - dp.y[:m]) ** 2)
            else:
                e = e_roll
            err = None
            t = roll.t[: e.size]
            e_series = e
            source = "ATT.Roll-DesRoll"
        else:
            t = err.t
            e_series = np.abs(err.y)

        ok = _armed(log, t)
        if not np.any(ok):
            return []
        e = e_series[ok]
        t_ok = t[ok]
        p95 = float(np.percentile(e, 95))
        mx = float(np.max(e))
        severity = merge_sev(sev(p95, 15.0, 30.0), "critical" if mx >= 55 else "info")
        if severity == "info":
            return []

        over = e > 25.0
        runs = 0
        longest = 0.0
        cur = 0.0
        prev = None
        for ti, flag in zip(t_ok, over):
            if flag:
                if prev is not None:
                    cur += ti - prev
                runs += 1
            else:
                longest = max(longest, cur)
                cur = 0.0
            prev = ti
        longest = max(longest, cur)
        t_worst = float(t_ok[int(np.argmax(e))])

        ev = [f"跟踪误差（{source}）：P95 {p95:.1f}°，最大 {mx:.1f}°",
              f"误差 >25° 的时长合计 {longest:.1f}s，最差时刻 {fmt_t(t_worst, log.t_end)}"]
        concl = ("实际姿态长期跟不上期望姿态，说明控制权限不足：可能是电机/桨失效、"
                 "重心偏移、舵机卡死或振动让姿态估计失真。")
        return [Finding(self.id, self.title, self.category, severity,
                        t_start=t_worst, t_end=t_worst, evidence=ev, conclusion=concl,
                        confidence=0.75, refs=["ATT"])]


class FlipDetector(Detector):
    """机体倾角超过 60°，基本等同于翻转/失控。"""

    id = "flip"
    title = "机体大角度倾斜（翻转迹象）"
    category = "姿态"
    requires = ("att.roll", "att.pitch")
    scope = "full"
    note = "倾角 >60° 且持续 ≥0.8 s 判为翻转"

    def run(self, log: FlightLog) -> list[Finding]:
        roll, pitch = log.get("att.roll"), log.get("att.pitch")
        t0 = max(roll.t0, pitch.t0)
        t1 = min(roll.t1, pitch.t1)
        if t1 - t0 < 0.5:
            return []
        grid = np.arange(t0, t1, 0.2)
        r = roll.interp(grid)
        p = pitch.interp(grid)
        tilt = np.sqrt(r ** 2 + p ** 2)
        ok = _armed(log, grid)
        if np.any(ok):
            tilt, grid = tilt[ok], grid[ok]
        over = tilt > 60.0
        if not np.any(over):
            return []
        idx = np.flatnonzero(over)
        t_first = float(grid[idx[0]])
        t_last = float(grid[idx[-1]])
        dur = float(t_last - t_first)
        severity = "critical" if dur >= 0.8 else "warn"
        return [Finding(self.id, self.title, self.category, severity,
                        t_start=t_first, t_end=t_last,
                        evidence=[f"最大倾角 {float(np.max(tilt)):.1f}°",
                                  f"倾角 >60° 持续约 {dur:.1f}s（{fmt_t(t_first, log.t_end)} 起）"],
                        conclusion=("机体倾角超过 60°，已超出正常可控飞行范围，"
                                    "通常对应翻转、撞桨或结构失效；结合末端数据可判断坠机形态。"),
                        confidence=0.8, refs=["ATT"])]


class OscillationDetector(Detector):
    """周期性振荡：桨叶不平衡、PID 过冲、机架共振。"""

    id = "oscillation"
    title = "姿态/角速度周期性振荡"
    category = "姿态"
    requires = ("gyro.x",)

    def run(self, log: FlightLog) -> list[Finding]:
        best = None
        for name in ("gyro.x", "gyro.y", "gyro.z"):
            fams = log.family(name)
            for s in fams[:1]:
                if len(s) < 256:
                    continue
                # 只统计解锁后、且机体已经在动的片段
                ok = _armed(log, s.t)
                if np.count_nonzero(ok) < 256:
                    continue
                y = s.y[ok]
                t = s.t[ok]
                # 去掉慢变成分，看 5Hz 以上
                hp = y - moving_average(y, 25)
                amp = float(np.sqrt(np.mean(hp ** 2)))
                if amp < 0.15:  # rad/s，太小的抖动没有诊断意义
                    continue
                n = min(len(t), 4096)
                freq, ratio_pk = _dominant(t[:n], hp[:n])
                score = amp * ratio_pk
                if best is None or score > best[0]:
                    best = (score, name, freq, ratio_pk, amp, float(np.max(np.abs(hp))))
        if best is None:
            return []
        score, name, freq, ratio_pk, amp, pk = best
        if not (8.0 <= freq <= 160.0) or ratio_pk < 0.12:
            return []
        severity = sev(amp, 0.8, 2.0)
        if severity == "info":
            return []
        axis = name.split(".")[1].upper()
        return [Finding(self.id, self.title, self.category, severity,
                        evidence=[f"{axis} 轴角速度高频分量 RMS {amp:.2f} rad/s，峰值 {pk:.2f} rad/s",
                                  f"主频约 {freq:.1f} Hz（能量占比 {ratio_pk * 100:.0f}%）"],
                        conclusion=(f"存在约 {freq:.0f} Hz 的周期性振荡，常见原因是桨叶不平衡/桨距不一致、"
                                    "机架或电机松动、PID 增益过高；持续振荡会放大振动并拖垮姿态控制。"),
                        confidence=0.6, refs=[name])]


def _dominant(t: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    dt = float(np.median(np.diff(t)))
    if dt <= 0:
        return 0.0, 0.0
    n = y.size
    spec = np.abs(np.fft.rfft(y * np.hanning(n)))
    freqs = np.fft.rfftfreq(n, d=dt)
    band = (freqs >= 5) & (freqs <= 250)
    if not np.any(band):
        return 0.0, 0.0
    sub = spec[band]
    i = int(np.argmax(sub))
    total = float(np.sum(sub) + 1e-12)
    return float(freqs[band][i]), float(sub[i] / total)
