"""飞行阶段类检测：中断的飞行、推力损失、电机急停。

这三条是"事故复盘"最直接的结构性证据，优先级最高：
它们不依赖阈值，只看**事情有没有发生**。
"""
from __future__ import annotations

import re

import numpy as np

from ..model import FlightLog, Finding, fmt_t
from .base import Detector, merge_sev


def _alt_at(log: FlightLog, t: float) -> float | None:
    for name in ("alt.rel", "alt.ctun", "alt.baro", "alt.gps"):
        s = log.get(name)
        if s is not None:
            return s.at(t)
    return None


class TruncatedLogDetector(Detector):
    """日志在飞行中结束：没有 disarm、没有着陆、最后还有高度。"""

    id = "truncated-log"
    title = "日志在飞行中中断"
    category = "其它"
    requires = ()
    scope = "full"

    def _audit(self, log: FlightLog, modes: list) -> list[Finding]:
        """没有事故时也做一次"模式切换是谁切的"审计。"""
        if len(modes) < 2:
            return []
        auto = []
        chain = []
        for e in modes[1:]:
            name, reason = self._split(e.detail)
            chain.append(f"{fmt_t(e.t, log.t_end)} 切到 {name}" + (f"（{reason}）" if reason else ""))
            if any(k in reason for k in ("失控保护", "围栏", "刹车超时", "GPS 异常")):
                auto.append((e, name, reason))
        if auto:
            sev = "warn" if all(("电池" in r) or ("围栏" in r) for _, _, r in auto) else "critical"
            head = f"有 {len(auto)} 次模式切换由飞控自发触发：" + \
                   "；".join(f"{fmt_t(e.t, log.t_end)} → {n}（{r}）" for e, n, r in auto)
            concl = ("这些切换不是人/地面站点的：触发源在飞控内部（失控保护、围栏、刹车超时等）。"
                     "要判断是否合理，请对照触发时刻的电池电压、遥控/GCS 链路与 EKF 状态。")
        else:
            sev = "info"
            head = f"共 {len(modes)} 次模式切换，原因字段全部是外部指令"
            reasons = sorted({self._split(e.detail)[1] for e in modes if self._split(e.detail)[1]})
            if reasons:
                head += "（" + "、".join(reasons) + "）"
            concl = ("日志里的 MODE.Rsn 字段记录了每次切换的发起者：遥控/地面站/任务指令都是"
                     "外部发起；若为失控保护类原因，才是飞控自己切的。本次没有这类原因。")
        return [Finding(self.id, "模式切换审计", "处置", sev,
                        t_start=modes[0].t, t_end=modes[-1].t,
                        evidence=chain[-8:], conclusion=concl + head + "。",
                        confidence=0.9, refs=["MODE"])]

    def run(self, log: FlightLog) -> list[Finding]:
        arms = log.events_of("arm")
        disarms = [e for e in log.events_of("disarm") if e.t > (arms[-1].t if arms else 0)]
        lands = [e for e in log.events_of("land") if e.t > log.t_end - 8]
        if disarms or lands:
            return []
        if log.t_end < 15:
            return []

        alt_end = _alt_at(log, log.t_end)
        alt_max = None
        for name in ("alt.rel", "alt.ctun"):
            s = log.get(name)
            if s is not None:
                alt_max = s.stat().get("max")
                break

        airborne = (alt_end is not None and alt_end > 2.0) or \
                   (alt_max is not None and alt_max > 15.0)
        if not airborne:
            return []

        last_events = [e for e in log.events
                       if e.t > log.t_end - 10 and e.severity == "critical"]
        ev = [f"日志最后一条记录在 {fmt_t(log.t_end, log.t_end)}，此后没有任何 disarm/着陆事件",
              f"最后高度约 {alt_end:.1f} m" if alt_end is not None else "缺少高度信号",
              f"全段最大高度 {alt_max:.1f} m" if alt_max is not None else ""]
        ev = [x for x in ev if x]
        if last_events:
            ev.append("结束前 10 秒内的关键事件：" +
                      "；".join(e.detail for e in last_events[:3]))
        return [Finding(self.id, self.title, self.category, "critical",
                        t_start=log.t_end, t_end=log.t_end, evidence=ev,
                        conclusion=("日志没有以正常降落（disarm）收尾，而是在空中戛然而止。"
                                    "常见原因：坠机导致电池断开/飞控断电、飞控复位、"
                                    "或 SD 卡写入中断。这本身就是强烈的事故证据。"),
                        confidence=0.85, refs=["EV", "MSG"])]


class ThrustLossDetector(Detector):
    """飞控自己报告的"推力损失"——通常意味着某个电机/电调/桨失效。"""

    id = "thrust-loss"
    title = "推力损失（动力失效）"
    category = "动力"
    requires = ()
    scope = "full"

    def _audit(self, log: FlightLog, modes: list) -> list[Finding]:
        """没有事故时也做一次"模式切换是谁切的"审计。"""
        if len(modes) < 2:
            return []
        auto = []
        chain = []
        for e in modes[1:]:
            name, reason = self._split(e.detail)
            chain.append(f"{fmt_t(e.t, log.t_end)} 切到 {name}" + (f"（{reason}）" if reason else ""))
            if any(k in reason for k in ("失控保护", "围栏", "刹车超时", "GPS 异常")):
                auto.append((e, name, reason))
        if auto:
            sev = "warn" if all(("电池" in r) or ("围栏" in r) for _, _, r in auto) else "critical"
            head = f"有 {len(auto)} 次模式切换由飞控自发触发：" + \
                   "；".join(f"{fmt_t(e.t, log.t_end)} → {n}（{r}）" for e, n, r in auto)
            concl = ("这些切换不是人/地面站点的：触发源在飞控内部（失控保护、围栏、刹车超时等）。"
                     "要判断是否合理，请对照触发时刻的电池电压、遥控/GCS 链路与 EKF 状态。")
        else:
            sev = "info"
            head = f"共 {len(modes)} 次模式切换，原因字段全部是外部指令"
            reasons = sorted({self._split(e.detail)[1] for e in modes if self._split(e.detail)[1]})
            if reasons:
                head += "（" + "、".join(reasons) + "）"
            concl = ("日志里的 MODE.Rsn 字段记录了每次切换的发起者：遥控/地面站/任务指令都是"
                     "外部发起；若为失控保护类原因，才是飞控自己切的。本次没有这类原因。")
        return [Finding(self.id, "模式切换审计", "处置", sev,
                        t_start=modes[0].t, t_end=modes[-1].t,
                        evidence=chain[-8:], conclusion=concl + head + "。",
                        confidence=0.9, refs=["MODE"])]

    def run(self, log: FlightLog) -> list[Finding]:
        hits = [e for e in log.events
                if e.kind == "thrust_loss" or "THRUST_LOSS" in e.detail.upper()
                or "POTENTIAL THRUST LOSS" in e.detail.upper()]
        if not hits:
            return []
        t0 = min(e.t for e in hits)
        ev = [f"{fmt_t(e.t, log.t_end)} {e.detail}" for e in hits[:4]]

        # 看输出通道：把"被顶到上限仍无推力"判为失效源，把"被压到下限"判为配平动作。
        # 关键点：飞控自报推力损失往往比物理失效晚 1–3 s，所以窗口不能以事件时刻为基准，
        # 要先在各通道上找"从常态跳到饱和/下限"的起点，用最早的起点当失效时刻。
        rng = _pwm_range(log)
        chans = []
        for k in log.series:
            m = re.fullmatch(r"out\.c(\d+)", k)
            if m:
                chans.append((int(m.group(1)), log.series[k]))
        chans.sort(key=lambda r: r[0])

        sat, cut, rise, onsets = [], [], [], []
        if chans:
            lo, hi = rng if rng is not None else _output_range(chans)
            lo, hi = _effective_bounds(chans, lo, hi, t0, log)
            span = hi - lo
            steps = {}
            for ch, sr in chans:
                st = _step_onset(sr, lo, hi, t0, back=12.0, ahead=2.0)
                if st is None:
                    continue
                kind, on = st
                # 失效是持续的：跳变后到事件时刻仍应保持在那一侧，否则只是短暂机动
                now = sr.at(t0 - 0.5)
                if kind == "sat" and now < hi - 0.08 * span:
                    continue
                if kind == "cut" and now > lo + 0.20 * span:
                    continue
                steps[ch] = st
                onsets.append(on)
            ref = min(onsets) if onsets else t0
            for ch, sr in chans:
                wb, wa = sr.window(ref - 6, ref - 0.5), sr.window(ref + 0.5, ref + 3)
                if not len(wb.y) or not len(wa.y):
                    continue
                b, a = float(np.mean(wb.y)), float(np.mean(wa.y))
                kind, on = steps.get(ch, (None, None))
                if kind == "sat" and a >= hi - 0.08 * span and a - b >= 0.08 * span:
                    sat.append((ch, b, a, on))
                elif kind == "cut" and a <= lo + 0.20 * span and b - a >= 0.12 * span:
                    cut.append((ch, b, a, on))
                elif a - b >= 0.06 * span:
                    rise.append((ch, b, a))
            sat.sort(key=lambda r: r[3])
            cut.sort(key=lambda r: r[3])

        if sat:
            for ch, b, a, on in sat[:3]:
                ev.append(f"电机 {ch} 输出被顶到上限：{b:.0f} → {a:.0f} us"
                          f"（可达上限约 {hi:.0f} us），自 {fmt_t(on, log.t_end)} 起持续饱和"
                          f"——推力没有跟上指令，是这一路动力（电机/电调/桨）失效的典型特征")
        if cut:
            for ch, b, a, on in cut[:3]:
                lag = ""
                if sat and abs(on - sat[0][3]) < 5:
                    dt_ = on - sat[0][3]
                    lag = f"，比 {sat[0][0]} 号饱和{'晚' if dt_ >= 0 else '早'} {abs(dt_):.1f} s"
                ev.append(f"电机 {ch} 被压到下限：{b:.0f} → {a:.0f} us"
                          f"（自 {fmt_t(on, log.t_end)} 起，下限约 {lo:.0f} us）{lag}"
                          f"——这是飞控在降低对侧输出配平偏航，不是 {ch} 号故障")
        for ch, b, a in rise[:4]:
            ev.append(f"电机 {ch} 输出上升：{b:.0f} → {a:.0f} us（剩余动力补偿）")
        if len(rise) > 4:
            ev.append(f"另有 {len(rise) - 4} 个通道同步加大输出")
        if onsets and t0 - min(onsets) > 0.5:
            ev.append(f"飞控自报推力损失在 {fmt_t(t0, log.t_end)}，"
                      f"比输出异常晚 {t0 - min(onsets):.1f} s —— 物理失效在先，告警在后")

        alt = _alt_at(log, t0)
        if alt is not None:
            ev.append(f"事件时刻高度约 {alt:.1f} m")
        return [Finding(self.id, self.title, self.category, "critical",
                        t_start=t0, t_end=log.flight_end, evidence=ev,
                        conclusion=_thrust_loss_conclusion([r[0] for r in sat],
                                                           [r[0] for r in cut]),
                        confidence=0.92 if (sat and cut) else 0.8,
                        refs=["MSG", "ERR", "RCOU"])]


def _output_range(chans) -> tuple[float, float]:
    """没有 PWM 参数时（PX4 归一化输出等），按实际输出范围推断上下限。"""
    hi = max(float(np.max(s.y)) for _c, s in chans)
    lo = min(float(np.min(s.y)) for _c, s in chans)
    if hi <= 1.5:  # 归一化 0–1
        return 0.0, max(1.0, hi)
    return lo, hi


def _effective_bounds(chans, lo: float, hi: float, t0: float, log) -> tuple[float, float]:
    """用实际能达到的输出范围修正 PWM 上下限。

    ArduCopter 的 RCOU 常见上限是 ``MOT_SPIN_MAX``（默认 0.95 → 1950 us）而不是 2000；
    下限则受 ``MOT_SPIN_MIN`` 约束。不做这个修正，"接近上限"就会被判成"没到上限"。
    """
    span = hi - lo
    vals = [s.window(t0 - 30, t0 + 2).y for _c, s in chans]
    vals = [v for v in vals if len(v)]
    if not vals:
        return lo, hi
    allv = np.concatenate(vals)
    spin_min = float(log.params.get("MOT_SPIN_MIN", 0.15) or 0.15)
    spin_max = float(log.params.get("MOT_SPIN_MAX", 0.95) or 0.95)
    hi_eff = min(hi, lo + spin_max * span, float(np.percentile(allv, 99.0)))
    lo_eff = max(lo, lo + spin_min * span)
    if hi_eff - lo_eff < 0.3 * span:  # 参数不可信就退回原始范围
        return lo, hi
    return lo_eff, hi_eff


def motor_bounds(log: FlightLog, t0: float) -> tuple[float, float, float] | None:
    """供图表使用的电机输出上下限 ``(lo, hi, span)``。

    与 :class:`ThrustLossDetector` 用同一套修正（MOT_SPIN_MIN/MAX + 实测 P99），
    保证图上画的两条参考线与判读依据是同一条线。
    """
    chans = []
    for name in log.series:
        m = re.fullmatch(r"out\.c(\d+)", name)
        if m:
            chans.append((int(m.group(1)), log.series[name]))
    if not chans:
        return None
    chans.sort(key=lambda x: x[0])
    rng = _pwm_range(log)
    if rng is None:
        lo, hi = _output_range(chans)
        if hi <= 1.5:
            return 0.0, 1.0, 1.0
        return lo, hi, hi - lo
    lo, hi = _effective_bounds(chans, rng[0], rng[1], t0, log)
    return lo, hi, hi - lo


def _step_onset(sr, lo: float, hi: float, t0: float,
                back: float = 10.0, ahead: float = 4.0, hold: float = 1.5):
    """找"从常态跳到饱和/下限"的起点，返回 (kind, t)；kind 为 "sat"/"cut"。

    必须"跳变"才算：只看是否接近上限，会把平飞时本来就很高的通道误判成失效。
    """
    span = hi - lo
    seg = sr.window(t0 - back, t0 + ahead)
    if not len(seg.y):
        return None
    for i, t in enumerate(seg.t):
        y = float(seg.y[i])
        before = seg.y[(seg.t >= t - 2.0) & (seg.t < t - 0.3)]
        after = seg.y[(seg.t >= t) & (seg.t <= t + hold)]
        if not len(before) or not len(after):
            continue
        if (y >= hi - 0.05 * span and np.mean(before) <= hi - 0.15 * span
                and np.mean(after) >= hi - 0.12 * span):
            return "sat", float(t)
        if (y <= lo + 0.10 * span and np.mean(before) >= lo + 0.25 * span
                and np.mean(after) <= lo + 0.15 * span):
            return "cut", float(t)
    return None


def _pwm_range(log: FlightLog) -> tuple[float, float] | None:
    """电机输出的 PWM 上下限；归一化输出（0–1，常见于 PX4）返回 None。"""
    try:
        lo = float(log.params.get("MOT_PWM_MIN", 1000.0))
        hi = float(log.params.get("MOT_PWM_MAX", 2000.0))
    except (TypeError, ValueError):
        return None
    if not (600.0 <= lo < hi <= 2200.0):
        return None
    return lo, hi


def _first_cross(s, ok, t0: float, t1: float) -> float | None:
    """在 [t0, t1] 内找第一个满足 ok(value) 的时刻。"""
    seg = s.window(t0, t1)
    for t, y in zip(seg.t, seg.y):
        if ok(float(y)):
            return float(t)
    return None


def _thrust_loss_conclusion(sat, cut) -> str:
    if sat and cut:
        s1, s2 = sat[0], cut[0]
        return (f"疑似 {s1} 号动力单元（电机/电调/桨）失效：飞控把它顶到满油仍没有推力，"
                f"随后把 {s2} 号压到最低去配平偏航，其余电机加力补偿也没能稳住。"
                f"判读顺序是**先饱和、后压低**——被压低的那一路是响应，不要把它当成故障源。"
                f"这是坠机的**直接原因**候选。")
    if sat:
        s1 = sat[0]
        return (f"疑似 {s1} 号动力单元失效：它的输出被顶到上限却没有对应的推力，"
                f"剩余电机加力补偿仍无法维持姿态。这是坠机的**直接原因**候选。")
    return ("飞控检测到推力损失：某个电机/电调/桨叶不再提供预期推力。"
            "多旋翼会立即出现不可控的偏航/滚转，剩余电机被迫满油补偿，通常数秒内失控。"
            "建议结合 RCOU 通道曲线定位具体是哪一路。")


class EstopDetector(Detector):
    """电机急停（E-Stop）：空中切断动力，几乎必然坠机。"""

    id = "estop"
    title = "空中电机急停 (E-Stop)"
    category = "操作"
    requires = ()
    scope = "full"

    def _audit(self, log: FlightLog, modes: list) -> list[Finding]:
        """没有事故时也做一次"模式切换是谁切的"审计。"""
        if len(modes) < 2:
            return []
        auto = []
        chain = []
        for e in modes[1:]:
            name, reason = self._split(e.detail)
            chain.append(f"{fmt_t(e.t, log.t_end)} 切到 {name}" + (f"（{reason}）" if reason else ""))
            if any(k in reason for k in ("失控保护", "围栏", "刹车超时", "GPS 异常")):
                auto.append((e, name, reason))
        if auto:
            sev = "warn" if all(("电池" in r) or ("围栏" in r) for _, _, r in auto) else "critical"
            head = f"有 {len(auto)} 次模式切换由飞控自发触发：" + \
                   "；".join(f"{fmt_t(e.t, log.t_end)} → {n}（{r}）" for e, n, r in auto)
            concl = ("这些切换不是人/地面站点的：触发源在飞控内部（失控保护、围栏、刹车超时等）。"
                     "要判断是否合理，请对照触发时刻的电池电压、遥控/GCS 链路与 EKF 状态。")
        else:
            sev = "info"
            head = f"共 {len(modes)} 次模式切换，原因字段全部是外部指令"
            reasons = sorted({self._split(e.detail)[1] for e in modes if self._split(e.detail)[1]})
            if reasons:
                head += "（" + "、".join(reasons) + "）"
            concl = ("日志里的 MODE.Rsn 字段记录了每次切换的发起者：遥控/地面站/任务指令都是"
                     "外部发起；若为失控保护类原因，才是飞控自己切的。本次没有这类原因。")
        return [Finding(self.id, "模式切换审计", "处置", sev,
                        t_start=modes[0].t, t_end=modes[-1].t,
                        evidence=chain[-8:], conclusion=concl + head + "。",
                        confidence=0.9, refs=["MODE"])]

    def run(self, log: FlightLog) -> list[Finding]:
        hits = [e for e in log.events if e.kind == "estop"]
        if not hits:
            return []
        t0 = min(e.t for e in hits)
        alt = _alt_at(log, t0)
        ev = [f"{fmt_t(e.t, log.t_end)} {e.detail}" for e in hits[:4]]
        if alt is not None:
            ev.append(f"急停时刻高度约 {alt:.1f} m")
        after = log.t_end - t0
        ev.append(f"急停后日志仅继续了 {after:.1f} s")
        sev = merge_sev(*["critical" if (alt is None or alt > 2) else "warn" for _ in hits])
        return [Finding(self.id, self.title, self.category, sev,
                        t_start=t0, t_end=min(log.t_end, t0 + 10), evidence=ev,
                        conclusion=("电机被主动切断（E-Stop 开关/指令）。若发生在空中，"
                                    "多旋翼会立即失去全部升力、自由落体；这通常是"
                                    "飞手在发现失控后的最后手段，也可能是误触。"),
                        confidence=0.95, refs=["MSG", "RCIN", "EV"])]


class ModeSwitchDetector(Detector):
    """事故前后的模式切换：既是飞手的处置动作，也是"当时还认为能救"的证据。

    只关心事故触发点附近（前 20 s、后 12 s）的切换。判定要点：
    - 切到 ALT_HOLD / POSHOLD 之类，通常是想先稳住姿态再处理；
    - 切到 RTL / LAND / AUTO 才算真正进入迫降/返航流程；
    - 事故后一直没进迫降模式，本身就值得写进报告。
    """

    id = "mode-switch"
    title = "飞行模式切换（处置动作）"
    category = "处置"
    requires = ()
    scope = "full"

    _RESCUE = ("RTL", "LAND", "AUTO")

    @staticmethod
    def _split(detail: str) -> tuple[str, str]:
        """把 "模式切换 → 17 BRAKE｜地面站指令" 拆成 (模式名, 原因)。"""
        body = detail.split("→")[-1].strip() if "→" in detail else detail
        if "｜" in body:
            name, reason = body.split("｜", 1)
            return name.strip(), reason.strip()
        return body.strip(), ""

    @staticmethod
    def _name(detail: str) -> str:
        return ModeSwitchDetector._split(detail)[0]

    def _audit(self, log: FlightLog, modes: list) -> list[Finding]:
        """没有事故时也做一次"模式切换是谁切的"审计。"""
        if len(modes) < 2:
            return []
        auto = []
        chain = []
        for e in modes[1:]:
            name, reason = self._split(e.detail)
            chain.append(f"{fmt_t(e.t, log.t_end)} 切到 {name}" + (f"（{reason}）" if reason else ""))
            if any(k in reason for k in ("失控保护", "围栏", "刹车超时", "GPS 异常")):
                auto.append((e, name, reason))
        if auto:
            sev = "warn" if all(("电池" in r) or ("围栏" in r) for _, _, r in auto) else "critical"
            head = f"有 {len(auto)} 次模式切换由飞控自发触发：" + \
                   "；".join(f"{fmt_t(e.t, log.t_end)} → {n}（{r}）" for e, n, r in auto)
            concl = ("这些切换不是人/地面站点的：触发源在飞控内部（失控保护、围栏、刹车超时等）。"
                     "要判断是否合理，请对照触发时刻的电池电压、遥控/GCS 链路与 EKF 状态。")
        else:
            sev = "info"
            head = f"共 {len(modes)} 次模式切换，原因字段全部是外部指令"
            reasons = sorted({self._split(e.detail)[1] for e in modes if self._split(e.detail)[1]})
            if reasons:
                head += "（" + "、".join(reasons) + "）"
            concl = ("日志里的 MODE.Rsn 字段记录了每次切换的发起者：遥控/地面站/任务指令都是"
                     "外部发起；若为失控保护类原因，才是飞控自己切的。本次没有这类原因。")
        return [Finding(self.id, "模式切换审计", "处置", sev,
                        t_start=modes[0].t, t_end=modes[-1].t,
                        evidence=chain[-8:], conclusion=concl + head + "。",
                        confidence=0.9, refs=["MODE"])]

    def run(self, log: FlightLog) -> list[Finding]:
        modes = sorted(log.events_of("mode"), key=lambda e: e.t)
        t_inc = log.t_incident

        if t_inc is None or len(modes) < 2:
            return self._audit(log, modes)
        lo, hi = t_inc - 20.0, min(log.t_end, t_inc + 12.0)
        idx = [i for i, e in enumerate(modes) if lo <= e.t <= hi]
        if not idx:
            return []

        def rel(t: float) -> str:
            d = t - t_inc
            if abs(d) < 0.05:
                return "与推力损失同一时刻"
            return f"推力损失后 {d:.1f} s" if d > 0 else f"推力损失前 {-d:.1f} s"

        ev, chain = [], []
        for i in idx:
            e = modes[i]
            name = self._name(e.detail)
            prev = self._name(modes[i - 1].detail) if i else "（日志起点）"
            chain.append(f"{fmt_t(e.t, log.t_end)} {prev} → {name}（{rel(e.t)}）")
            ev.append(chain[-1])

        after = [modes[i] for i in idx if modes[i].t >= t_inc]
        rescue = any(any(k in self._name(e.detail).upper() for k in self._RESCUE) for e in after)
        crashed = bool(log.events_of("impact")) or (log.t_end - t_inc) < 6.0

        if not after:
            sev, tail = "info", "事故触发后没有再切模式。"
        elif rescue:
            sev, tail = "info", "事故后进入了返航/迫降类模式，处置方向是对的。"
        else:
            sev = "warn" if crashed else "info"
            tail = ("事故后没有转入 RTL / LAND / AUTO 迫降模式——"
                    "切换都停留在 ALT_HOLD / POSHOLD 这类'先稳住'的模式上。")

        if crashed and not rescue:
            ev.append("事故后未进入 RTL / LAND / AUTO（迫降/返航）模式")
        return [Finding(self.id, self.title, self.category, sev,
                        t_start=modes[idx[0]].t, t_end=modes[idx[-1]].t,
                        evidence=ev,
                        conclusion=(tail + "先切定高/定点是想稳住机体，再切回 LOITER 说明当时还想救；"
                                    "这类切换记录能还原飞手在几秒内的判断顺序。"),
                        confidence=0.7, refs=["MODE", "EV"])]
