"""大模型叙事层：把"规则检出的证据"交给 LLM，生成事故复盘与建议。

设计原则
--------
* **模型只负责叙述，不负责发现事实**：所有时间、数值、事件都来自规则层（证据包），
  提示词明确要求"不得编造未给出的事实"；
* 兼容任何 OpenAI 格式的 ``/chat/completions``（DeepSeek、通义、Kimi、本地 vLLM…）；
* 只依赖标准库 ``urllib``，不强制安装 requests/openai；
* 解析失败不抛异常给用户看堆栈，而是降级为"原始文本"并在报告里标注。

典型用法::

    cfg = LLMConfig(api_key="sk-...", base_url="https://api.deepseek.com/v1",
                    model="deepseek-chat")
    narrative = narrate(analysis, cfg)
"""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from .model import Analysis, fmt_t

DEFAULT_BASE_URL = "https://api.deepseek.com/v1"
DEFAULT_MODEL = "deepseek-chat"

SYSTEM_PROMPT = """\
你是一名资深的多旋翼飞控（ArduPilot / PX4）事故调查工程师。
你会收到一份"证据包"：由规则引擎从飞行日志里自动提取的统计、事件时间线与检测结论。
你的任务是像写正式事故报告一样，把证据组织成清晰的复盘叙述。

硬性要求：
1. 只能使用证据包里出现的事实、数字和时间；**绝不编造**未给出的参数、坐标、人名或事件。
2. 引用时间一律用证据包里的写法（例如 T+07:21.5），不要换算成别的格式。
3. 区分"直接原因 / 诱因 / 结果"：例如电机失效是原因，空中急停是处置，翻转坠地是结果。
4. 判读电机输出时注意方向：**被顶到上限**（满油）仍无推力的一路是失效嫌疑；
   **被压到下限**的一路通常是飞控在配平偏航，是响应而不是故障源。顺序（先饱和、后压低）本身是证据。
5. 模式切换（MODE 事件）是**处置证据**：切到 RTL / LAND / AUTO 说明进入了返航或迫降流程；
   只切到 ALT_HOLD / POSHOLD / LOITER 说明当时只想先把机体稳住。要在 chain 与 handling 里
   写清楚"什么时候切了什么、说明飞手在想什么"，不要漏掉模式时间线。
6. 若证据不足以定论，明确写"证据不足"，并说明还需要哪些日志或数据。
7. 使用简体中文，语气克制、专业，不要营销腔，不要空话套话。
8. 严格输出 JSON（不要 Markdown 代码块、不要解释文字）。
"""

USER_TEMPLATE = """\
以下是证据包（JSON）：

{payload}

请输出如下结构的 JSON：
{{
  "headline": "一句话结论（30 字以内）",
  "summary": "150-250 字的总体复盘：发生了什么、为什么、后果",
  "chain": [{{"time": "T+MM:SS.s", "event": "发生了什么", "meaning": "这意味着什么"}}],
  "root_cause": {{"primary": "最可能的直接原因", "confidence": "高|中|低", "reasoning": "依据哪些证据"}},
  "alternatives": ["其他可能原因及为何可能性较低"],
  "contributing": ["诱因/促成因素"],
  "handling": "对飞手当时处置的评价（若无处置证据则写证据不足）",
  "recommendations": [{{"priority": "高|中|低", "action": "具体动作", "reason": "为什么"}}],
  "data_gaps": ["还需要哪些数据才能进一步确认"],
  "one_liner": "给机主看的一句话提醒（20 字以内）"
}}
"""


class LLMError(RuntimeError):
    """调用大模型失败（网络/鉴权/额度/解析）。"""


@dataclass
class LLMConfig:
    api_key: str
    base_url: str = DEFAULT_BASE_URL
    model: str = DEFAULT_MODEL
    temperature: float = 0.2
    max_tokens: int = 2400
    timeout: float = 180.0
    #: 额外请求头，例如 OpenRouter 的 HTTP-Referer
    headers: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        if not self.api_key:
            raise LLMError("缺少 API Key")
        if not self.base_url.endswith("/v1") and "/v1" not in self.base_url:
            self.base_url += "/v1"

    @property
    def endpoint(self) -> str:
        return f"{self.base_url}/chat/completions"


def config_from_env(**overrides: Any) -> LLMConfig | None:
    """从环境变量构造配置；没有任何密钥时返回 None。

    识别顺序：显式参数 > FLA_API_KEY > DEEPSEEK_API_KEY > OPENAI_API_KEY
    """
    key = (overrides.pop("api_key", None)
           or os.environ.get("FLA_API_KEY")
           or os.environ.get("DEEPSEEK_API_KEY")
           or os.environ.get("OPENAI_API_KEY"))
    if not key:
        return None
    base = overrides.pop("base_url", None) or os.environ.get("FLA_BASE_URL") or DEFAULT_BASE_URL
    model = overrides.pop("model", None) or os.environ.get("FLA_MODEL") or DEFAULT_MODEL
    return LLMConfig(api_key=key, base_url=base, model=model, **overrides)


# --------------------------------------------------------------------------- #
# 证据包
# --------------------------------------------------------------------------- #
def evidence_pack(analysis: Analysis, max_events: int = 40) -> dict[str, Any]:
    from .detectors import DEFAULT_DETECTORS

    log = analysis.log
    s = analysis.summary
    t_inc = log.t_incident
    pool = [e for e in log.events if e.kind != "msg" or e.severity != "info"]

    def dist(e) -> float:
        return abs(e.t - t_inc) if t_inc is not None else (log.t_end - e.t)

    events = sorted(pool, key=lambda e: (dist(e) > 30.0, dist(e)))[:max_events]
    events.sort(key=lambda e: e.t)
    switches = [{"t": fmt_t(e.t, log.t_end), "detail": e.detail}
                for e in log.events_of("mode")
                if t_inc is None or abs(e.t - t_inc) <= 30.0]
    return {
        "verdict": analysis.verdict,
        "score": analysis.score,
        "rule_based_summary": analysis.verdict_text,
        "flight": {
            "firmware": log.firmware,
            "vehicle": s.get("vehicle"),
            "log_format": log.log_format,
            "duration_s": s.get("duration_s"),
            "armed_s": s.get("armed_s"),
            "max_alt_m": s.get("max_alt_m"),
            "max_speed_ms": s.get("max_speed_ms"),
            "distance_m": s.get("distance_m"),
            "final_mode": s.get("mode"),
            "modes": s.get("modes"),
            "sessions": [
                {"index": x["index"], "t_start": fmt_t(x["t_start"], log.t_end),
                 "dur_s": round(x["dur"], 1),
                 "max_alt_m": None if x["max_alt_m"] is None else round(x["max_alt_m"], 1),
                 "mode_start": x.get("mode_start"), "end": x.get("end")}
                for x in (s.get("sessions") or [])
            ],
            "params": s.get("params"),
        },
        "mode_switches": switches,
        "events": [{"t": fmt_t(e.t, log.t_end), "kind": e.kind,
                    "detail": e.detail, "severity": e.severity} for e in events],
        "rule_limits": [f"{d.title}：{d.note}" for d in DEFAULT_DETECTORS if getattr(d, "note", "")],
        "findings": [
            {"id": f.id, "title": f.title, "severity": f.severity, "category": f.category,
             "time": fmt_t(f.t_start, log.t_end) if f.t_start is not None else None,
             "evidence": f.evidence, "conclusion": f.conclusion,
             "confidence": f.confidence}
            for f in analysis.sorted_findings()
        ],
        "not_checked": [{"detector": sk.detector, "reason": sk.reason} for sk in analysis.skipped],
    }


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #
def _post(cfg: LLMConfig, payload: dict[str, Any]) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {cfg.api_key}"}
    headers.update(cfg.headers)
    req = urllib.request.Request(cfg.endpoint, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=cfg.timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:800]
        hint = {
            401: "密钥无效或已过期",
            403: "密钥无权访问该模型",
            404: "接口地址或模型名不对（检查 base_url / model）",
            429: "触发限流或余额不足",
            500: "服务端错误，稍后重试",
        }.get(exc.code, "")
        raise LLMError(f"大模型接口返回 HTTP {exc.code} {hint}：{detail}") from exc
    except urllib.error.URLError as exc:
        raise LLMError(f"无法连接大模型接口（{cfg.endpoint}）：{exc.reason}") from exc
    except TimeoutError as exc:  # pragma: no cover - 依网络环境
        raise LLMError(f"大模型接口超时（{cfg.timeout:.0f}s）") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise LLMError(f"接口返回的不是 JSON：{raw[:300]}") from exc


def _extract_json(text: str) -> dict[str, Any]:
    """容错解析：去掉代码围栏、截取第一个平衡的 JSON 对象。"""
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    try:
        v = json.loads(t)
        return v if isinstance(v, dict) else {"summary": t}
    except json.JSONDecodeError:
        pass
    start = t.find("{")
    if start < 0:
        raise LLMError("模型输出里没有 JSON 对象")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(t[start:i + 1])
                except json.JSONDecodeError as exc:
                    raise LLMError(f"模型输出的 JSON 不合法：{exc}") from exc
    raise LLMError("模型输出的 JSON 不完整（可能被 max_tokens 截断）")


def _as_list(x: Any) -> list[Any]:
    if isinstance(x, list):
        return x
    if x in (None, "", {}):
        return []
    return [x]


def _norm(narr: dict[str, Any]) -> dict[str, Any]:
    """把模型输出规整成固定结构，缺字段给空值（报告层不用担心 KeyError）。"""
    chain = []
    for item in _as_list(narr.get("chain")):
        if isinstance(item, dict):
            chain.append({"time": str(item.get("time", "")),
                          "event": str(item.get("event", "")),
                          "meaning": str(item.get("meaning", ""))})
        elif item:
            chain.append({"time": "", "event": str(item), "meaning": ""})
    recs = []
    for item in _as_list(narr.get("recommendations")):
        if isinstance(item, dict):
            recs.append({"priority": str(item.get("priority", "")),
                         "action": str(item.get("action", "")),
                         "reason": str(item.get("reason", ""))})
        elif item:
            recs.append({"priority": "", "action": str(item), "reason": ""})
    rc = narr.get("root_cause")
    if not isinstance(rc, dict):
        rc = {"primary": str(rc or ""), "confidence": "", "reasoning": ""}
    return {
        "headline": str(narr.get("headline", "") or ""),
        "one_liner": str(narr.get("one_liner", "") or ""),
        "summary": str(narr.get("summary", "") or ""),
        "chain": chain,
        "root_cause": {"primary": str(rc.get("primary", "")),
                       "confidence": str(rc.get("confidence", "")),
                       "reasoning": str(rc.get("reasoning", ""))},
        "alternatives": [str(x) for x in _as_list(narr.get("alternatives"))],
        "contributing": [str(x) for x in _as_list(narr.get("contributing"))],
        "handling": str(narr.get("handling", "") or ""),
        "recommendations": recs,
        "data_gaps": [str(x) for x in _as_list(narr.get("data_gaps"))],
        "raw": narr,
    }


def narrate(analysis: Analysis, cfg: LLMConfig, *, evidence: dict[str, Any] | None = None,
            temperature: float | None = None) -> dict[str, Any]:
    """调用大模型生成叙事；返回规整后的 dict（含 usage 元信息）。"""
    pack = evidence if evidence is not None else evidence_pack(analysis)
    payload = {
        "model": cfg.model,
        "temperature": cfg.temperature if temperature is None else temperature,
        "max_tokens": cfg.max_tokens,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": USER_TEMPLATE.format(
                payload=json.dumps(pack, ensure_ascii=False, indent=1))},
        ],
    }
    try:
        resp = _post(cfg, payload)
    except LLMError as exc:
        # 有些兼容接口不支持 response_format，去掉再试一次
        if "response_format" not in str(exc) and "400" not in str(exc):
            raise
        payload.pop("response_format", None)
        resp = _post(cfg, payload)

    try:
        content = resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError(f"接口响应结构异常：{json.dumps(resp, ensure_ascii=False)[:400]}") from exc

    narr = _norm(_extract_json(content))
    narr["model"] = resp.get("model", cfg.model)
    usage = resp.get("usage") or {}
    narr["usage"] = {k: usage.get(k) for k in ("prompt_tokens", "completion_tokens", "total_tokens")}
    narr["raw_text"] = content
    return narr


def ping(cfg: LLMConfig) -> str:
    """最小请求，用于 Web 界面"测试密钥"。"""
    payload = {"model": cfg.model, "max_tokens": 8,
               "messages": [{"role": "user", "content": "回复 ok"}]}
    resp = _post(cfg, payload)
    try:
        return str(resp["choices"][0]["message"]["content"]).strip()
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError("接口响应结构异常") from exc


# --------------------------------------------------------------------------- #
# 落到 Markdown
# --------------------------------------------------------------------------- #
def narrative_markdown(narr: dict[str, Any], analysis: Analysis) -> str:
    """把叙事转成报告章节（插在"结论"之后）。"""
    log = analysis.log
    out: list[str] = []
    add = out.append
    if narr.get("headline"):
        add(f"> **{narr['headline']}**")
        add("")
    if narr.get("summary"):
        add(narr["summary"])
        add("")
    rc = narr.get("root_cause") or {}
    if rc.get("primary"):
        add(f"**最可能的直接原因**：{rc['primary']}"
            + (f"（置信度：{rc['confidence']}）" if rc.get("confidence") else ""))
        add("")
        if rc.get("reasoning"):
            add(f"依据：{rc['reasoning']}")
            add("")
    if narr.get("chain"):
        add("### 事故链条")
        add("")
        add("| 时间 | 事件 | 判读 |")
        add("| --- | --- | --- |")
        for c in narr["chain"][:20]:
            add(f"| {c['time']} | {c['event']} | {c['meaning']} |")
        add("")
    if narr.get("contributing"):
        add("### 促成因素")
        add("")
        for x in narr["contributing"][:10]:
            add(f"- {x}")
        add("")
    if narr.get("alternatives"):
        add("### 其他可能")
        add("")
        for x in narr["alternatives"][:10]:
            add(f"- {x}")
        add("")
    if narr.get("handling"):
        add("### 处置评价")
        add("")
        add(narr["handling"])
        add("")
    if narr.get("recommendations"):
        add("### 整改建议")
        add("")
        for i, r in enumerate(narr["recommendations"][:10], 1):
            tag = f"**{r['priority']}优先级**" if r.get("priority") else ""
            add(f"{i}. {tag} {r['action']}" + (f"——{r['reason']}" if r.get("reason") else ""))
        add("")
    if narr.get("data_gaps"):
        add("### 还缺什么证据")
        add("")
        for x in narr["data_gaps"][:10]:
            add(f"- {x}")
        add("")
    usage = narr.get("usage") or {}
    if usage.get("total_tokens"):
        add(f"*叙事由 `{narr.get('model', 'LLM')}` 生成，消耗 {usage['total_tokens']} tokens；"
            f"事实与时间戳来自规则层证据包，模型未参与事实提取。*")
        add("")
    return "\n".join(out)
