"""叙事核对：把大模型写出来的时间/数字，逐条对回规则层的证据包。

模型最危险的不是写得不好，而是**把没给的数字写得很像真的**。这里做一个
轻量核对：每个 T+ 时间都必须在证据包里出现过（或落在飞行时长内），每个带
单位的数字都要能在证据包里找到相近的值；对不上的不判错，只标出来给人看。
"""
from __future__ import annotations

import json
import re
from typing import Any

_TIME = re.compile(r"T\+(\d{1,2}):(\d{2}(?:\.\d+)?)")
_NUM = re.compile(r"(-?\d+(?:\.\d+)?)\s*(°C|°F|m/s²|m/s\^?2|m/s|us|µs|ms|°|deg|m|V|A|%|g)(?![A-Za-z])")

_RANGE = re.compile(r"(-?\d+(?:\.\d+)?)\s*(?:→|->|–|~|至)\s*(-?\d+(?:\.\d+)?)\s*"
                    r"(°C|°F|m/s²|m/s\^?2|m/s|us|µs|ms|°|deg|m|V|A|%|g)(?![A-Za-z])")

_G = 9.80665


def _times(text: str) -> list[float]:
    return [int(m) * 60 + float(s) for m, s in _TIME.findall(text or "")]


def _nums(text: str) -> list[tuple[float, str]]:
    out = []
    for v, u in _NUM.findall(text or ""):
        u = u.replace("µs", "us").replace("m/s^2", "m/s²").replace("deg", "°")
        out.append((float(v), u))
    return out


def _walk(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)


def check(narrative: dict[str, Any], pack: dict[str, Any], duration: float | None = None) -> dict[str, Any]:
    """返回 {times, nums, bad_times[], bad_nums[]}；bad_* 只列疑点，不阻断出报告。"""
    narr_text = _walk(narrative)
    pack_text = _walk(pack)

    allowed_t = _times(pack_text)
    times = _times(narr_text)
    bad_times = []
    for t in times:
        near = any(abs(t - a) <= 1.5 for a in allowed_t)
        if not near:
            if duration and -1.0 <= t <= duration + 1.0:
                bad_times.append(round(t, 1))   # 落在飞行区间但证据包里没这个时刻
            else:
                bad_times.append(round(t, 1))

    pack_nums = _nums(pack_text)
    for a, b, u in _RANGE.findall(pack_text):   # "1572 → 1949 us" 两端都算证据
        u = u.replace("µs", "us").replace("m/s^2", "m/s²").replace("deg", "°")
        pack_nums.append((float(a), u))
        pack_nums.append((float(b), u))
    nums = _nums(narr_text)
    bad_nums: list[str] = []

    def hit(v: float, u: str) -> bool:
        for pv, pu in pack_nums:
            if abs(v - pv) <= max(0.25, abs(pv) * 0.02):
                return True
            if u == "g" and pu in ("m/s²", "m/s^2") and abs(v * _G - pv) <= max(0.5, abs(pv) * 0.05):
                return True   # 1 g ≈ 9.81 m/s²，换算过的也算对得上
            if u == "m/s²" and pu == "g" and abs(v / _G - pv) <= max(0.5, abs(pv) * 0.05):
                return True
            # 单芯电压 3.89 V 由总电压 46.62 V ÷ 12 得来，属于合理换算
            if u == "V" and pu == "V" and 2.5 <= v <= 4.6:
                for cells in range(6, 15):
                    if abs(v * cells - pv) <= max(0.6, abs(pv) * 0.03):
                        return True
        return False

    for v, u in nums:
        if not hit(v, u):
            item = f"{v:g} {u}"
            if item not in bad_nums:      # 同一个数值只报一次
                bad_nums.append(item)

    return {
        "times": len(times),
        "nums": len(nums),
        "bad_times": bad_times,
        "bad_nums": bad_nums,
        "ok": not bad_times and not bad_nums,
    }
