"""一键启动本地网页界面（便携包 / 安装版用它，免开命令行）。

双击 ``启动.bat`` 后：

1. 选一个空闲端口（默认从 8000 起）；
2. 等服务起来后自动用默认浏览器打开；
3. 控制台窗口保留服务日志，关窗口即停止。
"""
from __future__ import annotations

import argparse
import os
import socket
import sys
import threading
import time
import webbrowser


def _free_port(host: str, start: int, tries: int = 20) -> int:
    for port in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind((host, port))
            except OSError:
                continue
            return port
    return start


def _open_when_ready(url: str, host: str, port: int, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.4)
            if sock.connect_ex((host, port)) == 0:
                time.sleep(0.25)
                try:
                    webbrowser.open(url)
                except Exception:
                    pass
                return
        time.sleep(0.15)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="fla-desktop", description="启动 flightlog-autopsy 网页界面")
    parser.add_argument("--port", type=int, default=8000, help="起始端口（被占用时自动往后找）")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址，默认只允许本机")
    parser.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    args = parser.parse_args(argv)

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass

    from . import __version__
    from .paths import data_root

    root = data_root()
    os.environ.setdefault("FLA_DATA_DIR", str(root))
    (root / "reports").mkdir(parents=True, exist_ok=True)

    from .web.app import app  # 必须在设置 FLA_DATA_DIR 之后导入

    port = _free_port(args.host, args.port)
    url = f"http://{args.host}:{port}"

    print("=" * 62)
    print(f"  flightlog-autopsy {__version__}  飞控日志事故分析")
    print("=" * 62)
    print(f"  网页地址 : {url}")
    print(f"  报告目录 : {root / 'reports'}")
    print("  关闭本窗口（或按 Ctrl+C）即停止服务")
    print()

    if not args.no_browser:
        threading.Thread(target=_open_when_ready, args=(url, args.host, port), daemon=True).start()

    import uvicorn

    try:
        uvicorn.run(app, host=args.host, port=port, log_level="warning", access_log=False)
    except KeyboardInterrupt:
        print("\n已停止。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
