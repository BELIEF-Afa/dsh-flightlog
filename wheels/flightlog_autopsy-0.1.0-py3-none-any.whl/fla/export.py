"""把 Markdown 报告导出成可以直接交付的文档。

支持两种格式：

* ``.docx`` —— Word 文档（现场报告、评审、归档都用得上）
* ``.html`` —— 独立单文件 HTML，自带打印样式，浏览器里"打印 → 另存为 PDF"
  就是 PDF，不需要装任何 PDF 库

刻意不引 python-docx：docx 本身就是一个 zip + 几个 XML，标准库足够拼出来，
这样 Windows 绿色包不需要再多带依赖，断网现场也能用。
"""
from __future__ import annotations

import datetime as _dt
import html as _html
import re
import zipfile
from pathlib import Path

from .web.md import render as md_to_html

__all__ = ["markdown_to_docx", "markdown_to_html", "save_documents",
           "inline_images", "SUFFIX_MEDIA"]

SUFFIX_MEDIA = {
    ".md": "text/markdown; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".png": "image/png",
    ".jpg": "image/jpeg",
}

_CJK = re.compile(r"[\u3000-\u9fff\uff00-\uffef]")


# --------------------------------------------------------------------------
# Markdown → 块
# --------------------------------------------------------------------------
def _join(parts: list[str]) -> str:
    """拼接被换行折断的段落：中文之间不留空格，西文之间留一个。"""
    out = ""
    for p in parts:
        if not out:
            out = p
        elif _CJK.search(out[-1]) or _CJK.search(p[:1]):
            out += p
        else:
            out += " " + p
    return out


def _blocks(md: str) -> list[tuple]:
    lines = md.splitlines()
    out: list[tuple] = []
    i, n = 0, len(lines)
    while i < n:
        raw = lines[i]
        s = raw.strip()
        if not s:
            i += 1
            continue

        if s.startswith("```"):
            j, buf = i + 1, []
            while j < n and not lines[j].strip().startswith("```"):
                buf.append(lines[j])
                j += 1
            out.append(("code", buf))
            i = j + 1
            continue

        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            out.append(("heading", len(m.group(1)), m.group(2).strip()))
            i += 1
            continue

        m_img = re.match(r"^!\[(.*?)\]\((.+?)\)$", s)
        if m_img:
            out.append(("image", m_img.group(1).strip(), m_img.group(2).strip()))
            i += 1
            continue

        if re.match(r"^([-*_])\1{2,}$", s):
            out.append(("hr",))
            i += 1
            continue

        if s.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip()[1:].strip())
                i += 1
            out.append(("quote", _join([b for b in buf if b])))
            continue

        if s.startswith("|"):
            rows: list[list[str]] = []
            while i < n and lines[i].strip().startswith("|"):
                row = lines[i].strip()
                i += 1
                if re.match(r"^\|[\s:\-|]+\|$", row):
                    continue
                rows.append([c.strip() for c in row.strip("|").split("|")])
            if rows:
                out.append(("table", rows))
            continue

        m = re.match(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$", raw)
        if m:
            level = len(m.group(1).expandtabs(4)) // 2
            out.append(("list", level, m.group(2)[0].isdigit(), m.group(3).strip()))
            i += 1
            continue

        buf = [s]
        i += 1
        while i < n:
            t = lines[i].strip()
            if (not t or t.startswith(("#", "|", ">", "```"))
                    or re.match(r"^(\s*)([-*+]|\d+[.)])\s+", lines[i])):
                break
            buf.append(t)
            i += 1
        out.append(("para", _join(buf)))
    return out


# --------------------------------------------------------------------------
# docx（OOXML）拼装
# --------------------------------------------------------------------------
_XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
_NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
       'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
       'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
       'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
       'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"')
_INLINE = re.compile(r"(\*\*.+?\*\*|\*[^*\n]+\*|`[^`]+`)")


def _esc(t: str) -> str:
    return _html.escape(t, quote=False)


def _runs(text: str, *, bold: bool = False, mono: bool = False) -> str:
    """把一行里的 **粗体** 与 `代码` 变成多个 run。"""
    parts: list[str] = []
    for piece in _INLINE.split(text):
        if not piece:
            continue
        b, m, i = bold, mono, False
        if len(piece) > 4 and piece.startswith("**") and piece.endswith("**"):
            piece, b = piece[2:-2], True
        elif len(piece) > 2 and piece.startswith("*") and piece.endswith("*"):
            piece, i = piece[1:-1], True
        elif len(piece) > 2 and piece.startswith("`") and piece.endswith("`"):
            piece, m = piece[1:-1], True
        rpr = ""
        if b:
            rpr += "<w:b/>"
        if i:
            rpr += "<w:i/>"
        if m:
            rpr += ('<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" '
                    'w:eastAsia="Microsoft YaHei"/><w:color w:val="2B4A6F"/>')
        if rpr:
            rpr = f"<w:rPr>{rpr}</w:rPr>"
        parts.append(f'<w:r>{rpr}<w:t xml:space="preserve">{_esc(piece)}</w:t></w:r>')
    return "".join(parts) or '<w:r><w:t xml:space="preserve"></w:t></w:r>'


def _para(text: str = "", *, style: str | None = None, bold: bool = False,
          mono: bool = False, indent: int = 0, before: int = 0, after: int = 120,
          align: str | None = None, shade: str | None = None,
          shade_size: int | None = None) -> str:
    ppr = ""
    if style:
        ppr += f'<w:pStyle w:val="{style}"/>'
    if indent:
        ppr += f'<w:ind w:left="{indent}"/>'
    if before or after:
        ppr += f'<w:spacing w:before="{before}" w:after="{after}"/>'
    if align:
        ppr += f'<w:jc w:val="{align}"/>'
    if shade:
        ppr += f'<w:shd w:val="clear" w:color="auto" w:fill="{shade}"/>'
    if ppr:
        ppr = f"<w:pPr>{ppr}</w:pPr>"
    if not text:
        return f"<w:p>{ppr}</w:p>"
    rpr = ""
    if mono or shade_size:
        rpr += '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Microsoft YaHei"/>'
    if shade_size:
        rpr += f'<w:sz w:val="{shade_size}"/><w:szCs w:val="{shade_size}"/>'
        rpr += '<w:color w:val="333333"/>'
    if rpr:
        rpr = f"<w:rPr>{rpr}</w:rPr>"
    body = _runs(text, bold=bold, mono=mono) if not rpr else (
        f'<w:r>{rpr}<w:t xml:space="preserve">{_esc(text)}</w:t></w:r>')
    return f"<w:p>{ppr}{body}</w:p>"


def _table(rows: list[list[str]]) -> str:
    cols = max(len(r) for r in rows)
    width = 9360 // cols
    grid = "".join(f'<w:gridCol w:w="{width}"/>' for _ in range(cols))
    borders = (
        '<w:tblBorders>'
        '<w:top w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '<w:left w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '<w:right w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="D5DDEA"/>'
        '</w:tblBorders>')
    out = [f'<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>{borders}</w:tblPr>'
           f"<w:tblGrid>{grid}</w:tblGrid>"]
    for r, row in enumerate(rows):
        out.append("<w:tr>")
        for c in range(cols):
            cell = row[c] if c < len(row) else ""
            shade = '<w:shd w:val="clear" w:color="auto" w:fill="EEF2F8"/>' if r == 0 else ""
            para = _para(cell, bold=(r == 0), after=20)
            out.append(f'<w:tc><w:tcPr><w:tcW w:w="{width}" w:type="dxa"/>{shade}</w:tcPr>'
                       f"{para}</w:tc>")
        out.append("</w:tr>")
    out.append("</w:tbl>")
    out.append('<w:p><w:pPr><w:spacing w:after="120"/></w:pPr></w:p>')
    return "".join(out)


def _png_size(data: bytes) -> tuple[int, int]:
    """从 PNG 头部读像素尺寸；读不出来就按 4:3 估。"""
    if len(data) > 24 and data[:8] == b"\x89PNG\r\n\x1a\n":
        import struct

        w, h = struct.unpack(">II", data[16:24])
        if w and h:
            return int(w), int(h)
    return 1200, 900


def _image_para(rid: str, cx: int, cy: int, alt: str, idx: int) -> str:
    return (
        '<w:p><w:pPr><w:jc w:val="center"/><w:spacing w:before="120" w:after="60"/></w:pPr>'
        '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
        f'<wp:extent cx="{cx}" cy="{cy}"/>'
        f'<wp:docPr id="{idx}" name="Picture {idx}" descr="{_esc(alt)}"/>'
        '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic><pic:nvPicPr>'
        f'<pic:cNvPr id="{idx}" name="image{idx}.png"/><pic:cNvPicPr/>'
        '</pic:nvPicPr><pic:blipFill>'
        f'<a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch>'
        '</pic:blipFill><pic:spPr>'
        '<a:xfrm><a:off x="0" y="0"/>'
        f'<a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
        '</pic:spPr></pic:pic></a:graphicData></a:graphic>'
        '</wp:inline></w:drawing></w:r></w:p>')


def _collect_images(blocks: list[tuple], base_dir: Path | None):
    """把 Markdown 里引用的图片收进 docx 的 media/，返回 (映射, 文件列表, 扩展名集合)。"""
    imgs: dict[str, tuple[str, str, int, int]] = {}
    files: list[tuple[str, bytes]] = []
    exts: set[str] = set()
    idx = 0
    for b in blocks:
        if b[0] != "image":
            continue
        src = b[2]
        if src in imgs:
            continue
        f = (base_dir or Path(".")) / src
        if not f.is_file():
            continue
        idx += 1
        data = f.read_bytes()
        ext = f.suffix.lower().lstrip(".") or "png"
        exts.add(ext)
        w, h = _png_size(data)
        width_emu = 5_580_000                      # 15.5 cm，A4 版心内
        cy = int(width_emu * h / max(1, w))
        if cy > 7_020_000:                          # 高于 19.5 cm 就按高度收
            cy = 7_020_000
            width_emu = int(cy * w / max(1, h))
        target = f"media/image{idx}.{ext}"
        rid = f"rIdImg{idx}"
        imgs[src] = (rid, target, width_emu, cy)
        files.append((target, data))
    return imgs, files, exts


def _body(blocks: list[tuple], imgs: dict | None = None) -> str:
    out: list[str] = []
    counters: dict[int, int] = {}
    for b in blocks:
        kind = b[0]
        if kind == "heading":
            level, text = b[1], b[2]
            style = {1: "Title", 2: "Heading1", 3: "Heading2"}.get(level, "Heading3")
            out.append(_para(text, style=style, before=240 if level > 1 else 0))
        elif kind == "para":
            text = b[1]
            if text.startswith("图 ") and len(text) < 220:
                out.append(_para(text, style="Caption", align="center"))
            else:
                out.append(_para(text))
        elif kind == "quote":
            out.append(_para(b[1], style="ReportQuote"))
        elif kind == "list":
            level, ordered, text = b[1], b[2], b[3]
            if ordered:
                counters[level] = counters.get(level, 0) + 1
                prefix = f"{counters[level]}. "
            else:
                prefix = "• "
            out.append(_para(prefix + text, indent=360 * (level + 1), after=40))
        elif kind == "table":
            out.append(_table(b[1]))
        elif kind == "code":
            for line in b[1] or [""]:
                out.append(_para(line, mono=True, shade_size=18, shade="F4F6FA", after=0))
            out.append(_para("", after=60))
        elif kind == "image":
            alt, src = b[1], b[2]
            info = (imgs or {}).get(src)
            if info is None:
                out.append(_para(alt, align="center"))
            else:
                rid, _target, cx, cy = info
                out.append(_image_para(rid, cx, cy, alt, abs(hash(src)) % 10000 + 1))
        elif kind == "hr":
            out.append(_para("", after=0))
    return "".join(out)


def _styles() -> str:
    def style(sid: str, name: str, *, size: int | None = None, bold=False,
              color: str | None = None, italic=False, before=0, after=120,
              base="Normal") -> str:
        rpr = ""
        if bold:
            rpr += "<w:b/>"
        if italic:
            rpr += "<w:i/>"
        if color:
            rpr += f'<w:color w:val="{color}"/>'
        if size:
            rpr += f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>'
        return (f'<w:style w:type="paragraph" w:styleId="{sid}">'
                f'<w:name w:val="{name}"/><w:basedOn w:val="{base}"/>'
                f'<w:next w:val="Normal"/><w:qFormat/>'
                f'<w:pPr><w:spacing w:before="{before}" w:after="{after}"/></w:pPr>'
                f'<w:rPr>{rpr}</w:rPr></w:style>')

    return (
        _XML_HEAD
        + f'<w:styles {_NS}>'
        "<w:docDefaults><w:rPrDefault><w:rPr>"
        '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Microsoft YaHei" w:cs="Calibri"/>'
        '<w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="en-US" w:eastAsia="zh-CN"/>'
        "</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr>"
        '<w:spacing w:after="120" w:line="288" w:lineRule="auto"/>'
        "</w:pPr></w:pPrDefault></w:docDefaults>"
        '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
        '<w:name w:val="Normal"/><w:qFormat/></w:style>'
        + style("Title", "Title", size=40, bold=True, color="1F2A44", after=280)
        + style("Heading1", "heading 1", size=32, bold=True, color="1F3864", before=320, after=140)
        + style("Heading2", "heading 2", size=26, bold=True, color="2E4A7D", before=240, after=120)
        + style("Heading3", "heading 3", size=22, bold=True, color="34507F", before=200, after=100)
        + style("ReportQuote", "Report Quote", size=19, color="6B7A90", italic=True, after=120)
        + style("Caption", "caption", size=18, color="6B7A90", before=40, after=180)
        + "</w:styles>")


def _document(blocks: list[tuple], title: str, imgs: dict | None = None) -> str:
    sect = ('<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
            '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" '
            'w:header="851" w:footer="992" w:gutter="0"/></w:sectPr>')
    return (_XML_HEAD
            + f"<w:document {_NS}><w:body>"
            + _body(blocks, imgs)
            + sect + "</w:body></w:document>")


def _core(title: str) -> str:
    now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return (_XML_HEAD
            + '<cp:coreProperties '
              'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
              'xmlns:dc="http://purl.org/dc/elements/1.1/" '
              'xmlns:dcterms="http://purl.org/dc/terms/" '
              'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f"<dc:title>{_esc(title)}</dc:title>"
            "<dc:creator>flightlog-autopsy</dc:creator>"
            "<cp:lastModifiedBy>flightlog-autopsy</cp:lastModifiedBy>"
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
            "</cp:coreProperties>")


_CONTENT_TYPES = (
    _XML_HEAD
    + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/word/document.xml" '
    'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
    '<Override PartName="/word/styles.xml" '
    'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
    '<Override PartName="/docProps/core.xml" '
    'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
    "</Types>")

_ROOT_RELS = (
    _XML_HEAD
    + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" '
    'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
    'Target="word/document.xml"/>'
    '<Relationship Id="rId2" '
    'Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
    'Target="docProps/core.xml"/>'
    "</Relationships>")

def _doc_rels(imgs: dict | None = None) -> str:
    rels = [
        '<Relationship Id="rId1" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>'
    ]
    for _src, (rid, target, _cx, _cy) in (imgs or {}).items():
        rels.append(f'<Relationship Id="{rid}" '
                    'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
                    f'Target="{target}"/>')
    return (_XML_HEAD
            + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + "".join(rels) + "</Relationships>")


_IMG_TYPES = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}


def markdown_to_docx(md: str, path: str | Path, title: str = "飞行事故分析报告",
                     base_dir: str | Path | None = None) -> Path:
    """把 Markdown 报告写成 .docx；图片按 ``base_dir`` 解析成相对路径。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    blocks = _blocks(md)
    imgs, files, exts = _collect_images(blocks, Path(base_dir) if base_dir else p.parent)
    ct = _CONTENT_TYPES.replace(
        "</Types>",
        "".join(f'<Default Extension="{e}" ContentType="{_IMG_TYPES.get(e, "image/png")}"/>'
                for e in sorted(exts)) + "</Types>")
    with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", _ROOT_RELS)
        z.writestr("word/document.xml", _document(blocks, title, imgs))
        z.writestr("word/_rels/document.xml.rels", _doc_rels(imgs))
        z.writestr("word/styles.xml", _styles())
        z.writestr("docProps/core.xml", _core(title))
        for target, data in files:
            z.writestr(f"word/{target}", data)
    return p


# --------------------------------------------------------------------------
# 独立 HTML（可打印成 PDF）
# --------------------------------------------------------------------------
_HTML_SHELL = """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  :root {{ color-scheme: light; }}
  body {{ margin: 0; padding: 40px 24px 64px; background: #f5f7fa;
         font: 15px/1.75 -apple-system, "Segoe UI", "Microsoft YaHei", "PingFang SC", sans-serif;
         color: #1f2937; }}
  main {{ max-width: 860px; margin: 0 auto; background: #fff; padding: 48px 56px 56px;
          border-radius: 10px; box-shadow: 0 2px 18px rgba(16,32,64,.08); }}
  h1 {{ font-size: 26px; margin: 0 0 18px; color: #12233f; }}
  h2 {{ font-size: 20px; margin: 32px 0 12px; padding-left: 10px; border-left: 4px solid #4f8cff;
        color: #14294a; }}
  h3 {{ font-size: 16px; margin: 22px 0 8px; color: #1b3358; }}
  p {{ margin: 8px 0; }}
  .figure {{ text-align: center; margin: 20px 0 4px; break-inside: avoid; }}
  .figure img {{ max-width: 100%; height: auto; display: block; margin: 0 auto; }}
  p > em:only-child {{ display: block; text-align: center; color: #6b7a90; font-size: .92em; }}
  blockquote {{ margin: 0 0 24px; padding: 10px 14px; background: #f2f6fd; border-radius: 6px;
                color: #4b5c74; font-size: 13px; }}
  code {{ background: #eef2f8; padding: 1px 5px; border-radius: 4px;
          font: 13px/1.5 Consolas, "SFMono-Regular", monospace; color: #24425f; }}
  table {{ border-collapse: collapse; width: 100%; margin: 12px 0 20px; font-size: 14px; }}
  th, td {{ border: 1px solid #dbe3ee; padding: 7px 10px; text-align: left; vertical-align: top; }}
  th {{ background: #eef2f8; font-weight: 600; }}
  ul, ol {{ margin: 8px 0 14px; padding-left: 22px; }}
  li {{ margin: 4px 0; }}
  hr {{ border: 0; border-top: 1px solid #e3e9f2; margin: 26px 0; }}
  @media print {{
    body {{ background: #fff; padding: 0; }}
    main {{ box-shadow: none; border-radius: 0; padding: 0 4mm; max-width: none; }}
    h2, h3 {{ break-after: avoid; }}
    table, li, p {{ break-inside: avoid; }}
    @page {{ size: A4; margin: 16mm 14mm; }}
  }}
</style>
</head>
<body><main>
{body}
</main></body></html>
"""


def inline_images(body: str, base_dir: Path | None) -> str:
    """把 <img src="..."> 换成 data URI，HTML 才能单文件带走。"""
    import base64

    if base_dir is None:
        return body

    def repl(m):
        src = m.group(1)
        f = base_dir / src
        if not (f.is_file() and f.suffix.lower() in (".png", ".jpg", ".jpeg")):
            return m.group(0)
        mime = "image/png" if f.suffix.lower() == ".png" else "image/jpeg"
        data = base64.b64encode(f.read_bytes()).decode("ascii")
        return f'src="data:{mime};base64,{data}"'

    return re.sub(r'src="([^"]+)"', repl, body)


def markdown_to_html(md: str, path: str | Path, title: str = "飞行事故分析报告",
                     base_dir: str | Path | None = None) -> Path:
    """把 Markdown 报告写成独立 HTML（浏览器打印即可另存 PDF）。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    body = inline_images(md_to_html(md), Path(base_dir) if base_dir else None)
    p.write_text(_HTML_SHELL.format(title=_esc(title), body=body), encoding="utf-8")
    return p


def save_documents(md: str, base: str | Path, title: str = "飞行事故分析报告",
                   *, markdown: bool = False,
                   base_dir: str | Path | None = None) -> dict[str, Path]:
    """以 ``base`` 为落点同时写 docx/html（可选 md），返回各文件的路径。"""
    b = Path(base)
    b = b.with_suffix("") if b.suffix.lower() in {".md", ".docx", ".html"} else b
    out = {
        "html": markdown_to_html(md, b.with_name(b.name + ".html"), title, base_dir),
        "docx": markdown_to_docx(md, b.with_name(b.name + ".docx"), title, base_dir),
    }
    if markdown:
        mp = b.with_name(b.name + ".md")
        mp.write_text(md, encoding="utf-8")
        out["md"] = mp
    return out
