"""规范化飞行日志数据模型。

设计目标：把 ArduPilot(.bin/.log)、PX4(.ulg)、CSV 等不同来源的日志，
统一成同一套"信号（canonical signal）"，让检测器只写一遍。

约定
----
* 时间轴 ``t`` 一律为 **相对日志起点的秒数**（float64），单调不减。
* 角度单位为 **度**，角速度为 **rad/s**，加速度为 **m/s²**。
* 缺失的信号就是不存在：检测器必须自己 ``if not log.has(...)`` 跳过，
  而不是用 0 填充（用 0 填出来的结论一定是错的）。
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

#: 规范信号表：name -> (单位, 中文说明)
SIGNALS: dict[str, tuple[str, str]] = {
    "att.roll": ("deg", "横滚角"),
    "att.pitch": ("deg", "俯仰角"),
    "att.yaw": ("deg", "偏航角"),
    "att.des_roll": ("deg", "期望横滚角"),
    "att.des_pitch": ("deg", "期望俯仰角"),
    "att.err_rp": ("deg", "姿态跟踪误差(RP 合成)"),
    "gyro.x": ("rad/s", "机体 X 轴角速度"),
    "gyro.y": ("rad/s", "机体 Y 轴角速度"),
    "gyro.z": ("rad/s", "机体 Z 轴角速度"),
    "acc.x": ("m/s²", "机体 X 轴加速度"),
    "acc.y": ("m/s²", "机体 Y 轴加速度"),
    "acc.z": ("m/s²", "机体 Z 轴加速度"),
    "acc.mag": ("m/s²", "加速度模长"),
    "vibe.x": ("m/s²", "X 轴振动"),
    "vibe.y": ("m/s²", "Y 轴振动"),
    "vibe.z": ("m/s²", "Z 轴振动"),
    "vibe.pk": ("m/s²", "三轴振动峰值"),
    "vibe.clip0": ("次", "IMU0 削顶计数"),
    "vibe.clip1": ("次", "IMU1 削顶计数"),
    "vibe.clip2": ("次", "IMU2 削顶计数"),
    "alt.rel": ("m", "相对起飞点高度"),
    "alt.baro": ("m", "气压高度"),
    "alt.gps": ("m", "GPS 高度"),
    "pos.lat": ("deg", "纬度"),
    "pos.lng": ("deg", "经度"),
    "vel.vert": ("m/s", "垂直速度"),
    "vel.ground": ("m/s", "地速"),
    "bat.volt": ("V", "电池电压"),
    "bat.curr": ("A", "电池电流"),
    "gps.sats": ("颗", "可见卫星数"),
    "gps.hdop": ("", "水平精度因子"),
    "gps.fix": ("", "定位状态(0-6)"),
    "rc.thr": ("us", "遥控油门输入"),
    "out.pwm": ("us", "执行器输出(多路)"),
    "ekf.ivn": ("", "EKF 北向新息"),
    "ekf.ive": ("", "EKF 东向新息"),
    "ekf.ipn": ("", "EKF 北向新息方差"),
    "ekf.ipe": ("", "EKF 东向新息方差"),
    "mag.strength": ("mGauss", "磁场强度"),
    "cpu.load": ("%", "CPU 负载"),
    "loop.max": ("ms", "主循环最大耗时"),
}


# --------------------------------------------------------------------------- #
# 基础容器
# --------------------------------------------------------------------------- #
def _f64(x: Any) -> np.ndarray:
    return np.asarray(x, dtype=np.float64).ravel()


@dataclass
class Series:
    """一条等间隔/不等间隔的时间序列。"""

    name: str
    t: np.ndarray
    y: np.ndarray
    unit: str = ""
    desc: str = ""
    source: str = ""  # 原始消息名，例如 "VIBE.VibeZ" / "sensor_combined.gyro_rad[0]"

    def __post_init__(self) -> None:
        self.t = _f64(self.t)
        self.y = _f64(self.y)
        n = min(self.t.size, self.y.size)
        self.t, self.y = self.t[:n], self.y[:n]
        if self.t.size > 1 and not np.all(np.diff(self.t) >= 0):
            order = np.argsort(self.t)
            self.t, self.y = self.t[order], self.y[order]
        if not self.unit:
            self.unit = SIGNALS.get(self.name, ("", ""))[0]
        if not self.desc:
            self.desc = SIGNALS.get(self.name, ("", ""))[1]

    # -- 基本属性 --------------------------------------------------------- #
    def __len__(self) -> int:
        return int(self.t.size)

    def __bool__(self) -> bool:
        return self.t.size > 0

    @property
    def t0(self) -> float:
        return float(self.t[0]) if self.t.size else 0.0

    @property
    def t1(self) -> float:
        return float(self.t[-1]) if self.t.size else 0.0

    def copy(self) -> "Series":
        return Series(self.name, self.t.copy(), self.y.copy(), self.unit, self.desc, self.source)

    def finite(self) -> "Series":
        m = np.isfinite(self.y)
        return Series(self.name, self.t[m], self.y[m], self.unit, self.desc, self.source)

    # -- 取数 ------------------------------------------------------------- #
    def window(self, t0: float | None = None, t1: float | None = None) -> "Series":
        t0 = self.t0 if t0 is None else t0
        t1 = self.t1 if t1 is None else t1
        m = (self.t >= t0) & (self.t <= t1)
        return Series(self.name, self.t[m], self.y[m], self.unit, self.desc, self.source)

    def interp(self, tq: Sequence[float] | np.ndarray | float) -> np.ndarray:
        """线性插值；超出范围取端点值（事故分析里比 NaN 更好用）。"""
        tq_arr = np.atleast_1d(_f64(tq))
        if self.t.size == 0:
            return np.full(tq_arr.shape, np.nan)
        if self.t.size == 1:
            return np.full(tq_arr.shape, float(self.y[0]))
        return np.interp(tq_arr, self.t, self.y)

    def at(self, t: float) -> float:
        return float(self.interp(t)[0])

    def value_near(self, t: float, tol: float = 0.5) -> float:
        if self.t.size == 0:
            return math.nan
        i = int(np.searchsorted(self.t, t))
        i = min(max(i, 0), self.t.size - 1)
        j = max(i - 1, 0)
        k = i if abs(self.t[i] - t) <= abs(self.t[j] - t) else j
        if abs(self.t[k] - t) > tol:
            return math.nan
        return float(self.y[k])

    # -- 统计 ------------------------------------------------------------- #
    def stat(self, t0: float | None = None, t1: float | None = None) -> dict[str, Any]:
        s = self.window(t0, t1).finite()
        if not len(s):
            return {"n": 0}
        y = s.y
        return {
            "n": int(y.size),
            "min": float(np.min(y)),
            "max": float(np.max(y)),
            "mean": float(np.mean(y)),
            "p95": float(np.percentile(y, 95)),
            "p05": float(np.percentile(y, 5)),
            "max_abs": float(np.max(np.abs(y))),
            "std": float(np.std(y)),
            "last": float(y[-1]),
            "argmax_t": float(s.t[int(np.argmax(y))]),
            "argmin_t": float(s.t[int(np.argmin(y))]),
        }

    def above(self, thr: float, min_dur: float = 1.0) -> list[tuple[float, float]]:
        """返回持续超过阈值的区间 [(t_start, t_end), ...]。"""
        if self.t.size == 0:
            return []
        mask = self.y >= thr
        return _runs(self.t, mask, min_dur)

    def below(self, thr: float, min_dur: float = 1.0) -> list[tuple[float, float]]:
        if self.t.size == 0:
            return []
        mask = self.y <= thr
        return _runs(self.t, mask, min_dur)


def _runs(t: np.ndarray, mask: np.ndarray, min_dur: float) -> list[tuple[float, float]]:
    """把布尔掩码转成持续区间，按 min_dur 过滤。"""
    out: list[tuple[float, float]] = []
    if t.size == 0:
        return out
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return out
    start = prev = idx[0]
    for i in idx[1:]:
        if i == prev + 1:
            prev = i
            continue
        if t[prev] - t[start] >= min_dur:
            out.append((float(t[start]), float(t[prev])))
        start = prev = i
    if t[prev] - t[start] >= min_dur:
        out.append((float(t[start]), float(t[prev])))
    return out


@dataclass
class Event:
    """日志中的离散事件（解锁、模式切换、失控保护、错误码、文本消息）。"""

    t: float
    kind: str  # arm | disarm | mode | failsafe | error | msg | impact | land | other
    detail: str
    severity: str = "info"  # info | warn | critical
    source: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"t": round(self.t, 3), "kind": self.kind, "detail": self.detail,
                "severity": self.severity, "source": self.source}


# --------------------------------------------------------------------------- #
# 飞行日志
# --------------------------------------------------------------------------- #
@dataclass
class FlightLog:
    path: Path
    firmware: str = "unknown"          # ArduPilot / PX4 / CSV / unknown
    log_format: str = ""               # .bin / .ulg / .csv
    meta: dict[str, Any] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)
    series: dict[str, Series] = field(default_factory=dict)
    #: 分类时间线：name -> (t[], labels[])
    cat: dict[str, tuple[np.ndarray, list[str]]] = field(default_factory=dict)
    events: list[Event] = field(default_factory=list)
    t_end: float = 0.0
    warnings: list[str] = field(default_factory=list)
    #: 原始消息计数，用于"日志是否完整"的判断
    message_counts: dict[str, int] = field(default_factory=dict)

    # -- 信号访问 --------------------------------------------------------- #
    def has(self, *names: str) -> bool:
        return all(n in self.series and len(self.series[n]) > 0 for n in names)

    def any_of(self, *names: str) -> str | None:
        for n in names:
            if self.has(n):
                return n
        return None

    def get(self, name: str) -> Series | None:
        s = self.series.get(name)
        return s if s is not None and len(s) else None

    def family(self, base: str) -> list[Series]:
        """返回同一信号的所有实例，例如 ``vibe.x``、``vibe.x#2``（双 IMU 日志）。"""
        out = []
        for name, s in self.series.items():
            if name == base or name.startswith(base + "#"):
                if len(s):
                    out.append(s)
        out.sort(key=lambda s: s.name)
        return out

    def add(self, s: Series | None) -> None:
        if s is None or not len(s):
            return
        old = self.series.get(s.name)
        if old is None or len(s) >= len(old):
            self.series[s.name] = s

    def cat_at(self, name: str, t: float) -> str | None:
        item = self.cat.get(name)
        if not item:
            return None
        ts, labels = item
        if ts.size == 0:
            return None
        i = int(np.searchsorted(ts, t, side="right")) - 1
        i = min(max(i, 0), len(labels) - 1)
        return labels[i]

    def cat_current(self, name: str) -> str | None:
        return self.cat_at(name, self.t_end)

    # -- 事件 ------------------------------------------------------------- #
    def events_of(self, *kinds: str) -> list[Event]:
        if not kinds:
            return list(self.events)
        return [e for e in self.events if e.kind in kinds]

    def first_event(self, *kinds: str) -> Event | None:
        evs = sorted(self.events_of(*kinds), key=lambda e: e.t)
        return evs[0] if evs else None

    def last_event(self, *kinds: str) -> Event | None:
        evs = sorted(self.events_of(*kinds), key=lambda e: e.t)
        return evs[-1] if evs else None

    def armed_intervals(self) -> list[tuple[float, float]]:
        """解锁区间。

        优先用 arm/disarm 事件；老固件/部分日志没有 arm 事件时，退化为
        "电机输出大于怠速"的区间；再不行就认为整段都在解锁状态。
        """
        arms = self.events_of("arm")
        dis = self.events_of("disarm")
        if arms:
            out: list[tuple[float, float]] = []
            for a in sorted(arms, key=lambda e: e.t):
                end = self.t_end
                for d in sorted(dis, key=lambda e: e.t):
                    if d.t > a.t:
                        end = d.t
                        break
                if end > a.t:
                    out.append((a.t, end))
            if out:
                return out

        # 退化：看电机输出是否在转
        motor = self.get("out.pwm")
        if motor is None:
            for k in sorted(self.series):
                if k.startswith("out.c"):
                    motor = self.get(k)
                    if motor is not None:
                        break
        if motor is not None:
            runs = motor.above(1100.0, min_dur=5.0)
            if runs:
                return runs

        return [(0.0, self.t_end)]

    @property
    def t_incident(self) -> float | None:
        """最早的结构性异常时刻（推力损失/急停/撞击）。

        飞行品质类统计应当只统计到这个时刻之前，否则坠机瞬间的冲击会把
        "飞行中是否正常"的结论完全带偏。
        """
        ts = [e.t for e in self.events if e.kind in ("impact", "estop", "thrust_loss")]
        if ts:
            return float(min(ts))
        crashed = [e.t for e in self.events if "crash" in e.kind]
        return float(min(crashed)) if crashed else None

    @property
    def t_quality_end(self) -> float:
        ti = self.t_incident
        return self.t_end if ti is None else min(self.t_end, ti)

    def slice(self, t0: float = 0.0, t1: float | None = None) -> "FlightLog":
        """时间切片：返回只含 [t0,t1] 的浅拷贝，供"飞行品质"类检测器使用。"""
        t1 = self.t_end if t1 is None else float(t1)
        if t0 <= 0.0 and t1 >= self.t_end:
            return self
        out = FlightLog(path=self.path, firmware=self.firmware, log_format=self.log_format,
                        meta=dict(self.meta), params=dict(self.params), t_end=t1,
                        warnings=list(self.warnings), message_counts=dict(self.message_counts))
        for name, s in self.series.items():
            w = s.window(t0, t1)
            if len(w):
                out.series[name] = w
        for name, (ts, labels) in self.cat.items():
            keep = [i for i, t in enumerate(ts) if t0 <= t <= t1]
            if keep:
                out.cat[name] = (np.asarray([ts[i] for i in keep], dtype=np.float64),
                                 [labels[i] for i in keep])
        out.events = [e for e in self.events if t0 <= e.t <= t1]
        return out

    @property
    def flight_end(self) -> float:
        """最后一段解锁的结束时刻（大致等于坠机/着陆时刻）。"""
        iv = self.armed_intervals()
        return iv[-1][1] if iv else self.t_end

    # -- 架次 ------------------------------------------------------------- #
    def sessions(self) -> list[dict]:
        """把日志按"解锁→上锁"切成架次。

        一个 .bin 里常常有好几段飞行（试飞、检修后复飞…），报告按架次分开写才
        不会把上一架次的振动/电压算到事故架次头上。
        """
        ivs = self.armed_intervals()
        if not ivs:
            return []
        dis = sorted(e.t for e in self.events_of("disarm"))
        out: list[dict] = []
        for i, (a0, a1) in enumerate(ivs):
            alt = self.any_of("alt.rel", "alt.ctun", "alt.baro", "alt.gps")
            max_alt = None
            if alt:
                seg = self.get(alt).window(a0, a1)
                if len(seg.y):
                    y = seg.y if alt == "alt.rel" else seg.y - seg.y[0]
                    max_alt = float(y.max())
            labeled = self.cat_at("mode", a0)
            closed = any(abs(d - a1) < 2.0 for d in dis)
            out.append({
                "index": i + 1,
                "t_start": float(a0),
                "t_end": float(a1),
                "dur": float(a1 - a0),
                "max_alt_m": max_alt,
                "mode_start": labeled,
                "end": "disarm" if closed else "interrupted",
            })
        return out

    # -- 概要 ------------------------------------------------------------- #
    def duration(self) -> float:
        return float(self.t_end)

    def add_event(self, e: Event) -> None:
        self.events.append(e)

    def sort_events(self) -> None:
        order = {"critical": 0, "warn": 1, "info": 2}
        self.events.sort(key=lambda e: (e.t, order.get(e.severity, 3)))

    def to_meta_dict(self) -> dict[str, Any]:
        d = dict(self.meta)
        d.update({
            "path": str(self.path),
            "firmware": self.firmware,
            "log_format": self.log_format,
            "duration_s": round(self.t_end, 2),
            "series_count": len(self.series),
            "event_count": len(self.events),
            "warnings": list(self.warnings),
        })
        return d


# --------------------------------------------------------------------------- #
# 分析结果
# --------------------------------------------------------------------------- #
SEVERITY_ORDER = {"critical": 0, "warn": 1, "info": 2}


@dataclass
class Finding:
    """一条检测结论。"""

    id: str
    title: str
    category: str = "其它"        # 动力/导航/姿态/机械/操作/环境/通信/电气
    severity: str = "info"
    t_start: float | None = None
    t_end: float | None = None
    evidence: list[str] = field(default_factory=list)
    conclusion: str = ""
    confidence: float = 0.6
    refs: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "title": self.title, "category": self.category,
            "severity": self.severity,
            "t_start": None if self.t_start is None else round(self.t_start, 2),
            "t_end": None if self.t_end is None else round(self.t_end, 2),
            "evidence": list(self.evidence), "conclusion": self.conclusion,
            "confidence": round(self.confidence, 2), "refs": list(self.refs),
        }


@dataclass
class Skipped:
    detector: str
    reason: str


@dataclass
class Analysis:
    log: FlightLog
    findings: list[Finding] = field(default_factory=list)
    skipped: list[Skipped] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    verdict: str = "unknown"
    verdict_text: str = ""
    score: int = 0          # 0-100，越高越"危险"
    tune: dict | None = None   # 调参体检结果（fla.tune.evaluate）

    def sorted_findings(self) -> list[Finding]:
        return sorted(self.findings,
                      key=lambda f: (SEVERITY_ORDER.get(f.severity, 3),
                                     f.t_start if f.t_start is not None else 0))

    def by_severity(self, sev: str) -> list[Finding]:
        return [f for f in self.sorted_findings() if f.severity == sev]

    def to_dict(self) -> dict[str, Any]:
        return {
            "log": self.log.to_meta_dict(),
            "verdict": self.verdict,
            "verdict_text": self.verdict_text,
            "score": self.score,
            "summary": self.summary,
            "findings": [f.to_dict() for f in self.sorted_findings()],
            "skipped": [{"detector": s.detector, "reason": s.reason} for s in self.skipped],
        }


# --------------------------------------------------------------------------- #
# 工具函数
# --------------------------------------------------------------------------- #
def fmt_t(t: float | None, t_end: float | None = None) -> str:
    """把秒数格式化成 ``T+03:21.5``。

    给了 ``t_end`` 且事件落在结束前 30 秒内时，额外标注"相对结束"的时间，
    方便复盘"坠机前 N 秒发生了什么"。
    """
    if t is None or not math.isfinite(t):
        return "—"
    sign = "-" if t < 0 else "+"
    a = abs(t)
    m, s = divmod(a, 60)
    h, m = divmod(int(m), 60)
    base = f"T{sign}{h:d}:{m:02d}:{s:04.1f}" if h else f"T{sign}{m:02d}:{s:04.1f}"
    if t_end is not None and t_end > 0 and abs(t_end - t) <= 30:
        base += f"（相对结束 {t - t_end:+.1f}s）"
    return base


def moving_average(y: np.ndarray, n: int) -> np.ndarray:
    n = max(int(n), 1)
    if n == 1 or y.size == 0:
        return y
    k = np.ones(n) / n
    pad = n // 2
    yp = np.pad(y, (pad, pad), mode="edge")
    return np.convolve(yp, k, mode="valid")[: y.size]


def highpass(y: np.ndarray, n: int) -> np.ndarray:
    """简单高通：原信号减滑动均值。"""
    return y - moving_average(y, n)


def dominant_freq(t: np.ndarray, y: np.ndarray, fmin: float = 5.0, fmax: float = 200.0) -> tuple[float, float]:
    """返回 (主频 Hz, 该频点占比)。用于识别机架共振/桨叶不平衡。"""
    if t.size < 32:
        return 0.0, 0.0
    dt = float(np.median(np.diff(t)))
    if dt <= 0:
        return 0.0, 0.0
    fs = 1.0 / dt
    y = y - np.mean(y)
    n = y.size
    win = np.hanning(n)
    spec = np.abs(np.fft.rfft(y * win))
    freqs = np.fft.rfftfreq(n, d=dt)
    band = (freqs >= fmin) & (freqs <= fmax)
    if not np.any(band):
        return 0.0, 0.0
    idx = np.flatnonzero(band)[int(np.argmax(spec[band]))]
    total = float(np.sum(spec[band]) + 1e-12)
    return float(freqs[idx]), float(spec[idx] / total)
