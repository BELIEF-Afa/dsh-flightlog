"""飞行日志的总体统计：报告第一页的"体检数据"。

这里只做**客观统计**，不下结论；结论全部交给 ``fla.detectors``。
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np

from .model import FlightLog


def _round(x: float | None, n: int = 1) -> float | None:
    if x is None or not math.isfinite(x):
        return None
    return round(float(x), n)


def armed_seconds(log: FlightLog) -> float:
    return sum(max(0.0, b - a) for a, b in log.armed_intervals())


def _max_abs(s, t0=None, t1=None) -> float | None:
    if s is None:
        return None
    st = s.stat(t0, t1)
    return st.get("max_abs")


def _series_peak(s) -> float | None:
    if s is None:
        return None
    st = s.stat()
    return st.get("max")


def distance_flown(log: FlightLog) -> float | None:
    """用 GPS 经纬度估算水平航程（米）。"""
    lat, lng = log.get("pos.lat"), log.get("pos.lng")
    if lat is None or lng is None or len(lat) < 2:
        return None
    # 只在 armed 区间内积分，避免地面静止点漂移
    total = 0.0
    for a, b in log.armed_intervals():
        la = lat.window(a, b)
        ln = lng.window(a, b)
        if len(la) < 2:
            continue
        tq = np.union1d(la.t, ln.t)
        if tq.size < 2:
            continue
        y1 = np.deg2rad(la.interp(tq))
        x1 = np.deg2rad(ln.interp(tq))
        dl = np.diff(y1)
        dn = np.diff(x1) * np.cos(y1[:-1])
        seg = 6371000.0 * np.sqrt(dl ** 2 + dn ** 2)
        seg = seg[seg < 200]  # 丢掉跳点
        total += float(np.sum(seg))
    return total


def mode_timeline(log: FlightLog) -> list[dict[str, Any]]:
    """模式切换时间线（含驻留时长）。"""
    item = log.cat.get("mode")
    out: list[dict[str, Any]] = []
    if not item:
        if "mode" in log.meta and log.meta.get("mode"):
            return [{"mode": log.meta["mode"], "t_start": 0.0, "t_end": log.t_end, "dur": log.t_end}]
        return out
    ts, labels = item
    for i, t in enumerate(ts):
        end = ts[i + 1] if i + 1 < len(ts) else log.t_end
        if end - t < 0.2 and i + 1 < len(ts):
            continue
        out.append({"mode": labels[i], "t_start": float(t), "t_end": float(end),
                    "dur": float(end - t)})
    return out


def coverage(log: FlightLog) -> dict[str, Any]:
    """日志消息覆盖率：哪些消息真正被转成了信号，哪些还没人用。

    这不是"越多越好"，而是让分析者一眼看到**盲区**：比如日志里明明有 RCIN，
    却没被任何规则使用，那"飞手操作"这类结论就没有依据。
    """
    skip = {"PARM", "FMT", "FMTU", "UNIT", "MULT", "MSG", "MODE", "EV", "ERR"}
    used: set[str] = set()
    for s in log.series.values():
        src = s.source or ""
        if src and not src.startswith("derived:"):
            used.add(src.split(".")[0].split("#")[0])   # CTUN#0 → CTUN
    counts = log.message_counts or {}
    unused = sorted(((m, c) for m, c in counts.items() if m not in used and m not in skip),
                    key=lambda x: -x[1])
    return {
        "used_msgs": sorted(used),
        "unused": unused[:12],
        "unused_total": len(unused),
        "msg_total": len(counts),
    }


def build_summary(log: FlightLog) -> dict[str, Any]:
    armed = armed_seconds(log)
    alt = log.any_of("alt.rel", "alt.baro", "alt.gps")
    spd = log.any_of("vel.ground")
    vib = log.get("vibe.pk")
    cpu = log.get("cpu.load")
    sats = log.get("gps.sats")
    volt = log.get("bat.volt")

    # 起飞点/最远点
    max_alt = None
    max_alt_t = None
    if alt:
        s = log.get(alt)
        st = s.stat()
        max_alt, max_alt_t = st.get("max"), st.get("argmax_t")
    max_spd = None
    max_spd_t = None
    if spd:
        st = log.get(spd).stat()
        max_spd, max_spd_t = st.get("max"), st.get("argmax_t")

    modes = mode_timeline(log)
    sess = log.sessions()
    cov = coverage(log)
    summary: dict[str, Any] = {
        "firmware": log.firmware,
        "log_format": log.log_format,
        "duration_s": _round(log.t_end),
        "armed_s": _round(armed),
        "flight_end_s": _round(log.flight_end),
        "distance_m": _round(distance_flown(log), 0),
        "max_alt_m": _round(max_alt),
        "max_alt_t": _round(max_alt_t),
        "alt_signal": alt,
        "max_speed_ms": _round(max_spd),
        "max_speed_t": _round(max_spd_t),
        "max_vibe": _round(_series_peak(vib)),
        "max_cpu_pct": _round(_series_peak(cpu), 0),
        "min_sats": _round(sats.stat().get("min")) if sats else None,
        "volt_min": _round(volt.stat().get("min"), 2) if volt else None,
        "volt_max": _round(volt.stat().get("max"), 2) if volt else None,
        "mode": log.cat_current("mode") or log.meta.get("mode"),
        "sessions": sess,
        "session_count": len(sess),
        "coverage": cov,
        "modes": modes,
        "armed_intervals": [(round(a, 1), round(b, 1)) for a, b in log.armed_intervals()],
        "series_present": sorted(k for k, s in log.series.items() if len(s)),
        "missing": [n for n in ("vibe.pk", "alt.rel", "vel.ground", "bat.volt", "gps.sats")
                    if not log.has(n)],
        "messages": len(log.events_of("msg")),
        "crashed": "crash" in " ".join(e.kind for e in log.events),
    }
    # 关键参数
    keep = ("FRAME_CLASS", "FRAME_TYPE", "ARMING_CHECK", "FS_THR_ENABLE", "FS_GPS_ENABLE",
            "FS_EKF_ACTION", "FENCE_ENABLE", "FENCE_ACTION", "RTL_ALT", "BATT_LOW_VOLT",
            "BATT_CRT_VOLT", "MOT_PWM_MIN", "MOT_PWM_MAX", "INS_LOG_BAT_MASK")
    params = {k: log.params[k] for k in keep if k in log.params}
    summary["params"] = params
    summary["vehicle"] = log.meta.get("vehicle") or log.meta.get("frame")
    return summary


def summary_table(summary: dict[str, Any]) -> list[tuple[str, str]]:
    """给报告用的"一行一项"表格。"""
    def f(v, unit="", nd=1):
        if v is None:
            return "—"
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            if nd == 0:
                return f"{v:.0f}{unit}"
            return f"{v:.{nd}f}{unit}"
        return f"{v}{unit}"

    rows = [
        ("固件 / 日志", f"{summary.get('firmware')} / {summary.get('log_format')}"),
        ("机型", str(summary.get("vehicle") or "—")),
        ("日志时长", f(summary.get("duration_s"), " s")),
        ("解锁时长", f(summary.get("armed_s"), " s")),
        ("最终模式", str(summary.get("mode") or "—")),
        ("最大高度", f(summary.get("max_alt_m"), " m")),
        ("最大地速", f(summary.get("max_speed_ms"), " m/s")),
        ("航程", f(summary.get("distance_m"), " m", 0)),
        ("最大振动峰值", f(summary.get("max_vibe"), " m/s²")),
        ("CPU 峰值", f(summary.get("max_cpu_pct"), " %", 0)),
        ("最低卫星数", f(summary.get("min_sats"), " 颗", 0)),
        ("电池电压范围", f"{f(summary.get('volt_min'), ' V', 2)} – {f(summary.get('volt_max'), ' V', 2)}"),
    ]
    return [(k, v) for k, v in rows]
