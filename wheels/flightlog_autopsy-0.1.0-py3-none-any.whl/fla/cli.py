"""命令行入口：``python -m fla.cli analyze log.bin --llm``。"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

from . import __version__
from .analyzer import analyze
from .llm import LLMConfig, LLMError, config_from_env, narrate, ping
from .export import markdown_to_docx, markdown_to_html
from .model import Analysis, fmt_t
from .figures import build_figures, explain
from .report import render_markdown, write_markdown


# --------------------------------------------------------------------------- #
# 小工具
# --------------------------------------------------------------------------- #
def _c(code: str, s: str, *, enabled: bool) -> str:
    return f"\033[{code}m{s}\033[0m" if enabled else s


def _color_for(sev: str) -> str:
    return {"critical": "31;1", "warn": "33", "info": "36"}.get(sev, "0")


def analysis_to_dict(a: Analysis) -> dict:
    log = a.log
    return {
        "version": __version__,
        "file": Path(log.path).name,
        "firmware": log.firmware,
        "log_format": log.log_format,
        "t_end": round(log.t_end, 2),
        "verdict": a.verdict,
        "score": a.score,
        "verdict_text": a.verdict_text,
        "summary": a.summary,
        "findings": [
            {"id": f.id, "title": f.title, "category": f.category, "severity": f.severity,
             "t_start": f.t_start, "t_end": f.t_end, "time": fmt_t(f.t_start, log.t_end)
             if f.t_start is not None else None,
             "evidence": f.evidence, "conclusion": f.conclusion, "confidence": f.confidence,
             "refs": f.refs}
            for f in a.sorted_findings()
        ],
        "skipped": [{"detector": s.detector, "reason": s.reason} for s in a.skipped],
        "events": [{"t": round(e.t, 3), "kind": e.kind, "detail": e.detail,
                    "severity": e.severity} for e in log.events],
        "message_counts": log.message_counts,
        "params": log.params,
        "warnings": log.warnings,
    }


def _print_analysis(a: Analysis, out_md: Path | None, elapsed: float,
                    color: bool, narrative: dict | None = None) -> None:
    log = a.log
    c = lambda code, s: _c(code, s, enabled=color)  # noqa: E731
    print()
    print(c("1", f"飞控日志分析 · {Path(log.path).name}"))
    s = a.summary
    print(f"  固件 {a.log.firmware or '未知'} · 机型 {s.get('vehicle') or '—'} · "
          f"时长 {s.get('duration_s'):.1f}s · 解锁 {s.get('armed_s'):.1f}s · "
          f"最高 {s.get('max_alt_m') or 0:.1f}m · 航程 {s.get('distance_m') or 0:.0f}m")
    print("  " + "─" * 62)
    print(f"  结论：{c('1', a.verdict)}（{a.score}/100）")
    if narrative and narrative.get("headline"):
        print(f"  模型：{narrative['headline']}")
    print()
    for f in a.sorted_findings():
        tag = c(_color_for(f.severity), f"[{f.severity:8s}]")
        when = f" {fmt_t(f.t_start, log.t_end)}" if f.t_start is not None else ""
        print(f"  {tag} {f.title}{when}")
        for e in f.evidence[:2]:
            print(f"           · {e}")
    if a.skipped:
        print()
        print(f"  未执行的检查 {len(a.skipped)} 项："
              + "、".join(x.detector for x in a.skipped[:8])
              + ("…" if len(a.skipped) > 8 else ""))
    print()
    print(f"  用时 {elapsed:.1f}s")


# --------------------------------------------------------------------------- #
# 子命令
# --------------------------------------------------------------------------- #
def cmd_analyze(args: argparse.Namespace) -> int:
    path = Path(args.log)
    if not path.exists():
        print(f"找不到日志文件：{path}", file=sys.stderr)
        return 2
    t0 = time.time()
    try:
        a = analyze(str(path))
    except Exception as exc:  # 解析失败要给用户看得懂的信息
        print(f"解析失败：{exc}", file=sys.stderr)
        return 3

    narrative = None
    if args.llm:
        cfg = config_from_env(api_key=args.api_key, base_url=args.base_url, model=args.model)
        if cfg is None:
            print("已指定 --llm 但没找到 API Key（--api-key / FLA_API_KEY / DEEPSEEK_API_KEY / "
                  "OPENAI_API_KEY）。先出离线报告。", file=sys.stderr)
        else:
            print(f"  调用大模型 {cfg.model} @ {cfg.base_url} …")
            try:
                narrative = narrate(a, cfg)
                try:  # 核对模型写出的时间/数字是否都在证据包里
                    from .llm import evidence_pack
                    from .verify import check as verify_narrative

                    rep = verify_narrative(narrative, evidence_pack(a), a.log.t_end)
                    if rep["ok"]:
                        print(f"  叙事核对：{rep['times']} 个时间戳、{rep['nums']} 个数字全部可溯源")
                    else:
                        print(f"  叙事核对：{len(rep['bad_times'])} 处时间、{len(rep['bad_nums'])} 处数值"
                              "未在证据包中找到（详见报告的叙事核对一节）")
                except Exception:
                    pass
            except LLMError as exc:
                print(f"大模型调用失败（已回退到离线报告）：{exc}", file=sys.stderr)

    # 报告落点：-o 可以是任意后缀，按 --format 决定实际写哪些文件
    base = Path(args.output) if args.output else (
        Path(args.outdir) / f"{path.stem}_report.md")
    base = base.with_suffix("") if base.suffix.lower() in {".md", ".html", ".docx"} else base
    fmt = getattr(args, "format", "md")
    figs, notes = [], []
    if not getattr(args, "no_figures", False):
        try:
            figs = build_figures(a, base.parent, prefix=f"{base.name}_fig")
            notes = explain(a)
        except Exception as exc:  # 画图失败不该挡住报告
            print(f"  画图失败（跳过）：{exc}", file=sys.stderr)
        if figs:
            print(f"  已生成 {len(figs)} 张图：{'、'.join(x.path.name for x in figs)}")
        if a.tune and a.tune.get("rate"):
            try:
                from .figures import build_tune_figure

                tf = build_tune_figure(a.log, a.tune, base.parent / f"{base.name}_tune.png")
                if tf:
                    a.tune["figure"] = str(tf.path)
                    a.tune["figure_caption"] = tf.caption
                    print(f"  已生成调参图：{tf.path.name}")
            except Exception as exc:
                print(f"  调参图未生成：{exc}", file=sys.stderr)
    md = render_markdown(a, narrative=narrative, figures=figs, notes=notes)
    written: list[Path] = []
    if fmt in ("md", "all"):
        mp = base.with_name(base.name + ".md")
        mp.parent.mkdir(parents=True, exist_ok=True)
        mp.write_text(md, encoding="utf-8")
        written.append(mp)
    if fmt in ("html", "all"):
        written.append(markdown_to_html(md, base.with_name(base.name + ".html"),
                                        base_dir=base.parent))
    if fmt in ("docx", "all"):
        written.append(markdown_to_docx(md, base.with_name(base.name + ".docx"),
                                        base_dir=base.parent))
    for w in written:
        print(f"  报告已写入：{w}")
    if args.json_out:
        jp = Path(args.json_out)
        jp.parent.mkdir(parents=True, exist_ok=True)
        payload = analysis_to_dict(a)
        if narrative:
            payload["narrative"] = {k: v for k, v in narrative.items() if k != "raw_text"}
        jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    md_path = next((w for w in written if w.suffix == ".md"), None)
    _print_analysis(a, md_path, time.time() - t0, color=sys.stdout.isatty(), narrative=narrative)
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print("需要先安装 web 依赖：pip install fastapi uvicorn python-multipart", file=sys.stderr)
        return 2
    os.environ.setdefault("FLA_API_KEY", args.api_key or "")
    os.environ.setdefault("FLA_BASE_URL", args.base_url or "")
    os.environ.setdefault("FLA_MODEL", args.model or "")
    uvicorn.run("fla.web.app:app", host=args.host, port=args.port, reload=args.reload)
    return 0


def cmd_llm(args: argparse.Namespace) -> int:
    cfg = config_from_env(api_key=args.api_key, base_url=args.base_url, model=args.model)
    if cfg is None:
        print("没有找到 API Key。用 --api-key 或环境变量 FLA_API_KEY / DEEPSEEK_API_KEY 提供。",
              file=sys.stderr)
        return 2
    print(f"模型 {cfg.model} · 接口 {cfg.endpoint}")
    try:
        print("响应：", ping(cfg))
    except LLMError as exc:
        print(f"失败：{exc}", file=sys.stderr)
        return 3
    return 0


def cmd_tune(args: argparse.Namespace) -> int:
    from .readers import load
    from .tune import evaluate

    path = Path(args.log)
    if not path.is_file():
        print(f"找不到日志：{path}", file=sys.stderr)
        return 2
    try:
        log = load(path)
    except Exception as exc:
        print(f"解析失败：{exc}", file=sys.stderr)
        return 3
    tune = evaluate(log)
    print(f"调参体检 · {path.name}")
    hz = tune.get("imu_hz")
    print(f"  判定：{tune['verdict']}" + (f"　·　IMU {hz:.0f} Hz" if hz else ""))
    for g in tune["gate"]:
        mark = {"ok": "OK  ", "warn": "WARN", "fail": "FAIL"}.get(g["level"], g["level"].upper())
        print(f"  [{mark}] {g['title']:<10} {g['detail']}")
    if tune.get("rate"):
        r = tune["rate"]
        print(f"  速率环：{r['fs']:.0f} Hz 记录，横滚 RMS {r.get('roll_rms', 0):.2f} °/s")
    if tune.get("delay"):
        d = tune["delay"]
        print(f"  等效延迟：{d['delay_ms']:.0f} ms（相干度 {d['coherence']:.2f}，"
              f"FLTT 贡献 {d['fltt_ms']:.0f} ms）")
    if tune["suggestions"]:
        print("  建议：")
        for sug in tune["suggestions"]:
            print(f"    {sug['param']:<22} {sug['current']} → {sug['suggested']}")
            print(f"      {sug['reason']}")
    if args.json_out:
        import json

        Path(args.json_out).write_text(
            json.dumps(_tune_json(tune), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  已写入 {args.json_out}")
    return 0 if not any(g["level"] == "fail" for g in tune["gate"]) else 2


def _tune_json(tune: dict) -> dict:
    """把 numpy 标量清掉，方便 json.dumps。"""
    import numpy as np

    def clean(v):
        if isinstance(v, dict):
            return {k: clean(x) for k, x in v.items()}
        if isinstance(v, list):
            return [clean(x) for x in v]
        if isinstance(v, (np.floating, np.integer)):
            return v.item()
        return v

    return clean(tune)


def cmd_doctor(_args: argparse.Namespace) -> int:
    print("flightlog-autopsy 环境自检")
    print(f"  版本：{__version__}")
    ok = True
    try:
        import pymavlink  # noqa: F401
        print("  pymavlink：已安装（ArduPilot 二进制日志）")
    except ImportError:
        print("  pymavlink：缺失 → pip install pymavlink")
        ok = False
    try:
        import pyulog  # noqa: F401
        print("  pyulog：已安装（PX4 ULog）")
    except ImportError:
        print("  pyulog：缺失 → pip install pyulog（仅解析 PX4 时需要）")
    try:
        import numpy
        print(f"  numpy：{numpy.__version__}")
    except ImportError:
        print("  numpy：缺失 → pip install numpy")
        ok = False
    cfg = config_from_env()
    if cfg:
        print(f"  大模型：已配置 {cfg.model} @ {cfg.base_url}")
    else:
        print("  大模型：未配置（离线分析可用；设置 DEEPSEEK_API_KEY 后可用 --llm）")
    print("  结果：", "可以开始分析" if ok else "缺少必需依赖")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="fla", description="开源飞控日志事故分析（ArduPilot .bin / PX4 .ulg）")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze", help="分析一份日志并输出 Markdown 报告")
    a.add_argument("log", help="日志路径（.bin/.log/.ulg/.csv）")
    a.add_argument("-o", "--output", help="报告输出路径（默认 reports/<日志名>_report.md）")
    a.add_argument("--outdir", default="reports", help="报告目录（默认 reports）")
    a.add_argument("-f", "--format", default="md", choices=["md", "html", "docx", "all"],
                   help="报告格式：md（默认）/ html（可打印成 PDF）/ docx（Word）/ all")
    a.add_argument("--no-figures", action="store_true", help="不生成图表（默认会画）")
    a.add_argument("--json", dest="json_out", help="同时导出结构化 JSON")
    a.add_argument("--llm", action="store_true", help="启用大模型叙事（需 API Key）")
    a.add_argument("--api-key", help="大模型 API Key（也可用环境变量）")
    a.add_argument("--base-url", help="OpenAI 兼容接口地址，如 https://api.deepseek.com/v1")
    a.add_argument("--model", help="模型名，如 deepseek-chat / qwen-plus / gpt-4o-mini")
    a.set_defaults(func=cmd_analyze)

    s = sub.add_parser("serve", help="启动网页界面")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8000)
    s.add_argument("--reload", action="store_true")
    s.add_argument("--api-key")
    s.add_argument("--base-url")
    s.add_argument("--model")
    s.set_defaults(func=cmd_serve)

    m = sub.add_parser("llm", help="测试大模型密钥是否可用")
    m.add_argument("--api-key")
    m.add_argument("--base-url")
    m.add_argument("--model")
    m.set_defaults(func=cmd_llm)

    t = sub.add_parser("tune", help="调参体检：数据质量门 + 速率环/延迟/参数建议")
    t.add_argument("log", help="日志路径（.bin/.log）")
    t.add_argument("--json", dest="json_out", help="同时导出结构化 JSON")
    t.set_defaults(func=cmd_tune)

    d = sub.add_parser("doctor", help="检查运行环境")
    d.set_defaults(func=cmd_doctor)
    return p


def _enable_windows_ansi() -> None:
    """Windows 10+ 的控制台需要显式打开 VT 转义序列，否则彩色输出是乱码。"""
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        for handle in (-11, -12):  # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(kernel32.GetStdHandle(handle), ctypes.byref(mode)):
                kernel32.SetConsoleMode(kernel32.GetStdHandle(handle), mode.value | 0x0004)
    except Exception:
        pass


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass
    _enable_windows_ansi()
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
