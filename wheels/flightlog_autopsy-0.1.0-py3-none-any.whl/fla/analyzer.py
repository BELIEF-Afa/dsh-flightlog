"""分析调度：加载日志 -> 总体统计 -> 跑检测器 -> 打分与结论。"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .detectors import DEFAULT_DETECTORS
from .detectors.base import Detector
from .model import Analysis, Finding, Skipped, fmt_t
from .readers import load
from .summary import build_summary

#: 严重度 -> 基础扣分权重，再乘以置信度
WEIGHT = {"critical": 32.0, "warn": 13.0, "info": 3.0}

VERDICTS = [
    (55, "事故", "日志呈现出明确的事故特征，需要按下述时间线复盘。"),
    (25, "严重异常", "存在足以导致失控/坠机的异常，建议停飞排查后再飞。"),
    (8, "轻微异常", "检出若干偏差，尚不致命，但应在下次飞行前处理。"),
    (0, "未见明显异常", "已执行的检查未发现明显异常；注意查看「未执行的检查」一节。"),
]


def score_findings(findings: Iterable[Finding]) -> int:
    total = 0.0
    for f in findings:
        total += WEIGHT.get(f.severity, 0.0) * max(0.2, min(1.0, f.confidence))
    return int(round(min(100.0, total)))


def verdict_for(score: int) -> tuple[str, str]:
    for th, name, text in VERDICTS:
        if score >= th:
            return name, text
    return "未见明显异常", ""


def _verdict_text(findings: list[Finding], log) -> str:
    """用最严重的几条发现拼一段人话摘要（离线模式用；LLM 模式会重写）。"""
    crit = [f for f in findings if f.severity == "critical"]
    warn = [f for f in findings if f.severity == "warn"]
    parts: list[str] = []
    if crit:
        first = crit[0]
        when = fmt_t(first.t_start, log.t_end) if first.t_start is not None else "全程"
        parts.append(f"最严重的问题出现在 {when}：{first.title}。{first.conclusion}")
        if len(crit) > 1:
            parts.append("同时/随后还检出：" + "；".join(f.title for f in crit[1:4]) + "。")
    elif warn:
        parts.append("未发现致命问题，但存在偏差：" + "；".join(f.title for f in warn[:3]) + "。")
    else:
        parts.append("已执行的规则未发现明显异常。")

    impacts = [f for f in findings if f.id in ("impact", "truncated-log", "estop")]
    if impacts:
        parts.append("从日志结尾看，" + "，".join(f.title for f in impacts) + "，"
                     "基本可以确认这不是一次正常降落。")
    return "".join(parts)


def analyze(path: str | Path, detectors: list[Detector] | None = None) -> Analysis:
    log = load(path)
    dets = list(detectors) if detectors is not None else list(DEFAULT_DETECTORS)
    findings: list[Finding] = []
    skipped: list[Skipped] = []
    for d in dets:
        why = d.available(log)
        if why:
            skipped.append(Skipped(d.id, why))
            continue
        try:
            target = log if getattr(d, "scope", "quality") == "full" else log.slice(0, log.t_quality_end)
            findings.extend(d.run(target))
        except Exception as exc:  # 单条规则出错不能拖垮整份报告
            log.warnings.append(f"检测器 {d.id} 执行失败：{type(exc).__name__}: {exc}")
            skipped.append(Skipped(d.id, f"执行出错：{type(exc).__name__}: {exc}"))

    log.sort_events()
    summary = build_summary(log)
    score = score_findings(findings)
    verdict, base = verdict_for(score)
    analysis = Analysis(log=log, findings=findings, skipped=skipped, summary=summary,
                        verdict=verdict, verdict_text=base, score=score)
    analysis.verdict_text = _verdict_text(analysis.sorted_findings(), log)
    try:
        from .tune import evaluate as _tune_eval

        analysis.tune = _tune_eval(log)
    except Exception as exc:  # 调参体检失败不影响事故结论
        log.warnings.append(f"调参体检失败：{type(exc).__name__}: {exc}")
    summary["finding_count"] = len(findings)
    summary["critical_count"] = len(analysis.by_severity("critical"))
    summary["warn_count"] = len(analysis.by_severity("warn"))
    return analysis
