"""ArduPilot DataFlash 日志读取（.bin / .log）。

依赖 ``pymavlink``（ArduPilot 官方维护的解析库）：:

    pip install pymavlink

本模块只负责"把字节流变成规范化信号"，不做任何业务判断。
字段名以 ArduPilot 4.x 的 DataFlash 结构为准，旧固件缺少的字段会自动跳过。
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from ..model import Event, FlightLog, Series

#: 消息 -> {原字段: 规范信号}
SERIES_MAP: dict[str, dict[str, str]] = {
    "ATT": {
        "Roll": "att.roll",
        "Pitch": "att.pitch",
        "Yaw": "att.yaw",
        "DesRoll": "att.des_roll",
        "DesPitch": "att.des_pitch",
        "ErrRP": "att.err_rp",
    },
    "IMU": {
        "GyrX": "gyro.x", "GyrY": "gyro.y", "GyrZ": "gyro.z",
        "AccX": "acc.x", "AccY": "acc.y", "AccZ": "acc.z",
    },
    "VIBE": {"VibeX": "vibe.x", "VibeY": "vibe.y", "VibeZ": "vibe.z",
             "Clip": "vibe.clip",            # 4.5+：单字段削顶计数
             "Clip0": "vibe.clip0", "Clip1": "vibe.clip1", "Clip2": "vibe.clip2"},
    "POS": {"Lat": "pos.lat", "Lng": "pos.lng", "RelHomeAlt": "alt.rel",
            "Alt": "pos.alt"},
    "GPS": {"NSats": "gps.sats", "HDop": "gps.hdop", "Status": "gps.fix",
            "Spd": "vel.ground", "Alt": "alt.gps"},
    "BAT": {"Volt": "bat.volt", "Curr": "bat.curr", "RemPct": "bat.pct"},
    "MAG": {"MagX": "mag.x", "MagY": "mag.y", "MagZ": "mag.z"},
    "NKF1": {"IVN": "ekf.ivn", "IVE": "ekf.ive"},
    "NKF3": {"IPN": "ekf.ipn", "IPE": "ekf.ipe"},
    "XKF1": {"Roll": "ekf.roll", "Pitch": "ekf.pitch"},
    "XKF3": {"IVN": "ekf.ivn", "IVE": "ekf.ive", "IPN": "ekf.ipn", "IPE": "ekf.ipe",
             "IVD": "ekf.ivd", "IPD": "ekf.ipd"},
    "XKF4": {"errRP": "ekf.err_rp", "SV": "ekf.sv", "SP": "ekf.sp", "SH": "ekf.sh"},
    "PM": {"Load": "cpu.load", "MaxT": "loop.max"},
    "CTUN": {"CRt": "vel.vert", "BAlt": "alt.baro", "Alt": "alt.ctun",
             "DAlt": "alt.des", "ThO": "thr.out"},
    "RCIN": {"C3": "rc.thr"},
    "RATE": {"RDes": "rate.des_roll", "R": "rate.roll",
             "PDes": "rate.des_pitch", "P": "rate.pitch",
             "YDes": "rate.des_yaw", "Y": "rate.yaw"},
}

#: 同一物理量的后续消息名（ArduPilot 用 IMU2/IMU3 表示第 2、3 个 IMU）
ALIAS_MSG = {"IMU2": ("IMU", 1), "IMU3": ("IMU", 2), "BAT2": ("BAT", 1)}

#: 多实例消息的实例编号字段
INSTANCE_FIELD = {
    "VIBE": ("IMU", "I"),
    "IMU": ("I", "Instance"),
    "MAG": ("I", "Instance"),
    "GPS": ("I", "Instance"),
    "BARO": ("I", "Instance"),
    "BAT": ("Inst", "Instance"),
}

#: 原始字段 -> 规范化时的缩放（pymavlink 只在 FMTU 完整时才应用倍率，不能依赖）
SCALE = {"cpu.load": 0.1, "loop.max": 1e-3, "vel.vert": 0.01}

OUTPUT_MSGS = ("RCOU",)

#: 多旋翼模式编号（ArduCopter）。PX4 用另一张表，在 px4.py 里处理。
COPTER_MODES = {
    0: "STABILIZE", 1: "ACRO", 2: "ALT_HOLD", 3: "AUTO", 4: "GUIDED", 5: "LOITER",
    6: "RTL", 7: "CIRCLE", 8: "POSITION", 9: "LAND", 10: "OF_LOITER", 11: "DRIFT",
    13: "SPORT", 14: "FLIP", 15: "AUTOTUNE", 16: "POSHOLD", 17: "BRAKE",
    18: "THROW", 19: "AVOID_ADSB", 20: "GUIDED_NOGPS", 21: "SMART_RTL",
    22: "FLOWHOLD", 23: "FOLLOW", 24: "ZIGZAG", 25: "SYSTEMID", 26: "AUTOROTATE",
    27: "AUTO_RTL",
}


#: 模式切换原因（AP_Vehicle/ModeReason.h），决定"是飞控自己切的还是人/地面站切的"
MODE_REASONS = {
    0: "原因未知", 1: "遥控指令", 2: "地面站指令", 3: "遥控信号丢失（失控保护）",
    4: "电池失控保护", 5: "地面站失联（失控保护）", 6: "EKF 失控保护", 7: "GPS 异常",
    8: "任务结束", 9: "降落逃逸", 10: "电子围栏", 11: "地形失控保护", 12: "刹车超时",
    13: "翻转完成", 14: "避障", 15: "避障恢复", 16: "抛飞完成", 17: "自毁", 18: "玩具模式",
    19: "撞击失控保护", 25: "通用失控保护", 26: "初始化", 30: "舵机测试", 31: "启动",
    32: "脚本指令", 41: "任务指令", 42: "FrSky 指令", 52: "DDS 指令", 53: "辅助通道",
}

#: 这些原因代表"飞控自己切的"（触发源不在人手上）
AUTONOMOUS_REASONS = {3, 4, 5, 6, 7, 10, 11, 12, 19, 25, 50}


def _mode_name(mode: int, firmware: str) -> str:
    if "copter" in firmware.lower():
        name = COPTER_MODES.get(mode)
        return f"{mode} {name}" if name else str(mode)
    return str(mode)

#: 日志错误子系统（ArduPilot AP_Logger/LogStructure.h）
ERROR_SUBSYS = {
    1: "MAIN", 2: "RADIO", 3: "COMPASS", 4: "OPTFLOW", 5: "FAILSAFE_RADIO",
    6: "FAILSAFE_BATT", 7: "FAILSAFE_GPS", 8: "FAILSAFE_GCS", 9: "FAILSAFE_FENCE",
    10: "FLIGHT_MODE", 11: "GPS", 12: "CRASH_CHECK", 13: "FLIP", 14: "AUTOTUNE",
    15: "PARACHUTE", 16: "EKFCHECK", 17: "FAILSAFE_EKFINAV", 18: "BARO",
    19: "CPU", 20: "FAILSAFE_ADSB", 21: "TERRAIN", 22: "NAVIGATION",
    23: "FAILSAFE_TERRAIN", 24: "EKF_PRIMARY", 25: "THRUST_LOSS_CHECK",
    26: "FAILSAFE_SENSORS", 27: "FAILSAFE_LEAK", 28: "PILOT_INPUT",
    29: "FAILSAFE_VIBE",
}
FAILSAFE_SUBSYS = {5, 6, 7, 8, 9, 16, 17, 20, 23, 25, 26, 27, 29}

#: 事件 Id（只保留含义明确的部分；未知 Id 原样展示，不猜测）
EVENTS = {
    10: ("arm", "解锁 (ARMED)"),
    11: ("disarm", "上锁 (DISARMED)"),
    15: ("arm", "自动解锁 (AUTO_ARMED)"),
    16: ("disarm", "自动上锁 (AUTO_DISARMED)"),
    17: ("land", "着陆判定(不确定)"),
    18: ("land", "着陆完成"),
}

_VEHICLE_RE = re.compile(
    r"(ArduCopter|ArduPlane|ArduRover|ArduSub|ArduHeli|APM:Copter|APM:Plane)\s*V?(\d+\.\d+\.\d+\S*)",
    re.I,
)
_FRAME_RE = re.compile(r"Frame:\s*(\S+)", re.I)
_CRASH_RE = re.compile(r"crash|impact detected|disarm(ed)?\s*(due to|after)\s*angle", re.I)
_ESTOP_RE = re.compile(r"motor\s*e-?stop|emergency\s*stop|\be-?stop\b", re.I)
_THRUST_RE = re.compile(r"thrust\s*loss|motor\s*(failure|failed|stopped)|esc.*(fail|error)", re.I)
_COMPASS_RE = re.compile(r"compass\s*(error|unhealthy|inconsistent)|gps\s*glitch|magnet", re.I)
_FAILSAFE_RE = re.compile(
    r"failsafe|EKF\d?.*(unhealthy|variance|failing)|vibration|brownout|watchdog|"
    r"reboot|emergency|parachute|battery\s*(low|critical)", re.I)
def read(path: Path) -> FlightLog:
    from pymavlink import DFReader  # 延迟导入，便于缺依赖时给出友好提示

    log = FlightLog(path=path, firmware="ArduPilot", log_format=path.suffix.lower())
    raw = DFReader.DFReader_binary(str(path))

    acc: dict[str, dict[str, list[float]]] = {}
    tmap: dict[str, list[float]] = {}
    mode_t: list[float] = []
    mode_v: list[str] = []
    counts: dict[str, int] = {}
    t_end = 0.0
    n = 0

    while True:
        try:
            m = raw.recv_msg()
        except Exception as exc:  # 损坏的日志尾部很常见
            log.warnings.append(f"解析在第 {n} 条消息处中断：{exc}")
            break
        if m is None:
            break
        n += 1
        mtype = m.get_type()
        counts[mtype] = counts.get(mtype, 0) + 1
        tu = getattr(m, "TimeUS", None)
        t = 0.0 if tu is None else tu * 1e-6
        if t_end < t:
            t_end = t

        if mtype == "PARM":
            try:
                log.params[str(m.Name)] = float(m.Value)
            except Exception:
                pass
            continue
        if mtype == "MSG":
            _handle_msg(log, t, str(m.Message))
            continue
        if mtype == "MODE":
            try:
                mode = int(m.Mode)
            except Exception:
                mode = str(m.Mode)
            if mode_v and mode_v[-1] == str(mode):
                continue  # 同一模式连续上报（解锁/上锁瞬间常见），不重复记事件
            try:
                rsn = int(getattr(m, "Rsn", 0))
            except Exception:
                rsn = 0
            reason = MODE_REASONS.get(rsn, f"原因 {rsn}")
            mode_t.append(t)
            mode_v.append(_mode_name(mode, log.firmware))
            log.add_event(Event(t, "mode",
                                f"模式切换 → {_mode_name(mode, log.firmware)}｜{reason}",
                                "info", "MODE"))
            continue
        if mtype == "EV":
            ev_id = int(m.Id)
            kind, label = EVENTS.get(ev_id, ("other", f"日志事件 Id={ev_id}"))
            sev = "info" if kind in ("arm", "disarm", "land") else "warn"
            log.add_event(Event(t, kind, label, sev, "EV"))
            continue
        if mtype == "ERR":
            sub = int(m.Subsys)
            code = int(m.ECode)
            name = ERROR_SUBSYS.get(sub, f"SUBSYS_{sub}")
            if sub in FAILSAFE_SUBSYS:
                log.add_event(Event(t, "failsafe", f"{name} 触发（错误码 {code}）", "critical", "ERR"))
            else:
                log.add_event(Event(t, "error", f"{name} 错误码 {code}", "warn", "ERR"))

        base, inst = ALIAS_MSG.get(mtype, (mtype, 0))
        for f in INSTANCE_FIELD.get(base, ()):
            if hasattr(m, f):
                try:
                    inst = int(getattr(m, f))
                except Exception:
                    pass
                break

        fields = SERIES_MAP.get(base)
        if fields is None and base in OUTPUT_MSGS:
            fields = {c: f"out.c{int(c[1:])}" for c in m.fmt.columns
                      if re.fullmatch(r"C\d+", c)}
        if not fields or tu is None:
            continue

        key = f"{base}#{inst}"
        tmap.setdefault(key, []).append(t)
        bucket = acc.setdefault(key, {})
        for orig, canon in fields.items():
            try:
                val = float(getattr(m, orig))
            except Exception:
                continue
            if np.isfinite(val):
                k = SCALE.get(canon)
                if k is not None:
                    val *= k
                bucket.setdefault(canon, []).append(val)

    log.t_end = t_end
    log.message_counts = counts
    log.meta.setdefault("messages", n)
    log.meta.setdefault("log_bytes", path.stat().st_size)

    for key, fields in acc.items():
        ts = np.asarray(tmap.get(key, []), dtype=np.float64)
        inst = int(key.split("#")[1])
        for canon, vals in fields.items():
            v = np.asarray(vals, dtype=np.float64)
            if not v.size:
                continue
            tt = ts[: v.size] if ts.size >= v.size else np.linspace(0.0, t_end, v.size)
            name = canon if inst == 0 else f"{canon}#{inst}"
            log.add(Series(name, tt, v, source=f"{key}.{canon}"))

    if mode_t:
        log.cat["mode"] = (np.asarray(mode_t, dtype=np.float64), mode_v)

    # 统一时间基准：日志第一条记录 = 0 秒（TimeUS 是"开机以来的微秒数"，直接展示会很怪）
    starts = [s.t0 for s in log.series.values() if len(s)] + [e.t for e in log.events]
    t0 = min(starts) if starts else 0.0
    if t0 > 0:
        for s in log.series.values():
            s.t = s.t - t0
        for e in log.events:
            e.t -= t0
        if "mode" in log.cat:
            ts, labels = log.cat["mode"]
            log.cat["mode"] = (ts - t0, labels)
        log.t_end = max(0.0, log.t_end - t0)
    log.meta.setdefault("boot_time_s", round(t0, 2))

    fam, ver = log.meta.get("vehicle_family"), log.meta.get("firmware_version")
    if fam:
        log.firmware = f"{fam} {ver}".strip() if ver else str(fam)
    _relabel_modes(log)

    _derive(log)
    log.sort_events()
    return log


def _relabel_modes(log: FlightLog) -> None:
    """解析时还不知道机型（MSG 在日志后段也可能出现），最后统一把模式编号翻成名字。"""
    def name(x: str) -> str:
        return _mode_name(int(x), log.firmware) if str(x).isdigit() else str(x)

    if "mode" in log.cat:
        ts, labels = log.cat["mode"]
        log.cat["mode"] = (ts, [name(x) for x in labels])
    if log.meta.get("mode") and str(log.meta["mode"]).isdigit():
        log.meta["mode"] = name(log.meta["mode"])
    for e in log.events:
        if e.kind == "mode":
            body = e.detail.rsplit("→", 1)[-1].strip()
            reason = ""
            if "｜" in body:
                body, reason = [x.strip() for x in body.split("｜", 1)]
            e.detail = f"模式切换 → {name(body)}" + (f"｜{reason}" if reason else "")


def _handle_msg(log: FlightLog, t: float, text: str) -> None:
    text = text.strip()
    if not text:
        return
    if "firmware_version" not in log.meta:
        m = _VEHICLE_RE.search(text)
        if m:
            log.meta["vehicle_family"] = m.group(1)
            log.meta["firmware_version"] = m.group(2)
    if "frame" not in log.meta:
        m = _FRAME_RE.search(text)
        if m:
            log.meta["frame"] = m.group(1)

    if _ESTOP_RE.search(text):
        log.add_event(Event(t, "estop", f"电机急停（E-Stop）：{text}", "critical", "MSG"))
    elif _THRUST_RE.search(text):
        log.add_event(Event(t, "thrust_loss", f"飞控报告推力损失：{text}", "critical", "MSG"))
    elif _CRASH_RE.search(text):
        log.add_event(Event(t, "impact", f"飞控报告撞击/坠机：{text}", "critical", "MSG"))
    elif _FAILSAFE_RE.search(text):
        log.add_event(Event(t, "failsafe", text, "warn", "MSG"))
    elif _COMPASS_RE.search(text):
        log.add_event(Event(t, "sensor", text, "warn", "MSG"))
    elif len(text) > 10 and not text.startswith(("PreArm", "Throttle", "Ground start")):
        log.add_event(Event(t, "msg", text, "info", "MSG"))


def _derive(log: FlightLog) -> None:
    """派生信号：振动峰值、加速度模长、磁场强度、输出通道最大值。"""
    s = log.series

    def _aligned(names: list[str]):
        seqs = [s[n] for n in names if n in s and len(s[n])]
        if len(seqs) != len(names):
            return None
        n = min(len(x) for x in seqs)
        return seqs[0].t[:n], [x.y[:n] for x in seqs]

    got = _aligned(["vibe.x", "vibe.y", "vibe.z"])
    if got:
        t, ys = got
        log.add(Series("vibe.pk", t, np.max(np.vstack(ys), axis=0), source="derived:vibe"))

    got = _aligned(["acc.x", "acc.y", "acc.z"])
    if got:
        t, ys = got
        log.add(Series("acc.mag", t, np.sqrt(sum(y ** 2 for y in ys)), source="derived:acc"))

    got = _aligned(["mag.x", "mag.y", "mag.z"])
    if got:
        t, ys = got
        log.add(Series("mag.strength", t, np.sqrt(sum(y ** 2 for y in ys)), source="derived:mag"))

    outs = [v for k, v in s.items()
            if re.fullmatch(r"out\.c\d+", k) and len(v) and float(np.max(v.y)) > 0]
    if outs:
        n = min(len(x) for x in outs)
        log.add(Series("out.pwm", outs[0].t[:n],
                       np.max(np.vstack([x.y[:n] for x in outs]), axis=0),
                       source="derived:out"))
