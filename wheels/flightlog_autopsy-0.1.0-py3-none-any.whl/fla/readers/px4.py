"""PX4 ULog 日志读取（.ulg）。

依赖 ``pyulog``（PX4 官方工具链使用的解析库）：:

    pip install pyulog

注意：PX4 与 ArduPilot 的坐标系/单位差异在本层统一：

* PX4 的 local position 是 NED（向下为正）→ 本层转成"向上为正"。
* 四元数按 [w, x, y, z] 处理 → 转成欧拉角（度）。
* 电机输出归一化 0~1 → 本层保留 0~1，检测器按"归一化"分支处理。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from ..model import Event, FlightLog, Series

#: PX4 nav_state -> 中文（PX4 固件版本间编号有调整，未知编号原样显示）
NAV_STATE = {
    0: "Manual", 1: "Altitude", 2: "Position", 3: "Mission", 4: "Loiter",
    5: "RTL", 6: "Land", 7: "RTGS", 8: "Acro", 9: "Offboard", 10: "Stabilized",
    11: "Rattitude", 12: "Takeoff", 13: "VTOL Takeoff", 14: "VTOL Land",
    15: "Follow Target", 16: "Precision Land", 17: "Orbit", 18: "Hold",
}


def _quat_to_euler(q: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """q: (4, N) 或 (N, 4)，单位四元数 [w,x,y,z] -> roll/pitch/yaw (deg)。"""
    q = np.asarray(q, dtype=float)
    if q.ndim != 2:
        raise ValueError("bad quaternion shape")
    if q.shape[0] == 4 and q.shape[1] != 4:
        w, x, y, z = q[0], q[1], q[2], q[3]
    else:
        w, x, y, z = q[:, 0], q[:, 1], q[:, 2], q[:, 3]
    roll = np.arctan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    pitch = np.arcsin(np.clip(2 * (w * y - z * x), -1, 1))
    yaw = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return np.degrees(roll), np.degrees(pitch), np.degrees(yaw)


class _ULogView:
    """对 pyulog 数据做轻量封装，缺失的 topic/字段返回 None。"""

    def __init__(self, ulog):
        self.ulog = ulog
        self._topics: dict[str, dict] = {}
        for d in ulog.data_list:
            key = d.name
            if key not in self._topics or d.multi_id == 0:
                self._topics.setdefault(key, d.data)
            if d.multi_id == 0:
                self._topics[key] = d.data
        self.t0 = 0.0
        ts = [float(np.min(d.data["timestamp"])) for d in ulog.data_list
              if "timestamp" in d.data and len(d.data["timestamp"])]
        if ts:
            self.t0 = min(ts) * 1e-6

    def topic(self, *names: str) -> dict | None:
        for n in names:
            d = self._topics.get(n)
            if d is not None and len(d.get("timestamp", [])):
                return d
        return None

    def t(self, d: dict) -> np.ndarray:
        key = "timestamp" if "timestamp" in d else "timestamp_sample"
        return np.asarray(d[key], dtype=np.float64) * 1e-6 - self.t0

    def field(self, d: dict, *names: str) -> np.ndarray | None:
        for n in names:
            if n in d:
                arr = np.asarray(d[n], dtype=np.float64)
                if arr.ndim == 2 and arr.shape[1] == 1:
                    arr = arr[:, 0]
                if arr.ndim == 1 and arr.size:
                    return arr
        return None

    def series(self, canon: str, d: dict, *names: str, scale: float = 1.0) -> Series | None:
        arr = self.field(d, *names)
        if arr is None:
            return None
        t = self.t(d)
        n = min(t.size, arr.size)
        return Series(canon, t[:n], arr[:n] * scale, source=f"{d.get('__name__', '')}.{names[0]}")


def read(path: Path) -> FlightLog:
    import pyulog  # 延迟导入

    ulog = pyulog.ULog(str(path))
    log = FlightLog(path=path, firmware="PX4", log_format=".ulg")
    v = _ULogView(ulog)

    info = getattr(ulog, "msg_info_dict", {}) or {}
    log.meta.update({
        "vehicle_family": info.get("sys_name") or info.get("vehicle_type") or "PX4",
        "firmware_version": info.get("ver_sw") or info.get("ver_sw_release"),
        "hardware": info.get("ver_hw"),
    })
    if getattr(ulog, "dropouts", None):
        log.warnings.append(f"ULog 记录到 {len(ulog.dropouts)} 次数据丢包")
    log.params = dict(getattr(ulog, "initial_parameters", {}) or {})

    # ---- 姿态 ----
    d = v.topic("vehicle_attitude")
    if d is not None:
        q = v.field(d, "q[0]", "q0")
        if q is not None and "q[0]" in d:
            qq = np.vstack([np.asarray(d[f"q[{i}]"], dtype=float) for i in range(4)])
        elif q is not None:
            qq = np.vstack([np.asarray(d[f"q{i}"], dtype=float) for i in range(4)])
        else:
            qq = None
        t = v.t(d)
        if qq is not None:
            roll, pitch, yaw = _quat_to_euler(qq)
            n = min(t.size, roll.size)
            log.add(Series("att.roll", t[:n], roll[:n], source="vehicle_attitude.q"))
            log.add(Series("att.pitch", t[:n], pitch[:n], source="vehicle_attitude.q"))
            log.add(Series("att.yaw", t[:n], yaw[:n], source="vehicle_attitude.q"))
        for canon, names in (("att.roll", ("roll",)), ("att.pitch", ("pitch",)),
                             ("att.yaw", ("yaw",))):
            arr = v.field(d, *names)
            if arr is not None:
                n = min(t.size, arr.size)
                log.add(Series(canon, t[:n], np.degrees(arr[:n]), source="vehicle_attitude"))

    d = v.topic("vehicle_attitude_setpoint")
    if d is not None:
        for canon, names in (("att.des_roll", ("roll_body",)),
                             ("att.des_pitch", ("pitch_body",))):
            arr = v.field(d, *names)
            if arr is not None:
                t = v.t(d)
                n = min(t.size, arr.size)
                log.add(Series(canon, t[:n], np.degrees(arr[:n]),
                               source="vehicle_attitude_setpoint"))

    # ---- 角速度 / 加速度 / 振动 ----
    d = v.topic("sensor_combined")
    if d is not None:
        t = v.t(d)
        for canon, names in (("gyro.x", ("gyro_rad[0]",)), ("gyro.y", ("gyro_rad[1]",)),
                             ("gyro.z", ("gyro_rad[2]",))):
            arr = v.field(d, *names)
            if arr is not None:
                n = min(t.size, arr.size)
                log.add(Series(canon, t[:n], arr[:n], source="sensor_combined"))
        for axis, names in (("acc.x", ("accelerometer_m_s2[0]",)),
                            ("acc.y", ("accelerometer_m_s2[1]",)),
                            ("acc.z", ("accelerometer_m_s2[2]",))):
            arr = v.field(d, *names)
            if arr is not None:
                n = min(t.size, arr.size)
                log.add(Series(axis, t[:n], arr[:n], source="sensor_combined"))

    d = v.topic("estimator_status")
    if d is not None:
        t = v.t(d)
        for i, canon in enumerate(("vibe.x", "vibe.y", "vibe.z")):
            arr = v.field(d, f"vibe[{i}]")
            if arr is not None:
                n = min(t.size, arr.size)
                log.add(Series(canon, t[:n], arr[:n], source="estimator_status"))

    # ---- 位置 / 高度 / 速度（NED -> 向上为正）----
    d = v.topic("vehicle_local_position")
    if d is not None:
        t = v.t(d)
        z = v.field(d, "z")
        if z is not None:
            n = min(t.size, z.size)
            log.add(Series("alt.rel", t[:n], -z[:n], source="vehicle_local_position.z"))
        vz = v.field(d, "vz")
        if vz is not None:
            n = min(t.size, vz.size)
            log.add(Series("vel.vert", t[:n], -vz[:n], source="vehicle_local_position.vz"))
        vxy = v.field(d, "v_xy")
        if vxy is not None:
            n = min(t.size, vxy.size)
            log.add(Series("vel.ground", t[:n], vxy[:n], source="vehicle_local_position"))

    d = v.topic("vehicle_global_position")
    if d is not None:
        t = v.t(d)
        for canon, names in (("pos.lat", ("lat",)), ("pos.lng", ("lon",)),
                             ("alt.gps", ("alt",)), ("alt.rel", ("alt_ellipsoid",))):
            arr = v.field(d, *names)
            if arr is None:
                continue
            n = min(t.size, arr.size)
            # alt_ellipsoid 不当作相对高度使用，避免误判
            if canon == "alt.rel":
                continue
            log.add(Series(canon, t[:n], arr[:n], source="vehicle_global_position"))

    d = v.topic("vehicle_air_data")
    if d is not None:
        arr = v.field(d, "baro_alt_meter")
        if arr is not None:
            t = v.t(d)
            n = min(t.size, arr.size)
            log.add(Series("alt.baro", t[:n], arr[:n], source="vehicle_air_data"))

    # ---- GPS ----
    d = v.topic("vehicle_gps_position", "sensor_gps")
    if d is not None:
        t = v.t(d)
        for canon, names in (("gps.sats", ("satellites_used",)),
                             ("gps.fix", ("fix_type",)),
                             ("gps.hdop", ("eph",)),
                             ("vel.ground", ("vel_m_s",)),
                             ("alt.gps", ("alt",))):
            arr = v.field(d, *names)
            if arr is None:
                continue
            n = min(t.size, arr.size)
            vals = arr[:n]
            if canon == "gps.hdop":
                vals = vals / 100.0 if np.nanmax(vals) > 20 else vals
            log.add(Series(canon, t[:n], vals, source="gps"))

    # ---- 电池 ----
    d = v.topic("battery_status")
    if d is not None:
        t = v.t(d)
        for canon, names in (("bat.volt", ("voltage_v", "voltage_filtered_v")),
                             ("bat.curr", ("current_a", "current_filtered_a"))):
            arr = v.field(d, *names)
            if arr is None:
                continue
            n = min(t.size, arr.size)
            log.add(Series(canon, t[:n], arr[:n], source="battery_status"))

    # ---- 执行器输出 ----
    d = v.topic("actuator_motors", "actuator_outputs", "actuator_controls_0")
    if d is not None:
        t = v.t(d)
        cols = [c for c in d if c.startswith("control[") or c.startswith("output[")]
        for i, c in enumerate(cols[:8], start=1):
            arr = np.asarray(d[c], dtype=np.float64)
            n = min(t.size, arr.size)
            log.add(Series(f"out.c{i}", t[:n], arr[:n], source="actuator"))

    # ---- 系统 ----
    d = v.topic("cpuload")
    if d is not None:
        arr = v.field(d, "load")
        if arr is not None:
            t = v.t(d)
            n = min(t.size, arr.size)
            log.add(Series("cpu.load", t[:n], arr[:n] * 100.0, source="cpuload"))

    # ---- 模式 / 解锁状态 ----
    d = v.topic("commander_state")
    if d is not None:
        arr = v.field(d, "main_state")
        if arr is not None:
            t = v.t(d)
            n = min(t.size, arr.size)
            log.cat["mode"] = (t[:n], [NAV_STATE.get(int(x), f"state{int(x)}") for x in arr[:n]])
            prev = None
            for ti, val in zip(t[:n], arr[:n]):
                label = NAV_STATE.get(int(val), f"state{int(val)}")
                if label != prev:
                    log.add_event(Event(float(ti), "mode", f"模式切换 → {label}", "info", "commander_state"))
                    prev = label

    d = v.topic("vehicle_status")
    if d is not None:
        t = v.t(d)
        arm = v.field(d, "arming_state")
        if arm is not None:
            n = min(t.size, arm.size)
            prev = None
            for ti, val in zip(t[:n], arm[:n]):
                state = "armed" if int(val) == 3 else "disarmed"
                if state != prev:
                    log.add_event(Event(float(ti), "arm" if state == "armed" else "disarm",
                                        "解锁" if state == "armed" else "上锁", "info", "vehicle_status"))
                    prev = state
        nav = v.field(d, "nav_state")
        if nav is not None and "mode" not in log.cat:
            n = min(t.size, nav.size)
            log.cat["mode"] = (t[:n], [NAV_STATE.get(int(x), f"state{int(x)}") for x in nav[:n]])

    log.t_end = max((s.t1 for s in log.series.values()), default=0.0)
    log.message_counts = {d.name: len(d.data.get("timestamp", [])) for d in ulog.data_list}
    log.sort_events()
    return log
