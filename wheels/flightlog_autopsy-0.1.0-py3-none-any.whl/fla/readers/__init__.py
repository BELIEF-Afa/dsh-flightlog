"""日志格式分派。"""
from __future__ import annotations

from pathlib import Path

from ..model import FlightLog


class UnsupportedLog(Exception):
    pass


def detect_format(path: str | Path) -> str:
    path = Path(path).expanduser()
    suffix = path.suffix.lower()
    if suffix in (".bin", ".log"):
        return "ardupilot"
    if suffix == ".ulg":
        return "px4"
    if suffix == ".csv":
        return "csv"
    head = b""
    try:
        with path.open("rb") as f:
            head = f.read(16)
    except OSError:
        pass
    if head[:2] == b"\xa3\x95":
        return "ardupilot"
    if head[:4] == b"ULog":
        return "px4"
    if head.lstrip(b"\xef\xbb\xbf").lower().startswith((b"t,", b"time", b"timeus")):
        return "csv"
    raise UnsupportedLog(
        f"无法识别的日志格式：{path.name}（支持 ArduPilot .bin/.log、PX4 .ulg、规范 CSV）"
    )


def load(path: str | Path) -> FlightLog:
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(p)
    kind = detect_format(p)
    if kind == "ardupilot":
        from . import ardupilot

        return ardupilot.read(p)
    if kind == "px4":
        from . import px4

        return px4.read(p)
    from . import csv_reader

    return csv_reader.read(p)
