"""规范化 CSV 读取。

给两种场景用：

1. **测试/离线复算**：把已经提取好的信号存成 CSV，直接跑检测器；
2. **兜底**：某些工具（PlotJuggler、ulog2csv、mavlogdump）导出的 CSV
   可以手工改列表头成规范信号名后喂进来。

格式要求：第一列是时间（``t`` 秒；或 ``TimeUS`` 微秒），其余列表头为规范信号名
（见 :data:`fla.model.SIGNALS`），例如::

    t,att.roll,att.pitch,alt.rel,vel.vert,bat.volt,gps.sats
    0.00,0.1,0.2,0.0,0.0,16.7,14
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from ..model import Event, FlightLog, SIGNALS, Series


def read(path: Path) -> FlightLog:
    log = FlightLog(path=path, firmware="CSV", log_format=".csv")
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if not header:
            raise ValueError("CSV 没有表头")
        header = [h.strip() for h in header]
        t_idx = 0
        t_scale = 1.0
        for i, h in enumerate(header):
            if h.lower() in ("timeus", "time_us", "timestamp"):
                t_idx, t_scale = i, 1e-6
                break
            if h.lower() in ("t", "time", "time_s", "seconds"):
                t_idx, t_scale = i, 1.0
                break
        cols: list[list[float]] = [[] for _ in header]
        ts: list[float] = []
        for row in reader:
            if len(row) < len(header):
                continue
            try:
                ts.append(float(row[t_idx]) * t_scale)
            except ValueError:
                continue
            for i, cell in enumerate(row):
                if i == t_idx:
                    continue
                try:
                    cols[i].append(float(cell))
                except ValueError:
                    cols[i].append(float("nan"))
    t = np.asarray(ts, dtype=np.float64)
    for i, name in enumerate(header):
        if i == t_idx or not name:
            continue
        y = np.asarray(cols[i], dtype=np.float64)
        n = min(t.size, y.size)
        if n == 0:
            continue
        log.add(Series(name, t[:n], y[:n], source=name))
    log.t_end = float(t[-1]) if t.size else 0.0
    if "alt.rel" not in log.series and "alt.baro" in log.series:
        log.series["alt.rel"] = log.series["alt.baro"]
        log.warnings.append("CSV 无 alt.rel，已用 alt.baro 代替相对高度")
    return log
