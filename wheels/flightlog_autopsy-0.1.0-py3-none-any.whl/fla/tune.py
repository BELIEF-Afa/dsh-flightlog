"""调参体检：先看数据质量，再谈 PID。

移植自 SmartTune 0.4.0（同作者），但改成读本项目的规范信号
（`FlightLog.series`），不再自己解析 DataFlash。

设计前提只有一条：**先用数据质量门拦住不该调的日志，再谈 PID。**
质量门没过时，所有增益建议都会被降级成"先治振动"，不许给具体数值。
"""

from __future__ import annotations

import math

import numpy as np

from .model import FlightLog, fmt_t

# ---------------------------------------------------------------- 阈值与默认值

THRESH = {
    "imu_min_hz": 100.0,      # 低于此值做不了频谱
    "vibe_warn": 30.0,
    "vibe_fail": 60.0,
    "motor_sat_pct": 5.0,
    "d_over_p": 0.10,
    "hover_mismatch": 0.12,   # 推力域差异
}

#: ArduCopter 4.6 出厂默认值
DEFAULTS = {
    "ATC_RAT_RLL_P": 0.135, "ATC_RAT_RLL_I": 0.135, "ATC_RAT_RLL_D": 0.0036,
    "ATC_RAT_PIT_P": 0.135, "ATC_RAT_PIT_D": 0.0036,
    "ATC_RAT_YAW_P": 0.18, "ATC_RAT_YAW_I": 0.018, "ATC_RAT_YAW_D": 0.0,
    "ATC_ANG_RLL_P": 4.5, "ATC_ANG_PIT_P": 4.5,
    "ATC_RAT_RLL_FLTD": 20, "ATC_RAT_RLL_FLTE": 0, "ATC_RAT_RLL_FLTT": 20,
    "INS_GYRO_FILTER": 20, "INS_ACCEL_FILTER": 10,
    "INS_HNTCH_ENABLE": 0, "INS_LOG_BAT_MASK": 0,
    "ATC_RAT_RLL_SMAX": 0.0, "MOT_THST_HOVER": 0.35, "MOT_THST_EXPO": 0.65,
}

PARAM_INFO = {
    "ATC_RAT_RLL_P": "速率环 P：差多少给多少力矩；大反应快、易高频抖",
    "ATC_RAT_RLL_I": "速率环 I：抗风、消稳态误差；大会在急停后来回摆",
    "ATC_RAT_RLL_D": "速率环 D：压振铃，但会把陀螺噪声放大成电机抖动",
    "ATC_RAT_RLL_FLTD": "D 项低通（Hz）：越低越平滑、相位滞后越大",
    "ATC_ANG_RLL_P": "角度环 P：把角度差换算成目标角速率（外环）",
    "INS_GYRO_FILTER": "陀螺总滤波（Hz）：控制链最上游的一道",
    "INS_HNTCH_ENABLE": "谐波陷波总开关：只压桨/机架那一个谐振频率",
    "INS_LOG_BAT_MASK": "批量采样：开了才记几百 Hz 原始 IMU，FFT 找谐振靠它",
    "ATC_RAT_RLL_SMAX": "P+D 压摆率上限：0=不限，是防高频抖的最后一道保险",
    "MOT_THST_HOVER": "悬停推力（0–1，推力域）：高度环与油门前馈都靠它",
    "MOT_THST_EXPO": "推力曲线指数：把线性的油门指令映射成非线性推力",
}

PARAM_TABLE = [
    "ATC_RAT_RLL_P", "ATC_RAT_RLL_I", "ATC_RAT_RLL_D", "ATC_RAT_RLL_FLTD",
    "ATC_ANG_RLL_P", "INS_GYRO_FILTER", "INS_HNTCH_ENABLE",
    "INS_LOG_BAT_MASK", "ATC_RAT_RLL_SMAX", "MOT_THST_HOVER", "MOT_THST_EXPO",
]

# ---------------------------------------------------------------- 基础工具


def _arr(log: FlightLog, name: str):
    s = log.get(name)
    if s is None or len(s.t) < 10:
        return None
    return np.asarray(s.t, float), np.asarray(s.y, float)


def _p95(y: np.ndarray) -> float:
    return float(np.percentile(np.abs(y), 95))


def imu_rate(log: FlightLog) -> float | None:
    """IMU 陀螺的落盘频率（Hz）。"""
    got = _arr(log, "gyro.x")
    if got is None:
        return None
    t, _ = got
    dt = np.diff(t)
    dt = dt[dt > 0]
    if not len(dt):
        return None
    return float(1.0 / np.median(dt))


def vibration(log: FlightLog) -> dict | None:
    axes = {}
    for key in ("vibe.x", "vibe.y", "vibe.z"):
        got = _arr(log, key)
        if got is None:
            continue
        _, y = got
        axes[key.split(".")[1]] = dict(p95=_p95(y), max=float(np.abs(y).max()),
                                       mean=float(np.abs(y).mean()))
    if not axes:
        return None
    clip = 0.0
    for key in [k for k in log.series if k.startswith("vibe.clip")]:
        _, y = _arr(log, key)
        if y is not None and len(y) > 1:
            clip += float(max(0.0, y[-1] - y[0]))
    return dict(axes=axes, clip=clip,
                p95=axes.get("z", {}).get("p95", 0.0),
                peak=max(a["max"] for a in axes.values()))


def motor_stats(log: FlightLog) -> dict | None:
    chans = [k for k in log.series if k.startswith("out.c")]
    chans.sort(key=lambda k: int(k.split("c")[-1]))
    if not chans:
        return None
    data = {}
    for k in chans:
        got = _arr(log, k)
        if got is not None:
            data[k] = got
    if not data:
        return None
    t, _ = next(iter(data.values()))
    stack = np.vstack([y for _, y in data.values()])
    mx = stack.max(axis=0)
    armed = mx > 1150
    if not armed.any():
        return dict(count=len(data), sat_pct=0.0, hover_pwm=None, hover_thr=None,
                    balance=None, max_pwm=float(mx.max()))
    pwm_max = max(float(np.percentile(v[armed], 99)) for _, v in data.values())
    sat = float(100 * np.mean(mx[armed] > pwm_max - 5))
    band = mx[(mx > 1400) & (mx < 1750)]
    hover = float(np.median(band if len(band) >= 30 else mx[armed]))
    return dict(count=len(data), sat_pct=sat, hover_pwm=hover,
                max_pwm=float(mx.max()), armed_frac=float(armed.mean()),
                balance=None)


def hover_estimate(log: FlightLog, motor: dict | None) -> dict | None:
    """把悬停 PWM 换算成推力域的 MOT_THST_HOVER 估计值。"""
    if not motor or not motor.get("hover_pwm"):
        return None
    pwm = float(motor["hover_pwm"])
    pmin = float(log.params.get("MOT_PWM_MIN", 1000.0))
    pmax = float(log.params.get("MOT_PWM_MAX", 2000.0))
    smin = float(log.params.get("MOT_SPIN_MIN", 0.15))
    smax = float(log.params.get("MOT_SPIN_MAX", 0.95))
    expo = float(log.params.get("MOT_THST_EXPO", 0.65))
    span = max(1e-3, pmax - pmin)
    x = (pwm - pmin) / span                     # 0..1 油门
    x = min(0.98, max(0.02, (x - smin) / max(1e-3, smax - smin)))
    thrust = (1.0 - expo) * x + expo * x * x    # 推力曲线
    return dict(throttle=x, thrust=thrust, expo=expo, pwm=pwm)


# ---------------------------------------------------------------- 频谱


def _segments(n: int, nper: int):
    step = max(1, nper // 2)
    for i in range(0, n - nper + 1, step):
        yield i


def cross_spec(x: np.ndarray, y: np.ndarray, fs: float):
    """互谱：返回 f, 相位(deg, 滞后为正), 相干度。"""
    nper = int(min(1024, len(x), len(y)))
    if nper < 64:
        return np.array([0.0]), np.array([0.0]), np.array([0.0])
    win = np.hanning(nper)
    sxx = np.zeros(nper // 2 + 1)
    syy = np.zeros(nper // 2 + 1)
    sxy = np.zeros(nper // 2 + 1, dtype=complex)
    for i in _segments(len(x), nper):
        xa = (x[i:i + nper] - x[i:i + nper].mean()) * win
        ya = (y[i:i + nper] - y[i:i + nper].mean()) * win
        X = np.fft.rfft(xa)
        Y = np.fft.rfft(ya)
        sxx += np.abs(X) ** 2
        syy += np.abs(Y) ** 2
        sxy += X * np.conj(Y)
    den = sxx * syy
    gamma = np.abs(sxy) ** 2 / np.maximum(den, 1e-18)
    if den.max() > 0:
        gamma[den < 1e-12 * den.max()] = 0.0
    phase = np.degrees(np.angle(sxy))
    f = np.fft.rfftfreq(nper, 1.0 / fs)
    return f, phase, gamma


def rate_metrics(log: FlightLog, trim_end: float = 5.0) -> dict | None:
    """速率环跟踪：RDes vs R 的 RMS 误差与跟随比。"""
    got = _arr(log, "rate.roll")
    if got is None:
        return None
    t, act = got
    _, des = _arr(log, "rate.des_roll")
    if des is None or len(des) != len(act):
        return None
    if trim_end and t[-1] - t[0] > 4 * trim_end:
        keep = t < t[-1] - trim_end
        t, act, des = t[keep], act[keep], des[keep]
    fs = (len(t) - 1) / (t[-1] - t[0]) if t[-1] > t[0] else 0.0
    out = {"fs": fs, "n": int(len(t))}
    for axis, d, a in (("roll", des, act), ("pitch", None, None)):
        if axis == "pitch":
            got2 = _arr(log, "rate.pitch")
            if got2 is None:
                continue
            _, a = got2
            _, d = _arr(log, "rate.des_pitch")
            if d is None or len(d) != len(a):
                continue
        m = min(len(d), len(a))
        err = d[:m] - a[:m]
        out[f"{axis}_rms"] = float(np.sqrt(np.mean(err ** 2)))
        sel = np.abs(d[:m]) > 15
        out[f"{axis}_n"] = int(sel.sum())
        if sel.any():
            out[f"{axis}_follow"] = float(np.sum(np.abs(a[:m][sel])) / max(1e-6, np.sum(np.abs(d[:m][sel]))))
    return out


def delay_analysis(log: FlightLog, rate: dict | None) -> dict | None:
    """用 0.5–3 Hz 的相位斜率估等效延迟（10 Hz 日志也能用）。"""
    if not rate:
        return None
    got = _arr(log, "rate.roll")
    if got is None:
        return None
    t, act = got
    _, des = _arr(log, "rate.des_roll")
    if des is None:
        return None
    fs = rate["fs"]
    if fs <= 0 or len(act) < 300:
        return None
    f, ph, gam = cross_spec(des, act, fs)
    band = (f >= 0.5) & (f <= min(3.0, fs / 4))
    if band.sum() < 4:
        return None
    w = gam[band] ** 2
    if w.sum() <= 1e-6:
        return None
    ff, pf = f[band], ph[band]
    A = np.vstack([ff, np.ones_like(ff)]).T
    W = np.diag(w)
    try:
        coef = np.linalg.lstsq(A.T @ W @ A, A.T @ W @ pf, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None
    slope, intercept = float(coef[0]), float(coef[1])
    delay_ms = slope / 360.0 * 1000.0
    fref = 2.0
    coh = float(np.interp(fref, f, gam))
    fc = float(log.params.get("ATC_RAT_RLL_FLTT", 20) or 0)
    fltt_deg = math.degrees(math.atan(fref / fc)) if fc > 0 else 0.0
    fltt_ms = fltt_deg / 360.0 / fref * 1000.0
    return {"delay_ms": delay_ms, "lag_2hz": intercept + slope * fref,
            "coherence": coh, "fltt_hz": fc, "fltt_deg": fltt_deg,
            "fltt_ms": fltt_ms, "residual_ms": delay_ms - fltt_ms,
            "usable": bool(coh >= 0.5 and 5 <= delay_ms <= 300)}


# ---------------------------------------------------------------- 参数与建议


def param_audit(log: FlightLog) -> list[dict]:
    p = log.params
    out: list[dict] = []
    for axis in ("RLL", "PIT"):
        P = p.get(f"ATC_RAT_{axis}_P")
        D = p.get(f"ATC_RAT_{axis}_D")
        if P and D:
            ratio = D / P
            if ratio > THRESH["d_over_p"]:
                out.append(dict(level="warn", param=f"ATC_RAT_{axis}_D",
                                text=f"D/P = {ratio:.3f}（默认量级 0.027），D 相对 P 偏大"))
            dflt = DEFAULTS.get(f"ATC_RAT_{axis}_D", 0.0036)
            if D > 3 * dflt:
                out.append(dict(level="warn", param=f"ATC_RAT_{axis}_D",
                                text=f"{D:.4f} 是默认 {dflt} 的 {D / dflt:.1f} 倍"))
    if p.get("INS_HNTCH_ENABLE", 0) == 0:
        out.append(dict(level="major", param="INS_HNTCH_ENABLE",
                        text="陷波器关闭：机架/桨的谐振会直接进陀螺仪"))
    if p.get("INS_LOG_BAT_MASK", 0) == 0:
        out.append(dict(level="major", param="INS_LOG_BAT_MASK",
                        text="没有 batch 原始采样，做不了高频 FFT"))
    if p.get("ATC_RAT_RLL_SMAX", 0) == 0:
        out.append(dict(level="info", param="ATC_RAT_RLL_SMAX",
                        text="压摆率限制未启用（D 大 + 振动大时是最后一道保险）"))
    return out


def coverage(log: FlightLog) -> dict:
    from .summary import coverage as _coverage

    return _coverage(log)


def evaluate(log: FlightLog) -> dict:
    """跑完所有体检测量，返回给报告/CLI 用的结构。"""
    vib = vibration(log)
    hz = imu_rate(log)
    mot = motor_stats(log)
    rate = rate_metrics(log)
    delay = delay_analysis(log, rate) if rate else None
    hov = hover_estimate(log, mot)
    cov = coverage(log)
    params = param_audit(log)

    gate: list[dict] = []
    if hz is not None:
        gate.append(dict(level="warn" if hz < THRESH["imu_min_hz"] else "ok",
                         title="IMU 记录率",
                         detail=f"{hz:.0f} Hz（奈奎斯特 {hz / 2:.1f} Hz）"))
    if vib:
        lvl = "fail" if vib["p95"] > THRESH["vibe_fail"] else (
            "warn" if vib["p95"] > THRESH["vibe_warn"] else "ok")
        gate.append(dict(level=lvl, title="振动 Z 轴 p95",
                         detail=f"{vib['p95']:.1f} m/s²，峰值 {vib['peak']:.1f}"))
        if vib["clip"] > 0:
            gate.append(dict(level="warn", title="加速度计削顶",
                             detail=f"{int(vib['clip'])} 次"))
    if mot:
        lvl = "warn" if mot["sat_pct"] > THRESH["motor_sat_pct"] else "ok"
        gate.append(dict(level=lvl, title="电机饱和",
                         detail=f"{mot['sat_pct']:.1f}% 时间贴上限"))
    if cov.get("msg_total"):
        gate.append(dict(level="ok", title="数据覆盖",
                         detail=f"{cov['msg_total']} 种消息，{cov['unused_total']} 种未用"))

    if rate:
        gate.append(dict(level="ok", title="速率环",
                         detail=f"{rate['fs']:.0f} Hz 记录，横滚 RMS {rate.get('roll_rms', 0):.2f} °/s"))
    else:
        gate.append(dict(level="warn", title="速率环",
                         detail="日志里没有 RATE 消息，做不了跟踪/延迟分析"))

    vib_bad = bool(vib and (vib["p95"] > THRESH["vibe_warn"] or vib["clip"] > 0))
    sugg: list[dict] = []

    # 1) 悬停推力：推力域比较（不是拿油门占空比直接比参数）
    hov_param = log.params.get("MOT_THST_HOVER")
    if hov and hov_param:
        diff = hov["thrust"] - float(hov_param)
        sugg.append(dict(param="MOT_THST_HOVER",
                         current=round(float(hov_param), 3),
                         suggested=round(float(hov["thrust"]), 3),
                         level="info" if abs(diff) <= THRESH["hover_mismatch"] else "warn",
                         reason=f"实测悬停 PWM {hov['pwm']:.0f} µs → 油门 {hov['throttle']:.2f}"
                                f"，按 expo {hov['expo']:.2f} 换成推力 {hov['thrust']:.2f}"
                                f"（参数 {hov_param:.3f}，差 {diff:+.2f}）"))

    # 2) 陷波：没有频谱就别给频率
    if log.params.get("INS_HNTCH_ENABLE", 0) == 0:
        if hz is not None and hz >= THRESH["imu_min_hz"]:
            sugg.append(dict(param="INS_HNTCH_ENABLE", current=0, suggested="1（先算桨频）",
                             level="info", reason="采样率够，可以按 桨频=转速/60×叶片数 填 FREQ"))
        else:
            sugg.append(dict(param="INS_HNTCH_ENABLE", current=0, suggested="暂不改",
                             level="info", reason=f"IMU 只有 {hz:.0f} Hz，算不桨频；先开 INS_LOG_BAT_MASK=1 复飞"))

    if log.params.get("INS_LOG_BAT_MASK", 0) == 0:
        sugg.append(dict(param="INS_LOG_BAT_MASK", current=0, suggested=1, level="major",
                         reason="打开 batch 采样，下次飞行才有 0–500 Hz 的原始 IMU 可做 FFT"))

    # 3) D 项：振动超标时不给数值
    for axis in ("RLL", "PIT"):
        P = log.params.get(f"ATC_RAT_{axis}_P")
        D = log.params.get(f"ATC_RAT_{axis}_D")
        if not (P and D) or D <= max(3 * DEFAULTS[f"ATC_RAT_{axis}_D"], THRESH["d_over_p"] * P):
            continue
        if vib_bad:
            sugg.append(dict(param=f"ATC_RAT_{axis}_D", current=round(D, 4), suggested="暂不改",
                             level="info",
                             reason=f"D/P={D / P:.3f} 偏大，但振动 Z p95 {vib['p95']:.1f} m/s²"
                                    f"／削顶 {int(vib['clip'])} 次，此时降 D 收益有限，先治振动"))
        else:
            new = round(max(0.03 * P, 0.7 * D, DEFAULTS[f"ATC_RAT_{axis}_D"]), 4)
            sugg.append(dict(param=f"ATC_RAT_{axis}_D", current=round(D, 4), suggested=new,
                             level="warn",
                             reason=f"D/P={D / P:.3f} 高于默认量级 0.027，按默认比例回调，单次最多降 30%"))

    # 4) 质量门没过：把"改增益"的建议收成一句话
    if vib_bad:
        sugg.insert(0, dict(param="（所有 PID 增益）", current="—", suggested="暂不改",
                            level="major",
                            reason=f"振动 Z 轴 p95 {vib['p95']:.1f} m/s²、削顶 {int(vib['clip'])} 次："
                                   f"先查桨平衡/电机轴承/机架螺丝，再谈 PID"))

    return dict(
        imu_hz=hz, vib=vib, motor=mot, rate=rate, delay=delay, hover=hov,
        coverage=cov, gate=gate, params=param_audit(log), suggestions=sugg,
        verdict=("先治振动" if vib_bad else ("可以开始调参" if rate else "数据不足")),
    )


def render_section(tune: dict, log: FlightLog) -> list[str]:
    """给 Markdown 报告用的「调参体检」章节。"""
    out: list[str] = []
    out.append(f"**判定**：{tune['verdict']}　·　"
               f"IMU {tune['imu_hz']:.0f} Hz" if tune.get("imu_hz") else f"**判定**：{tune['verdict']}")
    out.append("")
    out.append("| 检查项 | 结论 | 实测 |")
    out.append("| --- | --- | --- |")
    for g in tune["gate"]:
        out.append(f"| {g['title']} | {g['level'].upper()} | {g['detail']} |")
    out.append("")
    if tune.get("delay"):
        d = tune["delay"]
        out.append(f"**等效延迟**：{d['delay_ms']:.0f} ms（2 Hz 处滞后 {d['lag_2hz']:.0f}°，"
                   f"相干度 {d['coherence']:.2f}；其中 FLTT {d['fltt_hz']:.0f} Hz 贡献 "
                   f"{d['fltt_ms']:.0f} ms）")
        out.append("")
    if tune["suggestions"]:
        out.append("| 参数 | 当前 | 建议 | 依据 |")
        out.append("| --- | --- | --- | --- |")
        for s in tune["suggestions"]:
            out.append(f"| `{s['param']}` | {s['current']} | {s['suggested']} | {s['reason']} |")
        out.append("")
    covered = {x["param"] for x in tune["suggestions"]}
    rest = [p for p in tune["params"] if p["param"] not in covered]
    if rest:
        out.append("**其他参数**：")
        for p in rest:
            out.append(f"- [{p['level']}] `{p['param']}`：{p['text']}")
        out.append("")
    out.append("*调参建议只改一个参数、幅度不超过 20–30%，改完飞一次再比；"
               "本工具不写参数，所有改动需要在 Mission Planner / QGC 里人工执行。*")
    out.append("")
    return out
