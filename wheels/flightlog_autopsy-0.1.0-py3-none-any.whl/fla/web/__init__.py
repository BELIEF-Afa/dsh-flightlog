"""网页界面（FastAPI）。"""
