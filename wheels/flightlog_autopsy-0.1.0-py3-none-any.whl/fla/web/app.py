"""FastAPI 网页界面：上传日志 → 看报告。

启动：``python -m fla serve --port 8000``
"""
from __future__ import annotations

import datetime as dt
import time
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse

from .. import __version__
from ..analyzer import analyze
from ..export import SUFFIX_MEDIA, inline_images, markdown_to_docx, markdown_to_html
from ..figures import build_figures, explain
from ..llm import LLMConfig, LLMError, config_from_env, narrate, ping
from ..paths import data_root
from ..report import render_markdown
from .md import render as md_to_html

BASE_DIR = data_root()
TEMPLATE = Path(__file__).with_name("templates") / "index.html"
REPORT_DIR = BASE_DIR / "reports"
SAMPLE = BASE_DIR / "samples" / "accident_259.bin"
UPLOAD_DIR = BASE_DIR / ".uploads"
MAX_BYTES = 400 * 1024 * 1024

app = FastAPI(title="flightlog-autopsy", version=__version__)


def _llm_config(api_key: str | None, base_url: str | None, model: str | None) -> LLMConfig | None:
    try:
        return config_from_env(api_key=(api_key or None), base_url=(base_url or None),
                               model=(model or None))
    except LLMError:
        return None


def _payload(path: Path, a, narrative: dict | None, elapsed: float) -> dict:
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"{path.stem}_{stamp}"
    figs, notes = [], []
    try:
        figs = build_figures(a, REPORT_DIR, prefix=stem)
        notes = explain(a) if figs else []
    except Exception as exc:  # 画不出来也要出报告
        print(f"画图失败：{exc}", file=sys.stderr)
    md = render_markdown(a, narrative=narrative, figures=figs, notes=notes)
    out = REPORT_DIR / f"{stem}.md"
    out.write_text(md, encoding="utf-8")
    # 同时生成 Word 与可打印 HTML，网页上可以直接下载交付
    docx = markdown_to_docx(md, REPORT_DIR / f"{stem}.docx", base_dir=REPORT_DIR)
    html_doc = markdown_to_html(md, REPORT_DIR / f"{stem}.html", base_dir=REPORT_DIR)
    return {
        "ok": True,
        "file": path.name,
        "verdict": a.verdict,
        "score": a.score,
        "verdict_text": a.verdict_text,
        "summary": a.summary,
        "findings": [
            {"title": f.title, "severity": f.severity, "category": f.category,
             "time": f.t_start, "evidence": f.evidence, "conclusion": f.conclusion}
            for f in a.sorted_findings()
        ],
        "skipped": [{"detector": s.detector, "reason": s.reason} for s in a.skipped],
        "narrative": narrative,
        "markdown": md,
        "html": inline_images(md_to_html(md), REPORT_DIR),
        "figures": [{"file": f.path.name, "title": f.title, "caption": f.caption}
                    for f in figs],
        "report_file": out.name,
        "report_files": {"md": out.name, "docx": docx.name, "html": html_doc.name},
        "elapsed": round(elapsed, 1),
        "usage": (narrative or {}).get("usage"),
    }


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    tmpl = TEMPLATE.read_text(encoding="utf-8")
    return (tmpl.replace("{{VERSION}}", __version__)
                .replace("{{SAMPLE}}", "1" if SAMPLE.exists() else "0"))


@app.get("/api/health")
def health() -> dict:
    cfg = config_from_env()
    return {"ok": True, "version": __version__,
            "llm_configured": bool(cfg), "model": cfg.model if cfg else None,
            "sample": SAMPLE.exists()}


@app.post("/api/llm/ping")
def llm_ping(api_key: str = Form(""), base_url: str = Form(""), model: str = Form("")) -> JSONResponse:
    cfg = _llm_config(api_key, base_url, model)
    if cfg is None:
        return JSONResponse({"ok": False, "error": "没有提供 API Key"}, status_code=400)
    try:
        reply = ping(cfg)
    except LLMError as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=502)
    return JSONResponse({"ok": True, "model": cfg.model, "reply": reply[:80]})


def _run(path: Path, api_key: str, base_url: str, model: str,
         use_llm: bool, temperature: float | None) -> dict:
    t0 = time.time()
    try:
        a = analyze(str(path))
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"解析失败：{exc}") from exc
    narrative = None
    warn = None
    if use_llm:
        cfg = _llm_config(api_key, base_url, model)
        if cfg is None:
            warn = "未提供大模型密钥，已只输出规则层报告。"
        else:
            try:
                narrative = narrate(a, cfg, temperature=temperature)
            except LLMError as exc:
                warn = f"大模型调用失败，已回退到离线报告：{exc}"
    payload = _payload(path, a, narrative, time.time() - t0)
    if warn:
        payload["warning"] = warn
    return payload


@app.post("/api/analyze")
async def analyze_upload(
    file: UploadFile = File(...),
    api_key: str = Form(""),
    base_url: str = Form(""),
    model: str = Form(""),
    use_llm: bool = Form(False),
    temperature: float | None = Form(None),
) -> JSONResponse:
    name = Path(file.filename or "log.bin").name
    suffix = Path(name).suffix.lower() or ".bin"
    tmp_dir = UPLOAD_DIR
    tmp_dir.mkdir(parents=True, exist_ok=True)
    dst = tmp_dir / f"fla-{int(time.time() * 1000)}-{name}{'' if suffix in name else suffix}"
    size = 0
    with dst.open("wb") as f:
        while chunk := await file.read(1 << 20):
            size += len(chunk)
            if size > MAX_BYTES:
                dst.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="文件过大（上限 400 MB）")
            f.write(chunk)
    try:
        payload = _run(dst, api_key, base_url, model, use_llm, temperature)
        payload["file"] = name
        return JSONResponse(payload)
    finally:
        dst.unlink(missing_ok=True)


@app.post("/api/analyze-sample")
def analyze_sample(api_key: str = Form(""), base_url: str = Form(""), model: str = Form(""),
                   use_llm: bool = Form(False)) -> JSONResponse:
    if not SAMPLE.exists():
        raise HTTPException(status_code=404, detail="示例日志不存在")
    return JSONResponse(_run(SAMPLE, api_key, base_url, model, use_llm, None))


@app.get("/api/report/{name}")
def get_report(name: str):
    """下载报告：.md 原文 / .docx Word / .html 可打印版。"""
    safe = Path(name).name
    p = REPORT_DIR / safe
    suffix = p.suffix.lower()
    if not p.exists() or suffix not in SUFFIX_MEDIA:
        raise HTTPException(status_code=404, detail="报告不存在")
    return FileResponse(p, media_type=SUFFIX_MEDIA[suffix], filename=safe)
