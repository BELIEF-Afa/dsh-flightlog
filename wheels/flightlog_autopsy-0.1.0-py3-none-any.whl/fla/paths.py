"""运行时目录解析。

三种运行形态：

* 源码仓库：``fla/paths.py`` 的上一级目录就是项目根，示例日志在 ``samples/``。
* 便携包 / 安装版：Python 解释器位于 ``<根>/runtime/python.exe``，根目录下放
  ``samples/``、``reports/``、``.uploads/``，与 ``runtime/`` 平级。
* 其它（例如 pip 安装到 site-packages）：用当前工作目录，用户可再用
  ``FLA_DATA_DIR`` 覆盖。

统一入口是 :func:`data_root`，环境变量 ``FLA_DATA_DIR`` 优先级最高。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def data_root() -> Path:
    """返回存放 samples/reports/.uploads 的根目录。"""
    env = os.environ.get("FLA_DATA_DIR")
    if env:
        return Path(env).expanduser().resolve()
    exe_dir = Path(sys.executable).resolve().parent
    # 便携包：runtime/python.exe + runtime/python311._pth 同在解释器目录
    if (exe_dir / "python311._pth").exists():
        return exe_dir.parent
    # 源码仓库：本文件位于 <root>/fla/paths.py
    repo = Path(__file__).resolve().parents[1]
    if (repo / "samples").is_dir() or (repo / "pyproject.toml").exists():
        return repo
    return Path.cwd()
